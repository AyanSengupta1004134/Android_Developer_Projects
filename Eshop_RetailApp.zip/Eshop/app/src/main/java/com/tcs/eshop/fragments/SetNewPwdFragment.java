package com.tcs.eshop.fragments;

/**
 * Created by 986719 on 9/18/2015.
 */



        import android.content.Context;
        import android.os.Bundle;
        import android.support.v4.app.Fragment;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

        import com.tcs.eshop.activities.MainActivity;
        import com.tcs.eshop.fragments.ForgotPasswordFragment;
        import com.tcs.eshop.database.EshopSqlHelper;
        import com.tcs.eshop.R;

/**
 * Created by 963693 on 9/17/2015.
 */
public class SetNewPwdFragment extends Fragment {
    private Context mContext;
    private EshopSqlHelper mEshopSqlHelper;
    private TextView tvNewPswd, tvCnfmPswd;
    private EditText etNewPswd, etCntmPswd;
    Button btPswdChng;
    String mNewPswd, mCnfmPswd, mUserId;
    RegisterFragment shopNewRegister;
    ForgotPasswordFragment shopForgotPassword;
    MainActivity mainActivity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        mainActivity= (MainActivity) getActivity();
        mUserId = bundle.getString("uid");

    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // super.onCreateView(inflater, container, savedInstanceState);
        View v = inflater.inflate(R.layout.new_pswd, container, false);
        initViews(container, v);
        setListener();
        return v;
    }

    /**
     * Description: Used to set the listener
     */
    private void setListener() {
        btPswdChng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mNewPswd = etNewPswd.getText().toString();
                mCnfmPswd = etCntmPswd.getText().toString();
                //sUserId=shopForgotPassword.mUserId;
              if (mCnfmPswd.length() < 8) {
                    etCntmPswd.setError(getString(R.string.passwordLength));}
         if (mNewPswd.length() < 8) {

                  etNewPswd.setError(getString(R.string.passwordLength));}
                if (!validate(mNewPswd, mCnfmPswd)) {
                    Toast.makeText(mContext, R.string.passwordMismatchError, Toast.LENGTH_SHORT).show();
                } else if (mEshopSqlHelper.updatePassword(mUserId, mCnfmPswd)) {
                    Toast.makeText(mContext, R.string.LoginWithNewPassword, Toast.LENGTH_SHORT).show();
                   // LoginFragment shopLoginFragment = new LoginFragment();
                    mainActivity.changeFragment(LoginFragment.class, null, true, LoginFragment.class.getName());

                   // getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, shopLoginFragment, "login").addToBackStack("setnewpwd").commit();

                }

            }
        });
    }

    /**
     * Description: Used for initializing the views
     * @param container: View group
     * @param v: view
     */
    private void initViews(ViewGroup container, View v) {
        mContext = container.getContext();
        shopNewRegister = new RegisterFragment();
        shopForgotPassword = new ForgotPasswordFragment();
        mEshopSqlHelper = EshopSqlHelper.getInstance(getActivity());
        tvNewPswd = (TextView) v.findViewById(R.id.tvNewPswd);
        etNewPswd = (EditText) v.findViewById(R.id.etNewPswd);
        tvCnfmPswd = (TextView) v.findViewById(R.id.tvCnfmPswd);
        etCntmPswd = (EditText) v.findViewById(R.id.etCnfmPswd);
        btPswdChng = (Button) v.findViewById(R.id.btPswdChng);
    }

    /**
     * Description: Used for validating passwords
     * @param password: New Password
     * @param confirmPassword: Confirm Password
     * @return
     */
    public boolean validate(String password, String confirmPassword) {
        Boolean flag = true;
        if (!password.equals(confirmPassword)) {
            etNewPswd.setText("");
            etCntmPswd.setText("");
            //Toast.makeText(mContext, R.string.passwordMismatch, Toast.LENGTH_LONG).show();
            flag = false;
        }
        return flag;
    }


}
