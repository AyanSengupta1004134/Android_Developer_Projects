package com.tcs.eshop.EshopClasses;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by 986719 on 9/17/2015.
 */
public class DisplayToast {
    public static void showToast(String msg,Context context)
    {
        Toast.makeText(context,msg,Toast.LENGTH_LONG);
    }
}
