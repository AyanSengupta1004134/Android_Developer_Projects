package com.tcs.eshop.EshopClasses;

import java.io.Serializable;

/**
 * Created by 962609 on 9/21/2015.
 */
public class Payment implements Serializable {

    private int custId;
    private String cardNumber;
    private String cardType;
    private  String expiryMonth;
    private String expiryYear;

    public Payment(int custId,String cardNumber,String cardType,String expiryMonth,String expiryYear) {
        this.custId=custId;
       this.cardNumber=cardNumber;
        this.cardType=cardType;
        this.expiryMonth=expiryMonth;
        this.expiryYear=expiryYear;
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getExpiryMonth() {
        return expiryMonth;
    }

    public void setExpiryMonth(String expiryMonth) {
        this.expiryMonth = expiryMonth;
    }

    public String getExpiryYear() {
        return expiryYear;
    }

    public void setExpiryYear(String expiryYear) {
        this.expiryYear = expiryYear;
    }
}
