package com.tcs.eshop.adapter;

/**
 * Created by 986719 on 9/16/2015.
 */

import android.content.Context;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;

/**
 * Created by 986719 on 9/16/2015.
 */
public class SliderAdapter extends PagerAdapter {
    Context context;
    ImageView mImageView;
    //Drawable d=null;
    int mImageId[]={R.drawable.rsz_winter_sale,R.drawable.rsz_galaxy_s,R.drawable.rsz_mens_suit,R.drawable.kurtis_multilink,R.drawable.rsz_philips_trimmer,R.drawable.rsz_women_ethnic};
    public SliderAdapter(Context context)
    {
        this.context=context;
    }
    @Override
    public int getCount() {
        return mImageId.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return  view == ((View)object);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        ((ViewPager) container).removeView((View) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View view=null;

        LayoutInflater inflater = ((MainActivity)context).getLayoutInflater();
        if(view==null) {
            view = inflater.inflate(R.layout.slider, container, false);
        }
        mImageView= (ImageView) view.findViewById(R.id.imageView5);
        mImageView.setImageResource(mImageId[position]);
        mImageView.setScaleType(ImageView.ScaleType.FIT_XY);
        ((ViewPager)container).addView(view);
        return view;
    }
}
