package com.tcs.eshop.adapter;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.tcs.eshop.fragments.SwipeFragment1;
import com.tcs.eshop.fragments.SwipeFragment2;

/**
 * Created by 986719 on 9/16/2015.
 */
public class SwipeAdapter extends FragmentPagerAdapter {

    String mCategory;
    public SwipeAdapter(FragmentManager fm,String category) {
        super(fm);
        mCategory=category;
    }

    @Override
    public Fragment getItem(int position) {
        Fragment fragment=null;
        if(position==0)
        {
            fragment=new SwipeFragment1();
        }
        else
        {
            fragment=new SwipeFragment2();
        }
        Bundle bundle=new Bundle();
        bundle.putString("category", mCategory);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public int getCount() {
        return 2;
    }
}
