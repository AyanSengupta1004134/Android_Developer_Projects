package com.tcs.eshop.adapter;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.tcs.eshop.EshopClasses.Cart;
import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.R;
import com.tcs.eshop.utilities.DatabaseCaller;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by 986719 on 9/17/2015.
 */
public class CartAdapter extends BaseAdapter {
    Context context;
    Product mProduct;
     ArrayList<Cart> mCartlist;
    ArrayList<Product> mProductList;
    TextView mTotalPriceText;
    Button mPayNowButton;
    CartAdapter cartAdapter;
    int mCustId;
DatabaseCaller mDatabaseCaller;

    ImageView mProductImage,mDeleteProductImage;
    TextView mProductNameText,mProductPriceText,mProductQtyText,mProductTotalPriceText;
     boolean isOutOfStock=false;
    public CartAdapter(Context context,TextView totalPriceText, Button payNowButton)
    {
        mDatabaseCaller=new DatabaseCaller((MainActivity)context);
         cartAdapter=this;
        mCustId=context.getSharedPreferences("login", Context.MODE_PRIVATE).getInt("custId",-1 );
        this.mPayNowButton=payNowButton;
        this.context=context;
        this.mTotalPriceText=totalPriceText;
        mProductList=new ArrayList<>();
        mCartlist=mDatabaseCaller.getCartList(mCustId);
        fetchProductList();
        Log.d("list", "2st:" + mCartlist.size());
        Log.d("list","ist:"+mProductList.size());


    }

    public boolean isOutOfStock() {
        return isOutOfStock;
    }

    public ArrayList<Cart> getmCartlist() {
        return mCartlist;
    }

    public ArrayList<Product> getmProductList() {
        return mProductList;
    }
    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        mProductList=new ArrayList<>();
        mCartlist=mDatabaseCaller.getCartList(mCustId);
        fetchProductList();
        Log.d("list", "2st:" + mCartlist.size());
        Log.d("list", "ist:" + mProductList.size());
        setTotalPrice(mProductList, mCartlist);
        MainActivity mainActivity= (MainActivity)context;
        mainActivity.getmCartText().setText("" + mCartlist.size());
    }

    /**
     * Description: Used for fetching all the products in the Cart
     */
    public void fetchProductList()
    {
        for(int i=0;i<mCartlist.size();i++)
        {
            Log.d("list","i:"+i);

            mProductList.add(i,mDatabaseCaller.getProduct(mCartlist.get(i).getProductCode()));
        }
    }
    @Override
    public int getCount() {
        return mCartlist.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }


    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if(view==null) {
            view=inflater.inflate(R.layout.cartsinglerow, viewGroup, false);
        }
        initViews(view,i);
        return view;
    }

    public void initViews(View view, final int position)
    {
        mProductNameText= (TextView) view.findViewById(R.id.cartNameText);
        mProductPriceText= (TextView) view.findViewById(R.id.cartPriceText);
        mProductQtyText= (TextView) view.findViewById(R.id.cartlisqtyText);
        mProductTotalPriceText= (TextView) view.findViewById(R.id.cartTotalpriceText);
        mProductImage= (ImageView) view.findViewById(R.id.cartItemImgae);
        mDeleteProductImage= (ImageView) view.findViewById(R.id.cartDeleteImage);
        mProductNameText.setText(mProductList.get(position).getProductName());
        mProductPriceText.setText("rs:"+String.valueOf(mProductList.get(position).getProductPrice()));
        if(checkProductAvailable(position)) {
            mProductQtyText.setText("Quantity:" + String.valueOf(mCartlist.get(position).getNoOfItems()));

        }
        else
        {
            mProductQtyText.setText("Quantity:" + String.valueOf(mCartlist.get(position).getNoOfItems())+" (*Out Of Stock)");
            isOutOfStock=true;

        }
        mProductTotalPriceText.setText("Price("+mCartlist.get(position).getNoOfItems()+"*"+ mProductList.get(position).getProductPrice()+"):"+String.valueOf(mProductList.get(position).getProductPrice() * mCartlist.get(position).getNoOfItems()));

        File folder =context.getExternalFilesDir("contactimages");

        File file=new File(folder,mProductList.get(position).getProductImagePath());
        Log.d("path", file.getAbsolutePath());
        mProductImage.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
      //  Toast.makeText(context,"Name1a="+mProductList.get(position).getProductName(),Toast.LENGTH_LONG).show();

        mDeleteProductImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!checkProductAvailable(position))
                {
                    isOutOfStock=false;
                }
                mDatabaseCaller.deleteCartItems(mCustId, mProductList.get(position).getProductId());

                cartAdapter.notifyDataSetChanged();
               // Toast.makeText(context, "Deleting is not yet implemented", Toast.LENGTH_LONG).show();

            }
        });




    }

    /**
     * Description: Used for checking aavailability of a product
     * @param i: Position
     * @return: boolean indicating result
     */
    public boolean checkProductAvailable(int i)
    {
        boolean flag=true;


           if(mProductList.get(i).getProductQtyAvailable()<mCartlist.get(i).getNoOfItems())
           {
               flag=false;
           }
        return flag;

    }

    /**
     * Description:Used for setting total cart price
     * @param productArrayList: list of products
     * @param cartArrayList: list of cartProducts
     */
    public  void  setTotalPrice(ArrayList<Product> productArrayList,ArrayList<Cart> cartArrayList)
    {
        float totalPrice=0;
        if(productArrayList.size()>0)
        {
            for(int i=0;i<productArrayList.size();i++)
            {
                totalPrice+=productArrayList.get(i).getProductPrice()*cartArrayList.get(i).getNoOfItems();
            }
            mTotalPriceText.setText("Total Price:"+totalPrice);
        }
        else
        {
            mTotalPriceText.setText("Please add a product first..");
            MainActivity mainActivity= (MainActivity) context;
            mainActivity.getmCartText().setText("0");
            mPayNowButton.setVisibility(View.INVISIBLE);
        }

    }
}
