package com.tcs.eshop.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.EshopClasses.Review;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.CustomerTable;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.CustomerTable;
import com.tcs.eshop.utilities.DatabaseCaller;

import java.util.ArrayList;

/**
 * Created by 986719 on 9/19/2015.
 */
public class ReviewListAdapter extends BaseAdapter {
    Context context;
    ArrayList<Review> mReviewList;
    TextView mReviewText,mCustomerName;
    DatabaseCaller mDatabaseCaller;
    public ReviewListAdapter(Context context, ArrayList<Review> reviewArrayList) {
        this.context = context;
        mDatabaseCaller=new DatabaseCaller((MainActivity)context);
        mReviewList = reviewArrayList;
    }

    @Override
    public int getCount() {
        return mReviewList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (view == null) {
            view = inflater.inflate(R.layout.reviewlistsinglerow, viewGroup, false);
        }
        initViews(view, i);
        return view;
    }

    public void initViews(View view,int position) {
        mReviewText= (TextView) view.findViewById(R.id.review);
        mCustomerName= (TextView) view.findViewById(R.id.customerReview);
        mReviewText.setText(mReviewList.get(position).getUserReview());
        mCustomerName.setText("Name:"+mDatabaseCaller.getCustomerName(mReviewList.get(position).getCustomerId()));

    }

}