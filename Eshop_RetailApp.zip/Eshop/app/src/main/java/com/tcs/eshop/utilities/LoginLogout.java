package com.tcs.eshop.utilities;

import android.widget.Toast;

import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;

/**
 * Created by 986719 on 10/1/2015.
 */
public class LoginLogout {
    public static void setLogInDetails(MainActivity mainActivity) {

        mainActivity.setCartDetails();
        mainActivity.getMainMenu().findItem(R.id.loginMenu).setVisible(false);
        mainActivity.getMainMenu().findItem(R.id.logout).setVisible(true);
        mainActivity.getMainMenu().findItem(R.id.deleteAccount).setVisible(true);
        mainActivity.getMainMenu().findItem(R.id.changePassword).setVisible(true);
    }
    public static void setLogOutDetails(MainActivity mainActivity) {
        mainActivity.getmCartText().setText("0");
        mainActivity.getmNavTextView().setText("");
        mainActivity.getMainMenu().findItem(R.id.loginMenu).setVisible(true);
        mainActivity.getMainMenu().findItem(R.id.logout).setVisible(false);
        mainActivity.getMainMenu().findItem(R.id.deleteAccount).setVisible(false);
        mainActivity.getMainMenu().findItem(R.id.changePassword).setVisible(false);
        Toast.makeText(mainActivity,"LogOut",Toast.LENGTH_LONG).show();
        mainActivity.getSharedPreferences("login",mainActivity.MODE_PRIVATE).edit().clear().commit();
        mainActivity.getSharedPreferences("payment", mainActivity.MODE_PRIVATE).edit().clear().commit();
    }
}
