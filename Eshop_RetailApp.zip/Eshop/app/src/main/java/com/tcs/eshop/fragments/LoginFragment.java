package com.tcs.eshop.fragments;

/**
 * Created by 986719 on 9/18/2015.
 */


        import android.content.Context;
        import android.content.SharedPreferences;
        import android.os.Bundle;
        import android.support.v4.app.Fragment;
        import android.text.Editable;
        import android.text.TextWatcher;
        import android.text.method.HideReturnsTransformationMethod;
        import android.text.method.PasswordTransformationMethod;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.Button;
        import android.widget.CheckBox;
        import android.widget.CompoundButton;
        import android.widget.EditText;
        import android.widget.LinearLayout;
        import android.widget.TextView;
        import android.widget.Toast;

        import com.tcs.eshop.activities.MainActivity;
        import com.tcs.eshop.database.EshopSqlHelper;
        import com.tcs.eshop.R;
        import com.tcs.eshop.utilities.DatabaseCaller;
        import com.tcs.eshop.utilities.LoginLogout;


        import org.w3c.dom.Text;

        import java.util.regex.Matcher;
        import java.util.regex.Pattern;

/**
 * Created by 963693 on 9/15/2015.
 */
public class LoginFragment extends Fragment implements View.OnClickListener {
    private Context mContext;
    LinearLayout loginLinearLayout;
    EditText sEnterId,sEnterpswd;
    CheckBox sShowPswd;
    Button sBtLogin;
    TextView sForgotPassword,sRegister;
    EshopSqlHelper mEshopSqlHelper;
    String mUserId,mPswd;
    RegisterFragment shopNewRegister;
    DatabaseCaller databaseCaller;
    MainActivity mainActivity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
        databaseCaller=new DatabaseCaller((MainActivity)getActivity());
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // super.onCreateView(inflater, container, savedInstanceState);
        View v=inflater.inflate(R.layout.newlogin,container,false);
        mContext=container.getContext();
        loginLinearLayout= (LinearLayout) v.findViewById(R.id.loginLayoutMy);
        initViews(v);
        return v;
    }

    /**
     * Description:Iniatialises the views
     * @param v: view object representing the layout
     */
    private void initViews(View v) {

        mEshopSqlHelper= EshopSqlHelper.getInstance(getActivity());
        shopNewRegister =new RegisterFragment();
        sEnterId=(EditText) v.findViewById(R.id.etName);
        sEnterpswd=(EditText) v.findViewById(R.id.etPassword);
        sShowPswd=(CheckBox) v.findViewById(R.id.checkPassword);
        sBtLogin=(Button) v.findViewById(R.id.loginButton);
        sForgotPassword=(TextView) v.findViewById(R.id.tvForgotPassword);
        sRegister=(TextView) v.findViewById(R.id.Register);
        setListener();
    }

    /**Description:Used for setting the listeners
     *
     */
    private void setListener() {
        sBtLogin.setOnClickListener(this);
        sForgotPassword.setClickable(true);
        sForgotPassword.setOnClickListener(this);
        sRegister.setClickable(true);
        sRegister.setOnClickListener(this);
        // when user clicks on this checkbox, this is the handler.
        sShowPswd.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // checkbox status is changed from uncheck to checked.
                if (!isChecked) {
                    // show password
                    sEnterpswd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else {
                    // hide password
                    sEnterpswd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });
        sEnterId.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if(b)
                {
                  //  loginLinearLayout.setBackground(getResources().getDrawable(R.drawable.register_page));

                }
                if (sEnterId.getText().toString().isEmpty()) {
                    sEnterId.setError(mContext.getString(R.string.CustomerIdFilled));
                } else if (!isNumeric(sEnterId.getText().toString())) {
                    if (!shopNewRegister.isValidMail(sEnterId.getText().toString())) {
                        sEnterId.setError(mContext.getString(R.string.EmailFormat));
                    }
                } else if (!shopNewRegister.isValidNo(sEnterId.getText().toString())) {
                    sEnterId.setError(mContext.getString(R.string.phoneNoFormat));
                }
            }
        });
        sEnterpswd.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if(b)
                {

                    //loginLinearLayout.setBackground(getResources().getDrawable(R.drawable.register_page));
                }
                if (sEnterpswd.getText().toString().isEmpty()) {
                    sEnterpswd.setError(mContext.getString(R.string.EmptyPassword));
                }
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.loginButton:
                mUserId=sEnterId.getText().toString();
                mPswd=sEnterpswd.getText().toString();
                if(validate(mContext)==false){
                    Toast.makeText(mContext, R.string.EmptyField,Toast.LENGTH_SHORT).show();}

                else{
                    Boolean flag = mEshopSqlHelper.checkCustomer(mUserId);
                    if (flag == false) {
                        Toast.makeText(mContext, R.string.NewUser, Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Boolean mFlag=mEshopSqlHelper.loginCustomer(mUserId,mPswd);
                        if(mFlag==false)
                        {
                            Toast.makeText(mContext, R.string.WrongPassword, Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            SharedPreferences sharedPreferences=getActivity().getSharedPreferences("login",Context.MODE_PRIVATE);
                            SharedPreferences.Editor edit=sharedPreferences.edit();
                           edit.putString("userid", mUserId);
                            edit.putInt("custId", databaseCaller.getCustomerId(mUserId));
                            edit.commit();
                            //HomeFragment loggedInFragment=new HomeFragment();
                            LoginLogout.setLogInDetails((MainActivity) getActivity());
                            mainActivity.changeFragment(HomeFragment.class, null, true, HomeFragment.class.getName());

                            //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout,loggedInFragment,"home").commit();
                        }
                    }
                }
                break;
            case R.id.tvForgotPassword:

                mainActivity.changeFragment(ForgotPasswordFragment.class, null, true, ForgotPasswordFragment.class.getName());

               // getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new ForgotPasswordFragment(),"forgot").addToBackStack("login").commit();

                break;
            case R.id.Register:

                mainActivity.changeFragment(RegisterFragment.class, null, true, RegisterFragment.class.getName());

                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout,new RegisterFragment(),"register").addToBackStack("home").commit();
                break;
        }}


    /**
     * Description : Used For Validating the UserId And Password
     * @param context: Context object
     * @return: boolean value indicating validation
     */
    public boolean validate(Context context) {
        boolean flag = true;


        if (sEnterId.getText().toString().isEmpty() || sEnterpswd.getText().toString().isEmpty()) {
            flag = false;
        }return flag;
    }


    /**
     * Description: Used for checking whether str is numeric or not
     * @param str: String which needs checking
     * @return: boolean indicating the result
     */
    public static boolean isNumeric(String str)
    {
        try
        {
            double d = Double.parseDouble(str);
        }
        catch(NumberFormatException nfe)
        {
            return false;
        }
        return true;
    }

}


