package com.tcs.eshop.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.tcs.eshop.utilities.ApplicationConstant.*;

import com.tcs.eshop.R;

import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.utilities.LoginLogout;

/**
 * Created by 986719 on 9/24/2015.
 */
public class ChangePassword extends Fragment {
    private EditText etOldPswd,etNewPswd,etCnfmPswd;
    Button btChngPswd;
    String mUserId;
    EshopSqlHelper db;
MainActivity mainActivity;
    String mOldPswd,mNewPswd,mCnfmPswd;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
        mUserId=getActivity().getSharedPreferences("login", Context.MODE_PRIVATE).getString("userid", "");

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.change_password, container, false);
        initViews(v);


        return  v;
    }

    /**
     * Description: Used for initailizing the views
     * @param v: view argument
     */

    private void initViews(View v) {
        db= EshopSqlHelper.getInstance(getActivity());

        etOldPswd=(EditText)v.findViewById(R.id.etOldPswd);
        etNewPswd=(EditText)v.findViewById(R.id.etNewPassswd);
        etCnfmPswd=(EditText)v.findViewById(R.id.etCnfmPassword);
        btChngPswd=(Button)v.findViewById(R.id.btPswdChng);
        btChngPswd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mOldPswd = etOldPswd.getText().toString();
                mNewPswd = etNewPswd.getText().toString();
                mCnfmPswd = etCnfmPswd.getText().toString();
                boolean flag = db.loginCustomer(mUserId, mOldPswd);
                if (isValidPwd()) {
                    if (flag == false) {
                        etOldPswd.setError("Entered a wrong password");
                    } else if (!validate(mNewPswd, mCnfmPswd)) {
                        etCnfmPswd.setError("new password and confirm password is not matched");
                    } else if (db.updatePassword(mUserId, mCnfmPswd)) {
                        Toast.makeText(getActivity(), "Login with New password", Toast.LENGTH_SHORT).show();
                       // LoginFragment shopLoginFragment = new LoginFragment();
                        LoginLogout.setLogOutDetails((MainActivity) getActivity());
                        mainActivity.changeFragment(LoginFragment.class, null, true, LoginFragment.class.getName());

                      //  getFragmentManager().beginTransaction().replace(R.id.framelayout, shopLoginFragment, "login").addToBackStack(null).commit();

                    }
                }
            }
        });
    }

    /**
     * Description: Used for validation
     * @return: Boolean value indicating result
     */
    public boolean isValidPwd()
    {
        boolean flag=true;
        if(etCnfmPswd.getText().toString().isEmpty())
        {
            etCnfmPswd.setError(ErrorCaonstants.REQUIRED_FIELD);
            flag=false;
        }
        else {
            if (etCnfmPswd.getText().toString().length() < 8) {
                etCnfmPswd.setError(ErrorCaonstants.PASSWORD_FIELD);
                flag=false;
            }
        }
        if(etNewPswd.getText().toString().isEmpty())
        {
            etNewPswd.setError(ErrorCaonstants.REQUIRED_FIELD);
            flag=false;
        }
        else {
            if (etNewPswd.getText().toString().length() < 8) {
                etNewPswd.setError(ErrorCaonstants.PASSWORD_FIELD);
                flag=false;
            }
        }
        if(etOldPswd.getText().toString().isEmpty())
        {
            etOldPswd.setError(ErrorCaonstants.REQUIRED_FIELD);
            flag=false;
        }
        else {
            if (etOldPswd.getText().toString().length() < 8) {
                etOldPswd.setError(ErrorCaonstants.PASSWORD_FIELD);
                flag=false;
            }
        }

        return flag;

    }

    /**
     * Description: Used for required field Validation
     * @param password: New password
     * @param confirmPassword: Old Password
     * @return
     */
    public boolean validate(String password,String confirmPassword)
    { Boolean flag=true;
        if (!password.equals(confirmPassword)) {
            etNewPswd.setText("");
            etCnfmPswd.setText("");
            flag = false;
        }
        return  flag;
    }


}
