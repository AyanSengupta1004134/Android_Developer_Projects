package com.tcs.eshop.EshopClasses;

import java.io.Serializable;

/**
 * Created by 986719 on 9/17/2015.
 */
public class Product  implements Serializable{
    private int productId;
    private String productName;
    private String productCategory;
    private String productSubCategory;
    private float productPrice;
    private String productImagePath;
    private int productQtyAvailable;
    private String productDescription;

    public Product(int productId, String productName, String productCategory, String productSubCategory, float productPrice, String productImagePath, int productQtyAvailable, String productDescription) {
        this.productId = productId;
        this.productName = productName;
        this.productCategory = productCategory;
        this.productSubCategory = productSubCategory;
        this.productPrice = productPrice;
        this.productImagePath = productImagePath;
        this.productQtyAvailable = productQtyAvailable;
        this.productDescription = productDescription;
    }

    public Product(String productName, String productCategory, String productSubCategory, float productPrice, String productImagePath, int productQtyAvailable, String productDescription) {
        this.productName = productName;
        this.productCategory = productCategory;
        this.productSubCategory = productSubCategory;
        this.productPrice = productPrice;
        this.productImagePath = productImagePath;
        this.productQtyAvailable = productQtyAvailable;
        this.productDescription = productDescription;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public String getProductSubCategory() {
        return productSubCategory;
    }

    public void setProductSubCategory(String productSubCategory) {
        this.productSubCategory = productSubCategory;
    }

    public float getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(float productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductImagePath() {
        return productImagePath;
    }

    public void setProductImagePath(String productImagePath) {
        this.productImagePath = productImagePath;
    }

    public int getProductQtyAvailable() {
        return productQtyAvailable;
    }

    public void setProductQtyAvailable(int productQtyAvailable) {
        this.productQtyAvailable = productQtyAvailable;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }
}
