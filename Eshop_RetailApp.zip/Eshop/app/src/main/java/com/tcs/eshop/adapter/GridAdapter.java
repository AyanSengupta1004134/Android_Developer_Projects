package com.tcs.eshop.adapter;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.fragments.DetailsFragment;
import com.tcs.eshop.fragments.HomeFragment;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.ProductTable;
import com.tcs.eshop.utilities.DatabaseCaller;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by 986719 on 9/16/2015.
 */
public class GridAdapter extends BaseAdapter {
    Context context;
    String mCategory;
    TextView mNameText,mPriceText;
    ImageView mProductImage;
    ArrayList<Product> mProductList;
    DatabaseCaller mDatabaseCaller;
    public GridAdapter(Context context,String category)
    {
        mDatabaseCaller=new DatabaseCaller((MainActivity)context);
        this.context=context;
        this.mCategory=category;
        this.mProductList=mDatabaseCaller.getProductList(mCategory);
    }
    @Override
    public int getCount() {
        return mProductList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if(view==null) {
            view=inflater.inflate(R.layout.gridsingleitem,viewGroup,false);
        }
        initViews(view,i);
        return view;
    }

    /**
     * Description: Used for initializing the views
     * @param view: Views
     * @param position: index of the box
     */
    public void initViews(View view, final int position)
    {
        mNameText= (TextView) view.findViewById(R.id.gridNameText);
        mPriceText= (TextView) view.findViewById(R.id.gridPriceText);
        mProductImage= (ImageView) view.findViewById(R.id.gridProductImage);

        mProductImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             // Fragment fragment=new DetailsFragment();
                Bundle bundle=new Bundle();
                bundle.putSerializable("object", mProductList.get(position));
               // fragment.setArguments(bundle);
                ((MainActivity)context).changeFragment(DetailsFragment.class, bundle, true, DetailsFragment.class.getName());

                // ((MainActivity)context).getSupportFragmentManager().beginTransaction().replace(R.id.framelayout,fragment,"details").addToBackStack("category").commit();
            }
        });
        mNameText.setText(mProductList.get(position).getProductName());
        mPriceText.setText(String.valueOf(mProductList.get(position).getProductPrice()));

        File folder =context.getExternalFilesDir("contactimages");

        File file=new File(folder,mProductList.get(position).getProductImagePath());
        Log.d("path",file.getAbsolutePath());
        mProductImage.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
    }
}
