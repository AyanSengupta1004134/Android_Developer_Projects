package com.tcs.eshop.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.adapter.CartAdapter;

/**
 * Created by 986719 on 9/17/2015.
 */
public class CartFragment  extends Fragment {
    ListView mCartListView;
    LinearLayout mFooterLinearLayout;
   TextView mTotalPriceText;
     Button mPayNowButton;
    CartAdapter cartAdadter;
    EshopSqlHelper mEshopSqlHelper;
    MainActivity mainActivity;
    Customer mCustomer;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
    mEshopSqlHelper=EshopSqlHelper.getInstance(getActivity());


    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.cart_fragment,container,false);
       // mFooterLinearLayout= (LinearLayout) view.findViewById(R.id.footer);
        mCartListView= (ListView) view.findViewById(R.id.wishList);
        mCartListView.setDividerHeight(2);

        LayoutInflater layoutInflater= (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mCartListView.addFooterView(layoutInflater.inflate(R.layout.cartlist_footer, null, false));
        mTotalPriceText= (TextView) view.findViewById(R.id.toatlCartPrice);
        mPayNowButton= (Button) view.findViewById(R.id.cart_payButton);
        cartAdadter=new CartAdapter(getActivity(),mTotalPriceText,mPayNowButton);

        mCartListView.setAdapter(cartAdadter);

        mPayNowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cartAdadter.isOutOfStock())
                {
                    Toast.makeText(getActivity(), R.string.outOfStock,Toast.LENGTH_LONG).show();

                }
                else {
                    mainActivity.changeFragment(ShipingFragment.class, null, true, ShipingFragment.class.getName());

                   // getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new ShipingFragment(), "shiping").addToBackStack("cart").commit();
                }
            }
        });
        mCartListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            if(cartAdadter.getmCartlist().size()>0) {
                //Fragment fragment = new DetailsFragment();
                Bundle bundle = new Bundle();
                bundle.putSerializable("object", cartAdadter.getmProductList().get(position));
                //Toast.makeText(getActivity(), "Name=" + cartAdadter.mProductList.get(position).getProductName(), Toast.LENGTH_LONG).show();
                //fragment.setArguments(bundle);
                mainActivity.changeFragment(DetailsFragment.class, bundle, true, DetailsFragment.class.getName());

                // getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, fragment, "details").addToBackStack("cart").commit();

             }
            }
        });
        cartAdadter.setTotalPrice(cartAdadter.getmProductList(), cartAdadter.getmCartlist());
        return view;
    }



}