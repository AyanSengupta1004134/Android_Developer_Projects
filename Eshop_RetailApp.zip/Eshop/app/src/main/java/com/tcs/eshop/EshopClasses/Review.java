package com.tcs.eshop.EshopClasses;

import java.io.Serializable;

/**
 * Created by 986603 on 9/19/2015.
 */
public class Review implements Serializable{
    private int reviewid;
    private int customerId;
    private int productCode;
    private String userReview;

    public Review(int reviewid, int customerId, int productCode, String userReview) {
        this.reviewid = reviewid;
        this.customerId = customerId;
        this.productCode = productCode;
        this.userReview = userReview;
    }

    public Review(int customerId, int productCode, String userReview) {
        this.customerId = customerId;
        this.productCode = productCode;
        this.userReview = userReview;
    }

    public int getReviewid() {
        return reviewid;
    }

    public void setReviewid(int reviewid) {
        this.reviewid = reviewid;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getProductCode() {
        return productCode;
    }

    public void setProductCode(int productCode) {
        this.productCode = productCode;
    }

    public String getUserReview() {
        return userReview;
    }

    public void setUserReview(String userReview) {
        this.userReview = userReview;
    }

}
