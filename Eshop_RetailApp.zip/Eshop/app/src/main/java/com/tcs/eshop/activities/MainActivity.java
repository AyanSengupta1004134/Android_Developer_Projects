package com.tcs.eshop.activities;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.tcs.eshop.EshopClasses.Cart;
import com.tcs.eshop.EshopClasses.Customer;
import com.tcs.eshop.R;
import com.tcs.eshop.fragments.AdminFragment;
import com.tcs.eshop.fragments.CartFragment;
import com.tcs.eshop.fragments.CategoryFragment;
import com.tcs.eshop.fragments.ChangePassword;
import com.tcs.eshop.fragments.DetailsFragment;
import com.tcs.eshop.fragments.HomeFragment;
import com.tcs.eshop.fragments.LoginFragment;
import com.tcs.eshop.fragments.PaymentFragment;
import com.tcs.eshop.fragments.WishlistFragment;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.utilities.ApplicationConstant;
import com.tcs.eshop.utilities.ApplicationConstant.DataBaseConstant.CustomerTable;
import com.tcs.eshop.utilities.DatabaseCaller;
import com.tcs.eshop.utilities.LoginLogout;
import com.tcs.eshop.adapter.NavListAdapter;

import java.util.ArrayList;

/**
 * Main Activity class
 */
public class MainActivity extends AppCompatActivity {
Toolbar toolbar;
     DrawerLayout drawerLayout;
    ActionBarDrawerToggle mActionBarDrawerToggle;
    ListView mListView;
    TextView mNavTextView,mHomeNavText;
    TextView mCartText;
    String productCode;
    boolean isScanned=false;
    boolean mTablet=false;

    public TextView getmCartText() {
        return mCartText;
    }

    ArrayList<Customer> mCustomerList;
    ArrayList<Cart> mCartlist;
    ImageView mHomeNavImageView;
    Menu mainMenu;
    DatabaseCaller mDatabaseCaller;

    public Menu getMainMenu() {
        return mainMenu;
    }

    public boolean ismTablet() {
        return mTablet;
    }

    public TextView getmNavTextView() {
        return mNavTextView;
    }


    public ActionBarDrawerToggle getmActionBarDrawerToggle() {
        return mActionBarDrawerToggle;
    }

    ImageView mCartImage;
   public static MenuItem sMenuItem;
    EshopSqlHelper mEshopSqlHelper;
    String s[]={"Electronics","LifeStyle","Automotive","Home & Furniture","Books"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTablet=findDevice();
        mDatabaseCaller=new DatabaseCaller(this);
        toolbar= (Toolbar) findViewById(R.id.appBar);
        setSupportActionBar(toolbar);

       // drawerLayout= (DrawerLayout) findViewById(R.id.drawerLayout);
        mNavTextView=(TextView)findViewById(R.id.navUserId);
        mEshopSqlHelper=EshopSqlHelper.getInstance(this);
        mHomeNavText=(TextView)findViewById(R.id.navHomeLink);
        mHomeNavImageView= (ImageView) findViewById(R.id.homenavIcon);
        mHomeNavText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeFragment(HomeFragment.class, null, true, HomeFragment.class.getName());
                // getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new HomeFragment(), "home").addToBackStack(null).commit();
              if(!mTablet)
                drawerLayout.closeDrawers();
            }
        });
        mHomeNavImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeFragment(HomeFragment.class, null, true, HomeFragment.class.getName());
                // getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new HomeFragment(), "home").addToBackStack(null).commit();
                if(!mTablet)
                drawerLayout.closeDrawers();
            }
        });
        setUserName();
        //Setting drawyer if phone
        if(!mTablet) {
            initDrawer();
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setLogo(R.drawable.nav_logo_home);
            getSupportActionBar().setIcon(R.drawable.nav_logo_home);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

            mActionBarDrawerToggle.syncState();

        }
        mListView= (ListView) findViewById(R.id.listview);
        mListView.setDividerHeight(2);
      //mListView.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, s));
        mListView.setAdapter(new NavListAdapter(this, s));
                //mNavTextView.setText(getSharedPreferences("login", Context.MODE_PRIVATE).getString("userid", ""));
                mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        // getSupportActionBar().setTitle(s[i]);
                        //String category = s[i];
                        //Fragment fragment = new CategoryFragment();
                        Bundle bundle = new Bundle();
                        bundle.putString("category", s[i]);
                        //fragment.setArguments(bundle);
                        changeFragment(CategoryFragment.class, bundle, true, CategoryFragment.class.getName());
                        //getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, fragment, "category").addToBackStack("home").commit();
                        if(!mTablet)
                        drawerLayout.closeDrawers();
                    }
                });

        //getSupportActionBar().setLogo(R.drawable.nav_logo_home);
        //getSupportActionBar().setHomeAsUpIndicator(R.drawable.eshop_home_logo);
        if(!getIntent().getBooleanExtra("isNotified",false)) {
            changeFragment(HomeFragment.class,null,false,HomeFragment.class.getName());
            //getSupportFragmentManager().beginTransaction().add(R.id.framelayout, new HomeFragment(), "home").commit();
        }
        else
        {
            changeFragment(PaymentFragment.class, null, true,PaymentFragment.class.getName());

        //  getSupportFragmentManager().beginTransaction().add(R.id.framelayout, new PaymentFragment(), "payment").commit();

        }

        }
    public void getCartList()
    {
        mCartlist=mEshopSqlHelper.selectTableCartTable(ApplicationConstant.DataBaseConstant.CartTable.CART_CUSTOMER_NO+"=?",new String[]{String.valueOf(getCustomerId())});
    }
    public  int getCustomerId()
    {
        String userId=getSharedPreferences("login", Context.MODE_PRIVATE).getString("userid", "");
        if(!userId.equals("")) {
            mCustomerList = mEshopSqlHelper.getAllCustomer(ApplicationConstant.DataBaseConstant.CustomerTable.CUSTOMER_EMAIL_ID + "=? OR " + ApplicationConstant.DataBaseConstant.CustomerTable.CUSTOMER_PHONE_NO + "=?", new String[]{userId,userId});
            if (mCustomerList.size()>0)
            {
                return mCustomerList.get(0).getCustId();
            }
        }
        return -1;
    }
    public void setUserName()
    {
        String userId=getSharedPreferences("login", Context.MODE_PRIVATE).getString("userid", "");
        if(!userId.equals("")) {
            mCustomerList = mEshopSqlHelper.getAllCustomer(CustomerTable.CUSTOMER_EMAIL_ID + "=? OR " + CustomerTable.CUSTOMER_PHONE_NO + "=?", new String[]{userId,userId});
            if (mCustomerList.size()>0)
            {
               mNavTextView.setText("Hi "+mCustomerList.get(0).getFirstName());
            }
        }
    }
    public boolean findDevice()
    {
        boolean flag=false;
        try
        {
            drawerLayout= (DrawerLayout) findViewById(R.id.drawerLayout);
        }
        catch (Exception e)
        {
            flag=true;
        }
        if(drawerLayout==null)
            flag=true;
        return flag;
    }
    @Override
    protected void onResume() {
        super.onResume();

    }

    public void initDrawer()
{
    drawerLayout= (DrawerLayout) findViewById(R.id.drawerLayout);
    mActionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.drawer_open,R.string.drawer_close){

        @Override
        public void onDrawerOpened(View drawerView) {
            super.onDrawerOpened(drawerView);
          //  getSupportActionBar().setTitle("Opened");

        }

        @Override
        public void onDrawerClosed(View drawerView) {
            super.onDrawerClosed(drawerView);
            //getSupportActionBar().setTitle("Closed");
        }
    };
    toolbar.setNavigationOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            // Toast.makeText(MainActivity.this, "Innnnnnnnnn1", Toast.LENGTH_LONG).show();
            HomeFragment homeFragment = (HomeFragment) getSupportFragmentManager().findFragmentByTag(HomeFragment.class.getName());


            if (homeFragment != null && homeFragment.isVisible()) {
                if (drawerLayout.isDrawerOpen(Gravity.LEFT)) {
                    drawerLayout.closeDrawer(Gravity.LEFT);
                } else {
                    drawerLayout.openDrawer(Gravity.LEFT);
                }
            } else {
                onBackPressed();
            }

        }
    });

    drawerLayout.setDrawerListener(mActionBarDrawerToggle);
}
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        initMenu(menu);

        return true;
    }

    private void initMenu(Menu menu) {
        menu.findItem(R.id.myCartItem).setActionView(R.layout.menu_cart);
        View view=menu.findItem(R.id.myCartItem).getActionView();
        mCartImage= (ImageView) view.findViewById(R.id.userCartImage);
        mCartText= (TextView) view.findViewById(R.id.noOfCartItems);
        mCartImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!getSharedPreferences("login", Context.MODE_PRIVATE).getString("userid","").equals("")) {
                    changeFragment(CartFragment.class, null, true,CartFragment.class.getName() );
                    //getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new CartFragment(), "cart").addToBackStack("home").commit();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Login First", Toast.LENGTH_LONG).show();
                }
            }
        });
        mCartText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!getSharedPreferences("login",Context.MODE_PRIVATE).getString("userid","").equals("")) {
                    changeFragment(CartFragment.class, null, true, CartFragment.class.getName());

                    //getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new CartFragment(), "cart").addToBackStack("home").commit();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Login First",Toast.LENGTH_LONG).show();
                }
            }
        });
        sMenuItem= menu.findItem(R.id.myCartItem);
        if(!getSharedPreferences("login", Context.MODE_PRIVATE).getString("userid", "").equals(""))
        {
            setCartDetails();
            menu.findItem(R.id.logout).setVisible(true);
            menu.findItem(R.id.loginMenu).setVisible(false);
            menu.findItem(R.id.deleteAccount).setVisible(true);
            menu.findItem(R.id.changePassword).setVisible(true);

        }
        else
        {
            menu.findItem(R.id.loginMenu).setVisible(true);
            menu.findItem(R.id.logout).setVisible(false);
            menu.findItem(R.id.deleteAccount).setVisible(false);
            menu.findItem(R.id.changePassword).setVisible(false);



        }
        mainMenu=menu;
        menu.findItem(R.id.admin).setVisible(false);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        if(!mTablet)
        mActionBarDrawerToggle.syncState();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        /*int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }*/
       switch(item.getItemId())
       {

           case R.id.logout:
               if(!getSharedPreferences("login",Context.MODE_PRIVATE).getString("userid","").equals("")) {
                   AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

                   alertDialogBuilder.setTitle(R.string.logoutTitle).setMessage(R.string.looutContent).setIcon(R.drawable.logout_m);

                   alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                       @Override
                       public void onClick(DialogInterface arg0, int arg1) {
                          /* getSharedPreferences("login", MODE_PRIVATE).edit().clear().commit();
                           getSharedPreferences("payment", MODE_PRIVATE).edit().clear().commit();
                           mNavTextView.setText("");
                           mCartText.setText("0");*/
                           LoginLogout.setLogOutDetails(MainActivity.this);
                           changeFragment(LoginFragment.class, null, true, LoginFragment.class.getName());

                         //  getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new HomeFragment(), "home").addToBackStack("home").commit();


                       }
                   });

                   alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                       @Override
                       public void onClick(DialogInterface dialog, int which) {
                           //LoggedInFragment loggedInFragment=new LoggedInFragment();
                       }
                   });
                   AlertDialog alertDialog = alertDialogBuilder.create();
                   alertDialog.show();


               }
               break;
           case R.id.loginMenu:
               changeFragment(LoginFragment.class, null, true,LoginFragment.class.getName() );

               //getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new LoginFragment(), "login").addToBackStack("home").commit();


               break;
           case R.id.admin:
               getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new AdminFragment(), "admin").addToBackStack(null).commit();
               break;
           case R.id.myWishListItem:
               if(!getSharedPreferences("login",Context.MODE_PRIVATE).getString("userid","").equals("")) {
                   changeFragment(WishlistFragment.class, null, true,WishlistFragment.class.getName() );

                   //    getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new WishlistFragment(), "wishlist").addToBackStack(null).commit();
               }
               else
               {
                   Toast.makeText(this,"Login First",Toast.LENGTH_LONG).show();
               }
               break;
           case R.id.myCartItem:
               if(!getSharedPreferences("login",Context.MODE_PRIVATE).getString("userid","").equals("")) {
                   changeFragment(CartFragment.class, null, true,CartFragment.class.getName() );

                   // getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new CartFragment(), "cart").addToBackStack(null).commit();
               }
               else
               {
                   Toast.makeText(this,"Login First",Toast.LENGTH_LONG).show();
               }
               break;
           case R.id.deleteAccount:
               AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

               alertDialogBuilder.setTitle(R.string.deleteTitle ).setIcon(R.drawable.delete_icon).setMessage(R.string.DeleteContent);

               alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface arg0, int arg1) {
                      // Toast.makeText(MainActivity.this, R.string.yesSelection, Toast.LENGTH_LONG).show();
                       mEshopSqlHelper.deleteCustomer(getCustomerId());

                       if(!getSharedPreferences("login",Context.MODE_PRIVATE).getString("userid","").equals("")) {
                           LoginLogout.setLogOutDetails(MainActivity.this);
                           /*getmCartText().setText("0");
                           getSharedPreferences("login", MODE_PRIVATE).edit().clear().commit();
                           getSharedPreferences("payment", MODE_PRIVATE).edit().clear().commit();
                           mainMenu.findItem(R.id.loginMenu).setVisible(true);
                           mainMenu.findItem(R.id.logout).setVisible(false);
                           mainMenu.findItem(R.id.deleteAccount).setVisible(false);
                           mainMenu.findItem(R.id.changePassword).setVisible(false);*/
                       }
                       changeFragment(LoginFragment.class, null, true,LoginFragment.class.getName() );

                       //getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new LoginFragment()).addToBackStack("home").commit();

                   }
               });

               alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialog, int which) {
                       //LoggedInFragment loggedInFragment=new LoggedInFragment();
                   }
               });
               AlertDialog alertDialog = alertDialogBuilder.create();
               alertDialog.show();
               break;
           case R.id.changePassword:
               if(!getSharedPreferences("login",Context.MODE_PRIVATE).getString("userid","").equals("")) {
                   changeFragment(ChangePassword.class, null, true, ChangePassword.class.getName());

                  // getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new ChangePassword(), "chngpwd").addToBackStack("home").commit();

               }

               break;
           case R.id.exit:
               AlertDialog.Builder alertDialogBuilder1 = new AlertDialog.Builder(this);

               alertDialogBuilder1.setTitle("Exit!").setMessage("Do you really want to Exit?").setIcon(R.drawable.exit_icon);

               alertDialogBuilder1.setPositiveButton("yes", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface arg0, int arg1) {
                       finish();


                   }
               });

               alertDialogBuilder1.setNegativeButton("No", new DialogInterface.OnClickListener() {
                   @Override
                   public void onClick(DialogInterface dialog, int which) {
                   }
               });
               AlertDialog alertDialog1 = alertDialogBuilder1.create();
               alertDialog1.show();
               break;
           case R.id.scan:
               Intent intent = new Intent("com.google.zxing.client.android.SCAN");

               intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
                      // intent.putExtra("SCAN_MODE", "PRODUCT_MODE");
                      // intent.putExtra("SCAN_FORMATS", "CODE_39,CODE_93,CODE_128,DATA_MATRIX,ITF,CODABAR");
               startActivityForResult(intent, 0);
              break;


       }
        if(!mTablet) {
            if (mActionBarDrawerToggle.onOptionsItemSelected(item)) {

                return true;
            }
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Description:Used for setting card deatails
     */
    public void setCartDetails()
    {
        getCartList();
        if(mCustomerList.size()<=0)
        {
            mCartText.setText("0");

        }
        else
        mCartText.setText("" + mCartlist.size());
    }

    @Override
    public void onBackPressed() {
        HomeFragment homeFragment= (HomeFragment) getSupportFragmentManager().findFragmentByTag(HomeFragment.class.getName());
        LoginFragment loginFragment=(LoginFragment)getSupportFragmentManager().findFragmentByTag(LoginFragment.class.getName());
        if(homeFragment!=null&&homeFragment.isVisible())
        {
            Log.d("back", "home");
            getSupportFragmentManager().popBackStack(null,getSupportFragmentManager().POP_BACK_STACK_INCLUSIVE);
            finish();
        }
        else
            if(loginFragment!=null&&loginFragment.isVisible()) {
                getSupportFragmentManager().popBackStack(getSupportFragmentManager().getBackStackEntryAt(0).getName(),getSupportFragmentManager().POP_BACK_STACK_INCLUSIVE);

            }
        else {
            super.onBackPressed();
        }
        }

    @Override
    protected void onSaveInstanceState(Bundle outState) {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                productCode=(data.getStringExtra("SCAN_RESULT"));
                if(isNumeric(productCode)&&mDatabaseCaller.isProductExists(Integer.parseInt(productCode)))
                {
                    isScanned=true;
                    //showScanDetails(productCode);
                }
                else
                {
                    Toast.makeText(this,"Product Does not exists",Toast.LENGTH_LONG).show();
                }
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this,"Scan Cancelled",Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        if(isScanned)
        {
            showScanDetails(productCode);
            isScanned=false;
        }
    }

    private void showScanDetails(String productCode) {
        Fragment fragment=new DetailsFragment();
        Bundle bundle=new Bundle();
        bundle.putSerializable("object", mDatabaseCaller.getProduct(Integer.parseInt(productCode)));
        fragment.setArguments(bundle);
        //changeFragment(DetailsFragment.class, null, true,DetailsFragment.class.getName() );

        getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, fragment, DetailsFragment.class.getName()).addToBackStack(null).commitAllowingStateLoss();
    }
    public <T>void changeFragment(Class<T> fragmentClass,Bundle bundle,boolean isBackStack,String tag)
    {

        try {


            Fragment fragment=(Fragment)fragmentClass.newInstance();
            if(bundle!=null)
            {
                fragment.setArguments(bundle);
            }

            if (isBackStack) {
                getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, fragment, tag).addToBackStack(null).commit();

            } else {
                getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, fragment, tag).commit();
            }

        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public  boolean isNumeric(String str)
    {
        try
        {
            Integer d = Integer.parseInt(str);
        }
        catch(NumberFormatException nfe)
        {
            return false;
        }
        return true;
    }
}
