package com.tcs.eshop.fragments;

import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.utilities.ApplicationConstant;

import java.io.File;
import java.util.ArrayList;

/**
 * Created by 986719 on 9/16/2015.
 */
public class SwipeFragment2 extends Fragment {
    String mCategory;
    TextView mNameTextView1,mPriceTextView1,mNameTextView2,mPriceTextView2;
    ImageView mProductImageView1,mProductImageView2;
    ArrayList<Product> mProductArrayList;
    EshopSqlHelper mEshopSqlHelper;
    MainActivity mainActivity;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
        mEshopSqlHelper=EshopSqlHelper.getInstance(getActivity());
        mCategory=getArguments().getString("category");
        mProductArrayList=mEshopSqlHelper.selectTable(ApplicationConstant.DataBaseConstant.ProductTable.PRODUCT_CATEGORY+" =?",new String[]{mCategory});
    }



    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.swipe_fragment,container,false);
        initViews(view);
        if(mProductArrayList.size()>=4)
        {
            mNameTextView1.setText(mProductArrayList.get(2).getProductName());
            mNameTextView2.setText(mProductArrayList.get(3).getProductName());
            mPriceTextView1.setText(String.valueOf(mProductArrayList.get(2).getProductPrice()));
            mPriceTextView2.setText(String.valueOf(mProductArrayList.get(3).getProductPrice()));
            File folder =getActivity().getExternalFilesDir("contactimages");

            File file=new File(folder,mProductArrayList.get(2).getProductImagePath());
            Log.d("path", file.getAbsolutePath());
            mProductImageView1.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));

            file=new File(folder,mProductArrayList.get(3).getProductImagePath());
            Log.d("path", file.getAbsolutePath());
            mProductImageView2.setImageBitmap(BitmapFactory.decodeFile(file.getAbsolutePath()));
            setListener();


        }

        return view;
    }

    /**
     * Description: Used to set the listeners
     */
    private void setListener() {
        mProductImageView1.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                //Fragment fragment = new DetailsFragment();
                Bundle bundle = new Bundle();
                bundle.putSerializable("object", mProductArrayList.get(2));
                //fragment.setArguments(bundle);
                mainActivity.changeFragment(DetailsFragment.class, bundle, true, DetailsFragment.class.getName());

                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, fragment, "details").addToBackStack("home").commit();
            }
        });
        mProductImageView2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                //Fragment fragment=new DetailsFragment();
                Bundle bundle=new Bundle();
                bundle.putSerializable("object", mProductArrayList.get(3));
                //fragment.setArguments(bundle);
                mainActivity.changeFragment(DetailsFragment.class, bundle, true, DetailsFragment.class.getName());

                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout,fragment,"details").addToBackStack("home").commit();
            }
        });
    }

    /**
     * Description: Used for initialising the views
     * @param view: View
     */
    private void initViews(View view) {
        mNameTextView1= (TextView) view.findViewById(R.id.swipeNameText1);
        mNameTextView2= (TextView) view.findViewById(R.id.swipeNameText2);
        mPriceTextView1= (TextView) view.findViewById(R.id.swipePriceText1);
        mPriceTextView2= (TextView) view.findViewById(R.id.swipePriceText2);
        mProductImageView1= (ImageView) view.findViewById(R.id.swipeImage1);
        mProductImageView2= (ImageView) view.findViewById(R.id.swipeImage2);
    }
}
