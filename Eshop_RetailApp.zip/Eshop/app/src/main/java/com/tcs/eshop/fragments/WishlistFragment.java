package com.tcs.eshop.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.adapter.WishlistAdapter;

/**
 * Created by 986719 on 9/17/2015.
 */
public class WishlistFragment extends Fragment {
    ListView mWishListView;
     WishlistAdapter mWishlistAdapter;
    MainActivity mainActivity;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.wishlist_fragment,container,false);
        mWishListView= (ListView) view.findViewById(R.id.wishList);
        mWishlistAdapter=new WishlistAdapter(getActivity());
        mWishListView.setAdapter(mWishlistAdapter);
        mWishListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
               // Fragment fragment = new DetailsFragment();
                Bundle bundle = new Bundle();
                bundle.putSerializable("object", mWishlistAdapter.getmProductList().get(i));
                Toast.makeText(getActivity(), "Name=" + mWishlistAdapter.getmProductList().get(i).getProductName(), Toast.LENGTH_LONG).show();
                //fragment.setArguments(bundle);
                mainActivity.changeFragment(DetailsFragment.class, bundle, true, DetailsFragment.class.getName());

                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, fragment, "details").addToBackStack("wishlist").commit();
            }
        });
        return view;
    }
}
