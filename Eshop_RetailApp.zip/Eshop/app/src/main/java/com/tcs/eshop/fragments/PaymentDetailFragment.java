package com.tcs.eshop.fragments;


import android.app.AlertDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.tcs.eshop.EshopClasses.Cart;
import com.tcs.eshop.EshopClasses.Payment;
import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.R;
import com.tcs.eshop.activities.MainActivity;
import com.tcs.eshop.database.EshopSqlHelper;
import com.tcs.eshop.adapter.CardDetailsAdapter;
import com.tcs.eshop.utilities.DatabaseCaller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by 962609 on 9/21/2015.
 */
public class PaymentDetailFragment extends Fragment implements View.OnClickListener {
    ListView mCardListView;
    EditText mEditTextCardNo;
    EditText mEditTextMonth;
    EditText mEditTextYear;
    EditText mEditTextCvv;
    Bundle bundle;
    String mCardType;
    String mCardNumber;
    String mExpiryMonth;
    String mExpiryYear;
    Calendar mCalender = Calendar.getInstance();
    int currMonth= mCalender.get(Calendar.MONTH);
    int currYear=mCalender.get(Calendar.YEAR);
    Button mButPayNow;
    Payment mPayment;
    EshopSqlHelper mEshopSqlHelper;
    CheckBox mCheckBox;
    Context mContext;
    int mCustId;
    DatabaseCaller mDatabaseCaller;
    MainActivity mainActivity;
    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainActivity= (MainActivity) getActivity();
        mEshopSqlHelper=EshopSqlHelper.getInstance(getActivity());
        bundle=getArguments();
        mDatabaseCaller=new DatabaseCaller((MainActivity)getActivity());
        mCustId=getActivity().getSharedPreferences("login", Context.MODE_PRIVATE).getInt("custId", -1);
        mCardType=bundle.getString("Card Type");


    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.payment_detail_layout, container, false);
        initViews(container, view);

        return  view;
    }

    /**
     * Description: Used for initialising the views
     * @param container :viewgroop
     * @param view: view
     */
    private void initViews(ViewGroup container, View view) {
        mContext=container.getContext();
        mCardListView= (ListView) view.findViewById(R.id.paymentcardListView);


        LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mCardListView.addFooterView(layoutInflater.inflate(R.layout.payment_details_footer, null, false));
        final CardDetailsAdapter cardDetailsAdapter=new CardDetailsAdapter(getActivity(),mCardType);
        //    mCardListView.setAdapter(new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, mCardNoList));
        mCardListView.setAdapter(cardDetailsAdapter);
        mCardListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                mEditTextCardNo.setText(cardDetailsAdapter.mpaymentArrayList.get(i).getCardNumber());
                mEditTextMonth.setText(cardDetailsAdapter.mpaymentArrayList.get(i).getExpiryMonth());
                mEditTextYear.setText(cardDetailsAdapter.mpaymentArrayList.get(i).getExpiryYear());
            }
        });

        mEditTextCardNo=(EditText)view.findViewById(R.id.editText_card_no);
        mEditTextMonth=(EditText)view.findViewById(R.id.editText_month);
        mEditTextYear=(EditText)view.findViewById(R.id.editText_year);
        mEditTextCvv=(EditText)view.findViewById(R.id.editText_cvv);
        mCheckBox=(CheckBox)view.findViewById(R.id.checkBox1);
        Log.d("Card type", mCardType);
        mButPayNow=(Button)view.findViewById(R.id.button_pay_now);
        mButPayNow.setOnClickListener(this);


        mCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // checkbox status is changed from uncheck to checked.

            }
        });
    }


    public static boolean isNumeric(String str)
    {
        try
        {
            double d = Double.parseDouble(str);
        }
        catch(NumberFormatException nfe)
        {
            return false;
        }
        return true;
    }

    public boolean isValidNo(String number) {
        String CARD_NUMBER_PATTERN = "\\d{16}";
        Pattern pattern = Pattern.compile(CARD_NUMBER_PATTERN);
        Matcher matcher = pattern.matcher(number);
        return matcher.matches();
    }
    public boolean isValidExpiry(String month,String year)
    {
        boolean flag=false;
        Log.d("current month",""+currMonth);
        Log.d("year",""+currYear);

        if(Integer.parseInt(month)<currMonth&&Integer.parseInt(year)>currYear&&Integer.parseInt(month)>0&&Integer.parseInt(month)<13)

        {
            flag=true;

        }
        else if(Integer.parseInt(month)>currMonth&&Integer.parseInt(year)>=currYear&&Integer.parseInt(month)>0&&Integer.parseInt(month)<13) {

            flag = true;

    }
        else
            {
                flag=false;
            }


        return  flag;
    }

    public boolean isValidCVV(String ccv) {
        String CVV_PATTERN = "\\d{3}";
        Pattern pattern = Pattern.compile(CVV_PATTERN);
        Matcher matcher = pattern.matcher(ccv);
        return matcher.matches();

    }
    public boolean isValidCardNo(String number) {
        String CARD_NUMBER_PATTERN = "\\d{16}";
        Pattern pattern = Pattern.compile(CARD_NUMBER_PATTERN);
        Matcher matcher = pattern.matcher(number);
        return matcher.matches();
    }
    private boolean isValidYear(String year) {
        String CARD_NUMBER_PATTERN = "\\d{4}";
        Pattern pattern = Pattern.compile(CARD_NUMBER_PATTERN);
        Matcher matcher = pattern.matcher(year);
        return matcher.matches();

    }

    private boolean isValidMonth(String month) {
        String CARD_NUMBER_PATTERN = "\\d{2}";
        Pattern pattern = Pattern.compile(CARD_NUMBER_PATTERN);
        Matcher matcher = pattern.matcher(month);
        return matcher.matches();

    }

    @Override
    public void onClick(View v) {

        if (mEditTextCardNo.getText().toString().isEmpty())
        {
            mEditTextCardNo.setError(getString(R.string.Mandatory));
        } else if (!isNumeric(mEditTextCardNo.getText().toString()))
        {
            mEditTextCardNo.setError(getString(R.string.numericField));
        } else if (!isValidCardNo(mEditTextCardNo.getText().toString()))
        {
            mEditTextCardNo.setError(getString(R.string.cardNoDigits));
        }

        else if (mEditTextMonth.getText().toString().isEmpty()) {
            mEditTextMonth.setError(getString(R.string.Mandatory));
        } else if (!isNumeric(mEditTextMonth.getText().toString())) {
            mEditTextMonth.setError(getString(R.string.monthsNumeric));
        } else if (!isValidMonth(mEditTextMonth.getText().toString())) {
            mEditTextMonth.setError(getString(R.string.monthDigitCheck));
        }

        else if (mEditTextYear.getText().toString().isEmpty()) {
            mEditTextYear.setError(getString(R.string.Mandatory));
        }
        else if (!isNumeric(mEditTextYear.getText().toString())) {
            mEditTextYear.setError(getString(R.string.yearNumeric));
        }
        else if (!isValidYear(mEditTextYear.getText().toString())) {
            mEditTextYear.setError(getString(R.string.yearDigits));
        }
        else if (mEditTextCvv.getText().toString().isEmpty()) {
            mEditTextCvv.setError(getString(R.string.Mandatory));
        }
        else if (!isNumeric(mEditTextCvv.getText().toString())) {
            mEditTextCvv.setError(getString(R.string.cvvNumeric));
        }
        else if(!isValidCVV(mEditTextCvv.getText().toString()))
        {
            mEditTextCvv.setError(getString(R.string.cvvDigits));
        }

        else if(!isValidExpiry(mEditTextMonth.getText().toString(),mEditTextYear.getText().toString()))
        {
            mEditTextMonth.setError("invalid expiry details");
        }
        else
        {
            if(isConnected()) {
                if (mCheckBox.isChecked()) {
                    mCardNumber = mEditTextCardNo.getText().toString();
                    mExpiryMonth = mEditTextMonth.getText().toString();
                    mExpiryYear = mEditTextYear.getText().toString();


                    Log.d("Customer ID", "" +mCustId);
                    mPayment = new Payment(mCustId, mCardNumber, mCardType, mExpiryMonth, mExpiryYear);
                    Log.d("card no", mCardNumber);
                    mEshopSqlHelper.insertPaymentDetail(mPayment);

                  //  Toast.makeText(mContext, R.string.cardSaved, Toast.LENGTH_SHORT).show();

                } else {
                    // hide password
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

// set title
                    alertDialogBuilder.setTitle("Payment");

// set dialog message
                    alertDialogBuilder.setMessage("Payment Successfull thanks for shoping ").setCancelable(true);

// create alert dialog
                    AlertDialog alertDialog = alertDialogBuilder.create();

// show it
                    alertDialog.setCanceledOnTouchOutside(true);
                    alertDialog.show();

                    //Toast.makeText(mContext, R.string.shopping, Toast.LENGTH_SHORT).show();
                }
                makeDispatch();
                mainActivity.changeFragment(HomeFragment.class, null, true, HomeFragment.class.getName());

                //getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.framelayout, new HomeFragment(), "home").addToBackStack(null).commit();

            }
            else
            {
                getActivity().getSharedPreferences("payment", Context.MODE_PRIVATE).edit().putString("pay","yes").commit();
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());

// set title
                alertDialogBuilder.setTitle("Payment").setIcon(R.drawable.network_check);

// set dialog message
                alertDialogBuilder.setMessage("Payment Failure No Network Available").setCancelable(true);

// create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

// show it
                alertDialog.setCanceledOnTouchOutside(true);
                alertDialog.show();

// After some action

                //Toast.makeText(mContext, R.string.noNetwork, Toast.LENGTH_SHORT).show();

            }

        }

    }

    /**
     * Description: Used for checking the network connection
     * @return: boolean result
     */
    public boolean isConnected()
    {
        ConnectivityManager cm =
                (ConnectivityManager)getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();

    }

    /**
     * Description: Used for updating cart and product quantities
     */
    public void makeDispatch() {
        Product mProduct;
        ArrayList<Cart> cartArrayList = mDatabaseCaller.getCartList(mCustId);
        for(Cart c:cartArrayList)
        {
            mProduct=mDatabaseCaller.getProduct(c.getProductCode());
            mDatabaseCaller.updateProductNoOfItems(mProduct.getProductQtyAvailable() - c.getNoOfItems(), c.getProductCode());
           mDatabaseCaller.deleteCartItems(mCustId, c.getProductCode());
        }
        MainActivity mainActivity= (MainActivity) getActivity();

        mainActivity.getmCartText().setText("0");

    }
}
