package com.tcs.eshop.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import com.tcs.eshop.*;
import com.tcs.eshop.EshopClasses.Product;
import com.tcs.eshop.database.EshopSqlHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by 963693 on 9/15/2015.
 */
public class Splash extends Activity{
    EshopSqlHelper mEshopSqlHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);
        mEshopSqlHelper=EshopSqlHelper.getInstance(this);
        if(mEshopSqlHelper.getRowCount(null,null)<=0) {

            jsonparser();
        }
        new Timer().schedule(new TimerTask(){

            public void run()
            {
                Intent i=new Intent(Splash.this, MainActivity.class);
                startActivity(i);
                finish();
            }},2000);

    }
    public String readjsonfile() {
        StringBuilder builder = new StringBuilder();
        File file = new File(Environment.getExternalStorageDirectory(),"jason_file.txt");
        Log.d("dir", "dir " + Environment.getExternalStorageDirectory());
        if (file.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line;
                while ((line = br.readLine()) != null) {
                    builder.append(line);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return builder.toString();

    }
    public void jsonparser() {
        String strJson = readjsonfile();
        String name,category,subcategory,imagePath,description;
        int price,productQtyAvailable;
        String data = "";
        try {
            Log.d("json",data);
            JSONObject jsonRootObject = new JSONObject(strJson);

            //Get the instance of JSONArray that contains JSONObjects
            JSONArray jsonArray = jsonRootObject.optJSONArray("Product");

            //Iterate the jsonArray and print the info of JSONObjects
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                name = jsonObject.optString("productName");
                category = jsonObject.optString("productCategory");
                subcategory = jsonObject.optString("productSubCategory");

                price= jsonObject.optInt("productPrice");
                imagePath = jsonObject.optString("productImagePath").toString();
                productQtyAvailable = jsonObject.optInt("productQtyAvailable");
                description= jsonObject.optString("description").toString();
                mEshopSqlHelper.insertTable(new Product(name, category, subcategory, price, imagePath, productQtyAvailable, description));
                //data =data+"\n"+ "productName:" + name + " productCategory:" + category + " productSubCategory:" + subcategory + " productPrice:" + price + " productImagePath:" + imagePath + " productQtyAvailable:" + productQtyAvailable+" description:"+description+"\n";
                Log.d("insert no=", "" + i);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


}
