package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import tcs.com.bankingsystem.Activity.Bk_FragmentContainer;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;


/**
 * Created by DELL LEAP on 9/16/2015.
 */
public class Bk_ChangePassword extends Fragment implements View.OnFocusChangeListener, View.OnClickListener{
  private EditText et_oldPassword,et_newPassword,et_confirmPassword;
   private TextView et_custId;
   private Button bChange,bCancel;
   private dbHandler mdbHandler;
   private Long id;
   private Context context;
   private Long custId;
   private Bundle bundle;
    public static boolean flag=false;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.bk_change_password,container,false);
        initializeView(view);
        listenerSetUp();
        context=container.getContext();
        mdbHandler=new dbHandler(context);
        custId = getCustomerIdFromBundle();
        Log.d("ChangePasswordCust", custId + "");
        et_custId.setText(custId + "");
        return view;

    }

    public void onFocusChange(View v, boolean hasFocus) {
        switch(v.getId()){
            case R.id.et_NewPassword:
                if(hasFocus) {
                    if (et_oldPassword.getText().toString().isEmpty())
                        et_oldPassword.setError("Enter Old Password");
                }
                break;
            case R.id.et_ConfirmPassword_ChangePassword:
                if(hasFocus) {

                    if (et_oldPassword.getText().toString().isEmpty())
                        et_oldPassword.setError("Enter Old Password");
                    else if (et_newPassword.getText().toString().length() < 8)
                        et_newPassword.setError("Password Too Short");
                    else if (et_newPassword.getText().toString().isEmpty())
                        et_newPassword.setError("Enter New Password");
                }
                break;
        }
    }

    public void onClick(View v) {
        switch(v.getId()){
            case R.id.b_changePassword:
                if(et_oldPassword.getText().toString().isEmpty())
                    et_oldPassword.setError("Enter Old Password");
                else if(et_newPassword.getText().toString().isEmpty())
                    et_newPassword.setError("Enter New Password");
                else if (et_newPassword.getText().toString().length() < 8)
                    et_newPassword.setError("Password Too Short");
                else if(!et_newPassword.getText().toString().equals(et_confirmPassword.getText().toString()))
                    et_confirmPassword.setError("Passwords do not match");
                else if(!mdbHandler.checkCustomer(custId,et_oldPassword.getText().toString()))
                    et_oldPassword.setError("Enter Correct Old Password");
                else{
                    mdbHandler.updatePassword(custId, et_newPassword.getText().toString());
                    Toast.makeText(context, "Password Changed Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(getActivity(),Bk_FragmentContainer.class);
                    getActivity().finish();
                    startActivity(intent);
                }
                break;
            case R.id.b_Cancel_ChangePassword:
                    Bk_Home homeFrag=new Bk_Home();
                homeFrag.setArguments(bundle);
                    getFragmentManager().beginTransaction().replace(R.id.container,homeFrag).addToBackStack(null).commit();
                break;
        }
    }
    public static boolean isNumeric(String str) {
        int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (Character.isDigit(str.charAt(i)) == false) {
                return false;
            }
        }
        return true;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        flag=true;
    }

    public void onDestroy() {
        super.onDestroy();
        flag=false;
    }

    public void onPause() {
        super.onPause();
        Log.d("onPause", "checking");
        flag=false;
    }

    public void onResume() {
        super.onResume();
        Log.d("onResume", "checking");
        flag=true;

    }
    public void initializeView(View view)
    {
        et_custId=(TextView) view.findViewById(R.id.tv_custId_ChangePassword);

        et_oldPassword=(EditText) view.findViewById(R.id.et_OldPassword);
        et_newPassword=(EditText) view.findViewById(R.id.et_NewPassword);
        et_confirmPassword=(EditText) view.findViewById(R.id.et_ConfirmPassword_ChangePassword);
        bChange=(Button) view.findViewById(R.id.b_changePassword);
        bCancel= (Button) view.findViewById(R.id.b_Cancel_ChangePassword);
    }
    public void listenerSetUp()
    {
        et_oldPassword.setOnFocusChangeListener(this);
        et_newPassword.setOnFocusChangeListener(this);
        et_confirmPassword.setOnFocusChangeListener(this);
        bChange.setOnClickListener(this);
        bCancel.setOnClickListener(this);
    }
   public long getCustomerIdFromBundle()
    {
        bundle =new Bundle();
        bundle=getArguments();
        custId=bundle.getLong("customer id");
        return custId;
    }
}
