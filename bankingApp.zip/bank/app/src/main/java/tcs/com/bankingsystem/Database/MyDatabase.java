package tcs.com.bankingsystem.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by 963691 on 9/16/2015.
 */
public class MyDatabase extends SQLiteOpenHelper {
    Context context;

    private static final String CUSTOMER_TABLE_NAME="CUSTOMER";
    private static final String CUSTOMERID="CUSTOMERID";
    private static final String PASSWORD="PASSWORD";
    private static final String SECURITY_QUESTION="SECURITY_QUESTION";
    private static final String SECURITY_ANSWER="SECURITY_ANSWER";
    private static final String CREATE_CUSTOMER_TABLE="create table "+CUSTOMER_TABLE_NAME+" ("+CUSTOMERID+" INTEGER PRIMARY KEY ,"+PASSWORD+"  varchar(255) ,"+SECURITY_QUESTION+" varchar(255) ,"+SECURITY_ANSWER+" varchar(255))";
    private static final String DROP_CUSTOMER_TABLE="DROP TABLE IF EXISTS "+CUSTOMER_TABLE_NAME;
                            /*BENEFICIARY*/
    private static final String BENEFICIARY_TABLE_NAME="BENEFICIARY";
    private static final String CUSTOMER_ID="ID";
    private static final String BENEFICIARY_NAME="NAME";
    private static final String BENEFICIARY_ACCNO="ACCNO";
    private static final String BENEFICIARY_BRANCH="BRANCH";
    private static final String BENEFICIARY_EMAIL="EMAIL";
    private static final String DROP_BENEFICIARY_TABLE="DROP TABLE IF EXISTS "+BENEFICIARY_TABLE_NAME;
                        /*TRANSACTION*/
   private static final String TRANS_TABLE="TRANS";
    private static final String TRANS_ID="TRANS_ID";
   private static final String TRANS_DATE="TRANS_DATE";
   private static final String TRANS_AMOUNT="AMOUNT";
    private static final String IS_STARMARK="STAR";
    private static final String TRANS_ACCT_NO="ACCOUNT_NO";
   private static final String CUSTOMER_ID_TRANS="CUSTOMER_ID";
    private static final String TRANS_DESCRIPTION="DESCRIPTION";
   private static final String DROP_TRANS_TABLE="DROP TABLE IF EXISTS "+TRANS_TABLE;
                        /* FOREX TABLE*/
    private static final String FOREX_TABLE="FOREX";
    private static final String FOREX_ID="ID";
    private static final String CURRENCY_PAIR="PAIR";
    private static final String FOREX_RATES="RATES";
    private static final String FOREX_CUST_ID="CUSTOMER_ID";
    private static final String DROP_FORX_TABLE="DROP TABLE IF EXISTS "+FOREX_TABLE;
                        /*FOREX VIEW*/
    private static final String FOREX_VIEW_TABLE="FOREXVIEW";
    private static final String VIEW_TABLE_CUSTID="CUSTID";
    private static final String VIEW_CURRENCY_PAIR="PAIR";
    private static final String VIEW_FOREX_DATE="DATETIME";
    private static final String DROP_VIEW_FORX_TABLE="DROP TABLE IF EXISTS "+FOREX_VIEW_TABLE;
                        /*FOREX_FAV*/
    private static final String FOREX_FAV_TABLE="FOREXFAV";
    private static final String VIEW_FAV_CUSTID="CUSTID";
    private static final String FAV_CURRENCY_PAIR="PAIR";
    private static final String FAV_FOREX_DATE="DATETIME";
    private static final String DROP_FAV_FORX_TABLE="DROP TABLE IF EXISTS "+FOREX_FAV_TABLE;

    public MyDatabase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {

        super(context, name, factory, version);
        this.context=context;
    }

    private static final String CREATE_BENEFICIARY="CREATE TABLE " + BENEFICIARY_TABLE_NAME + " ("
            + CUSTOMER_ID + " INTEGER, "
            + BENEFICIARY_NAME + " TEXT,"
            + BENEFICIARY_ACCNO + " TEXT,"
            +BENEFICIARY_EMAIL + " TEXT,"
            + BENEFICIARY_BRANCH + " TEXT "
            +  ")";


    private static final String CREATE_TRANS_TABLE="create table " + TRANS_TABLE + "("
            + TRANS_ID + " INTEGER PRIMARY KEY,"
            + TRANS_DATE + " varchar(255),"
            + TRANS_DESCRIPTION + " varchar(255),"
            + TRANS_AMOUNT + " varchar(255),"
            + IS_STARMARK + " varchar(255),"
            +CUSTOMER_ID_TRANS +" INTEGER,"
            + TRANS_ACCT_NO + " varchar(255)"

            + ")";

    private static final String CREATE_FOREX_TABLE="create table " + FOREX_TABLE + "("
            + FOREX_ID + " INTEGER AUTOINCREMENTED,"
            + CURRENCY_PAIR + " varchar(255),"
            + FOREX_RATES + " varchar(255),"
            + FOREX_CUST_ID + " INTEGER"

            + ")";


    private static final String CREATE_FAV_FOREX_TABLE="create table " + FOREX_FAV_TABLE + "("
            + VIEW_FAV_CUSTID + " INTEGER,"
            + FAV_CURRENCY_PAIR + " varchar(255),"
            + FAV_FOREX_DATE + " varchar(255), "
            + "PRIMARY KEY"+"("+VIEW_FAV_CUSTID+","+FAV_CURRENCY_PAIR+")"
            + ")";

    private static final String CREATE_VIEW_FOREX_TABLE="create table " + FOREX_VIEW_TABLE + "("
            + VIEW_TABLE_CUSTID + " INTEGER,"
            + VIEW_CURRENCY_PAIR + " varchar(255),"
            + VIEW_FOREX_DATE + " varchar(255), "
            + "PRIMARY KEY"+"("+VIEW_TABLE_CUSTID+","+VIEW_CURRENCY_PAIR+")"
            + ")";

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("onCreate", "checking");
        db.execSQL(CREATE_CUSTOMER_TABLE);
        Log.d("onCreate", "checking1");
        db.execSQL(CREATE_BENEFICIARY);
        Log.d("onCreate", "checking3");
        db.execSQL(CREATE_TRANS_TABLE);
        Log.d("tRANS", "checking4");
        db.execSQL(CREATE_FOREX_TABLE);
         Toast.makeText(context, "FOREX table created", Toast.LENGTH_LONG).show();
        db.execSQL(CREATE_VIEW_FOREX_TABLE);
        Toast.makeText(context,"VIEW table created",Toast.LENGTH_LONG).show();

        db.execSQL(CREATE_FAV_FOREX_TABLE);
        Toast.makeText(context,"fav table created",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if(newVersion>oldVersion){
            db.execSQL(DROP_CUSTOMER_TABLE);
            db.execSQL(DROP_BENEFICIARY_TABLE);
            db.execSQL(DROP_TRANS_TABLE);
            db.execSQL(DROP_FORX_TABLE);
            db.execSQL(DROP_VIEW_FORX_TABLE);
            db.execSQL(DROP_FAV_FORX_TABLE);
            Log.d("ONUPDATE", "checking4");
            onCreate(db);
        }
    }

}
