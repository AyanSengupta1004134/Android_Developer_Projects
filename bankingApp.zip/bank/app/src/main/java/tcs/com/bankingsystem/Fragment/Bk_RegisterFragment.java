package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;

import java.io.IOException;

import tcs.com.bankingsystem.Activity.Bk_FragmentContainer;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;
import tcs.com.bankingsystem.Utilities.JSonReader;

/**
 * Created by 963691 on 9/16/2015.
 */
public class Bk_RegisterFragment extends Fragment implements View.OnClickListener {
   private EditText et_custId,et_password,et_confirmPassword,et_security_answer;
   private Spinner security_spinner;
   private Button bRegister;
   private dbHandler mdbHandler;
   private Context context;
   private String securityQuestion,securityAnswer;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.bk_register_customer,container,false);
        initializeView(view);
        mdbHandler=new dbHandler(container.getContext());
        context=container.getContext();
        setOnFocusValidation();
        bRegister.setOnClickListener(this);
        getActivity().setTitle("Register Here");
        Bk_FragmentContainer.flag=2;
        return view;
    }

    public void onClick(View v) {

        registration();
    }
    public static boolean isNumeric(String str) {
        if (str == null) {
            return false;
        }
        int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (Character.isDigit(str.charAt(i)) == false) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void onDestroy() {
        Bk_FragmentContainer.flag=1;
        super.onDestroy();

    }
    public void initializeView(View view)
    {
        et_custId= (EditText) view.findViewById(R.id.eCustomerId);
        et_password=(EditText) view.findViewById(R.id.ePassword);
        et_confirmPassword=(EditText) view.findViewById(R.id.eConfirmPassword);
        et_security_answer=(EditText)view.findViewById(R.id.security_answer_register_page);
        security_spinner=(Spinner)view.findViewById(R.id.spinner_register_page);
        bRegister=(Button) view.findViewById(R.id.bRegister);
    }
    public void setOnFocusValidation()
    {
        et_password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    Long Id=0L;
                    if(!et_custId.getText().toString().isEmpty()&&isNumeric(et_custId.getText().toString()))
                        Id=Long.parseLong(et_custId.getText().toString());
                    if(et_custId.getText().toString().isEmpty())
                        et_custId.setError("Enter Id First");
                    else if(!isNumeric(et_custId.getText().toString()))
                        et_custId.setError("Enter Numeric Customer Id");
                    else if(mdbHandler.isCustIdAlreadyRegistered(Id))
                        et_custId.setError("Customer ID already Registered.Go to Login Page");
                }
            }
        });

        et_confirmPassword.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    Long Id=0L;
                    if(et_custId.getText().toString().isEmpty())
                        et_custId.setError("Enter Customer Id ");
                    else if(!isNumeric(et_custId.getText().toString()))
                        et_custId.setError("Enter Numeric Customer Id");
                    else
                        Id=Long.parseLong(et_custId.getText().toString());
                    if(et_password.getText().toString().isEmpty())
                        et_password.setError("Enter Password");
                    else if(et_password.getText().toString().length()<8)
                        et_password.setError("Password Too Short");
                    else if(mdbHandler.isCustIdAlreadyRegistered(Id))
                        et_custId.setError("Customer ID already Registered.Go to Login Page");
                }
            }
        });
    }
    public void registration()
    {
        String id =et_custId.getText().toString();
        String password=et_password.getText().toString();
        String conFirmPassword=et_confirmPassword.getText().toString();
        securityQuestion =String.valueOf(security_spinner.getSelectedItem());
        securityAnswer=et_security_answer.getText().toString();
        Long custId=0L;
        if(!id.isEmpty()&&isNumeric(id))
            custId=Long.parseLong(id);
        if(id.isEmpty())
            et_custId.setError("Enter Customer Id ");
        else if(!isNumeric(id)) {
            et_custId.setError("Enter Numeric Customer Id");
        }
        else if(et_password.getText().toString().isEmpty())
            et_password.setError("Enter Password");
        else if(et_password.getText().toString().length()<8)
            et_password.setError("Password Too Short");
        else if(!password.equals(conFirmPassword))
            et_confirmPassword.setError("Passwords do not match");
        else {
            try {
                if (!JSonReader.checkAccount(custId))
                    et_custId.setError("Customer Id not valid..");
                else {
                    if (mdbHandler.isCustIdAlreadyRegistered(custId)) {
                        et_custId.setError("Customer ID already Registered.Go to Login Page");
                        et_password.setText("");
                        et_confirmPassword.setText("");
                    } else {
                        mdbHandler.registerCustomer(custId, password, securityQuestion, securityAnswer);
                        Toast.makeText(context, "Registered Successfully", Toast.LENGTH_SHORT).show();
                        Bk_login login = new Bk_login();
                        getFragmentManager().beginTransaction().replace(R.id.framelayout, login).commit();
                    }
                }
            } catch (IOException e) {
                Toast.makeText(context,"Error...Can't Connect to Server..Try Again",Toast.LENGTH_LONG).show();
                et_custId.setText("");
                et_password.setText("");
                et_confirmPassword.setText("");
                et_security_answer.setText("");
                e.printStackTrace();
            } catch (JSONException e) {
                Toast.makeText(context,"Error...Can't Connect to Server..Try Again",Toast.LENGTH_LONG).show();
                et_custId.setText("");
                et_password.setText("");
                et_confirmPassword.setText("");
                et_security_answer.setText("");
                e.printStackTrace();
            }

        }
    }
}
