package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.Adapter.beneficiary_adapter;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;
import tcs.com.bankingsystem.Beans.beneficiary_class;

/**
 * Created by 963691 on 9/17/2015.
 */
public class Bk_bene_frag extends Fragment  {
    private Context context;
    private ListView lv;
    private dbHandler mdbHandler;
    private beneficiary_class bene;
    private ArrayList<beneficiary_class> bene_list;
    private Bundle bundle;
    private beneficiary_adapter mAdapter;
    private Long custId;
    public static boolean flag=false;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bk_layout_bene_list,null);
        bundleSetup();
        context=container.getContext();
        beneficiaryListviewSetup(view);
        return view;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        flag=true;
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_bene_list, menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.add_bene_menu) {
            Bk_add_beneficiary addBeneficiary = new Bk_add_beneficiary();
            addBeneficiary.setArguments(bundle);
            getFragmentManager().beginTransaction().replace(R.id.container, addBeneficiary).addToBackStack(null).commit();
        }
            return super.onOptionsItemSelected(item);

    }
    public void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy","checking");
        flag=false;
    }

    public void onPause() {
        super.onPause();
        Log.d("onPause", "checking");
        flag=false;
    }

    public void onResume() {
        super.onResume();
        Log.d("onResume", "checking");
        flag=true;

    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Beneficiary");
        Bk_Containt.title="Beneficiary";
    }
    public void bundleSetup()
    {
        bundle=getArguments();
        custId=bundle.getLong("customer id");
        Log.d("bk_bene",custId+"");
    }
    public void beneficiaryListviewSetup(View view)
    {
        lv = (ListView) view.findViewById(R.id.listView);
        mdbHandler=new dbHandler(context);
        bene_list=new ArrayList<beneficiary_class>();
        bene_list = mdbHandler.readAllbeneficiaries(custId);
        mAdapter=new beneficiary_adapter(context,bene_list);
        lv.setAdapter(mAdapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Bk_Edit_bene frag = new Bk_Edit_bene();
                Bundle bundle = new Bundle();
                bundle.putLong("customer id",custId);
                bundle.putSerializable("beneficiary", bene_list.get(position));
                frag.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.container,frag).addToBackStack(null).commit();
            }
        });
    }
}
