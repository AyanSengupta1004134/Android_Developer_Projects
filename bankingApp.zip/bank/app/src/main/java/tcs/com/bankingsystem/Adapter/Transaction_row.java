package tcs.com.bankingsystem.Adapter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

import tcs.com.bankingsystem.Beans.Transaction;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.Fragment.Bk_TransactionFragment;
import tcs.com.bankingsystem.Fragment.Bk_Transaction_list;
import tcs.com.bankingsystem.R;

/*
	set the single row for star transaction list
 */
public class Transaction_row extends BaseAdapter {
	private Context mcontext;
	private dbHandler dbhandler;
	private int custId;
	private ArrayList<Transaction> translist;
	public Transaction_row(Context context,int custId) {
		translist=new ArrayList<Transaction>();
		mcontext=context;
		this.custId=custId;
		dbhandler=new dbHandler(mcontext);
		translist= Bk_Transaction_list.translist;
	}

	public int getCount() {

		return translist.size();
	}


	public Object getItem(int i) {

		return translist.get(i);
	}


	public long getItemId(int arg0) {

		return 0;
	}


	public View getView(int i, View arg1, ViewGroup viewGroup) {

		    LayoutInflater inflater=(LayoutInflater)mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	        View row=inflater.inflate(R.layout.bk_transaction_row,viewGroup,false) ;
	        TextView trans_id=(TextView)row.findViewById(R.id.trans_id);
	        TextView trans_date=(TextView)row.findViewById(R.id.trans_date);
	        ImageButton img=(ImageButton)row.findViewById(R.id.imageView1);
	        
	        final Transaction temp=translist.get(i);
		if(temp.getStar().equals("false")) {
			//img.setImageResource(R.drawable.star_none);
			img.setImageResource(android.R.drawable.btn_star_big_off);

		}
		else {
			img.setImageResource(android.R.drawable.btn_star_big_on);

		}
		trans_id.setText(temp.getId());

		trans_date.setText(temp.getDate());

		img.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
			dbhandler.updatestardata(temp.getId());
			Bk_TransactionFragment list= new Bk_TransactionFragment();
			Bundle b=new Bundle();
			b.putLong("customer id",custId);
			list.setArguments(b);
			((Activity) mcontext).getFragmentManager().beginTransaction().replace(R.id.listframelayout, list).commit();
			}
		});
	        return row;
	}

}
