package tcs.com.bankingsystem.Activity;

import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import tcs.com.bankingsystem.Adapter.DrawerListAdapter;
import tcs.com.bankingsystem.Beans.Account;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.Fragment.Bk_CurrencyFrameLayout;
import tcs.com.bankingsystem.Fragment.Bk_Forex;
import tcs.com.bankingsystem.Fragment.Bk_Home;
import tcs.com.bankingsystem.Fragment.Bk_TransactionFragment;
import tcs.com.bankingsystem.Fragment.Bk_fund_transfer;
import tcs.com.bankingsystem.Fragment.Bk_login;
import tcs.com.bankingsystem.Fragment.Bk_ChangePassword;
import tcs.com.bankingsystem.Fragment.Bk_PayBillFragment;
import tcs.com.bankingsystem.Fragment.Bk_account_summary;
import tcs.com.bankingsystem.Fragment.Bk_bene_frag;
import tcs.com.bankingsystem.Fragment.Bk_emi;
import tcs.com.bankingsystem.R;
import tcs.com.bankingsystem.Utilities.JSonReader;


public class Bk_Containt extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private  ActionBarDrawerToggle mDrawerToggle;
    private CharSequence mDrawerTitle;
    private CharSequence mTitle;
    private ListView mDrawer;
    private Long cust_id;
    private Bundle bundle;
    private dbHandler mdbhandler;
    public static String title;
    private Toolbar toolbar;
    private TextView prof_name;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bk_all_containt);
        initialiseView();
        toolbar=(Toolbar)findViewById(R.id.app);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        bundleSetup();
        jsonparser();
        changeFragment(Bk_Home.class, bundle, false, R.id.container);
        drawerActionBarSetup();
        navigationDrawerMenuSetup();
        navigationDrawerToggleSetup();mDrawerLayout.bringToFront();
         prof_name=(TextView)findViewById(R.id.name);
        prof_name.setText(setAccountHolder(cust_id));

    }

    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Pass the event to ActionBarDrawerToggle, if it returns
        // true, then it has handled the app icon touch event
        if(item.getItemId()==android.R.id.home)
        {
            if(Bk_bene_frag.flag|| Bk_emi.flag|| Bk_account_summary.flag||Bk_fund_transfer.flag|| Bk_ChangePassword.flag|| Bk_PayBillFragment.mflag || Bk_Forex.flag || Bk_TransactionFragment.flag){
                Log.d("stackentry",getFragmentManager().getBackStackEntryCount()+"");
                for(int i=0;i<getFragmentManager().getBackStackEntryCount();i++){
                    getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                    Log.d("stack","clearing..");
                }
                Bk_Home home=new Bk_Home();
                home.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.container,home).addToBackStack(null).commit();
            }
            else if(Bk_CurrencyFrameLayout.flag)
            {
                Log.d("stackentry",getFragmentManager().getBackStackEntryCount()+"");
                for(int i=0;i<getFragmentManager().getBackStackEntryCount();i++){
                    getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                    Log.d("stack","clearing..");
                }
                Bk_Forex forex=new Bk_Forex();
                forex.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.container,forex).addToBackStack(null).commit();
            }
            else if(getFragmentManager().getBackStackEntryCount()>0){
                getFragmentManager().popBackStackImmediate();
            }


        }
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        // Handle your other action bar items...

        return super.onOptionsItemSelected(item);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }
    public void onBackPressed() {
        setTitle("Menu");
        if(Bk_Home.flag) {
            AlertDialog.Builder alert = new AlertDialog.Builder(Bk_Containt.this);
            alert.setTitle("Logout").setIcon(R.drawable.logout);
            alert.setCancelable(false);;
            alert.setMessage("Are you sure to Logout?");
            alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(Bk_Containt.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(Bk_Containt.this, Bk_FragmentContainer.class);
                    Bk_FragmentContainer.flag=1;
                    finish();
                    startActivity(intent);
                }
            });
            alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            alert.show();
        }
        else if(Bk_bene_frag.flag|| Bk_emi.flag|| Bk_account_summary.flag||Bk_fund_transfer.flag|| Bk_ChangePassword.flag|| Bk_PayBillFragment.mflag || Bk_Forex.flag){
            Log.d("stackentry",getFragmentManager().getBackStackEntryCount()+"");
            for(int i=0;i<getFragmentManager().getBackStackEntryCount();i++){
                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Log.d("stack","clearing..");
            }
            Bk_Home home=new Bk_Home();
            home.setArguments(bundle);
            getFragmentManager().beginTransaction().replace(R.id.container,home).addToBackStack(null).commit();
        }
        else if(Bk_CurrencyFrameLayout.flag)
        {
            Log.d("stackentry",getFragmentManager().getBackStackEntryCount()+"");
            for(int i=0;i<getFragmentManager().getBackStackEntryCount();i++){
                getFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                Log.d("stack","clearing..");
            }
            Bk_Forex forex=new Bk_Forex();
            forex.setArguments(bundle);
            getFragmentManager().beginTransaction().replace(R.id.container,forex).addToBackStack(null).commit();
        }
        else if(getFragmentManager().getBackStackEntryCount()>0){
                getFragmentManager().popBackStackImmediate();
            }
        else{
            super.onBackPressed();
        }

    }

/*
    Parse transaction jason file and insert in to transaction table if record is not present .
 */
    public void jsonparser()
    {
        mdbhandler=new dbHandler(this);
        String strJson=readjsonfile();
        String data = "";
        try {
            JSONObject jsonRootObject = new JSONObject(strJson);

            //Get the instance of JSONArray that contains JSONObjects
            JSONArray jsonArray = jsonRootObject.optJSONArray("Transactions");

            //Iterate the jsonArray and print the info of JSONObjects
            for(int i=0; i < jsonArray.length(); i++){
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                int id =(jsonObject.optInt("id"));
                double amount = jsonObject.optDouble("amount");
                String date=jsonObject.optString("Date").toString();
                String description=jsonObject.optString("description").toString();
                String is_star=jsonObject.optString("is_star").toString();
                String Account_no=jsonObject.optString("Account_no").toString();
                int customer_id=jsonObject.optInt("customer_id");
                Log.d("custttid", "" + customer_id);
                Log.d("anand", "" + id);
                mdbhandler.insert_Transaction_detail(id, date, amount, is_star, Account_no, description, customer_id);

            }

        } catch (JSONException e) {e.printStackTrace();}
    }
    /*
        read the json file and save it in string format
     */
    public String readjsonfile()
    {
        StringBuilder builder=new StringBuilder();
        File file = new File(Environment.getExternalStorageDirectory(), "json.txt");
        if(file.exists())
        {

            try {
                BufferedReader br =new BufferedReader(new FileReader(file));
                String line;
                while((line=br.readLine())!=null)
                {
                    builder.append(line);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return builder.toString();

    }
    public  ActionBarDrawerToggle getmDrawerToggle()
    {
        return mDrawerToggle;
    }
    public void initialiseView()
    {
        mDrawerLayout= (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawer= (ListView) findViewById(R.id.left_drawer);
    }
    public void bundleSetup()
    {
       // bundle=getArguments();
       // custId= bundle.getLong("customer id");
        cust_id=getIntent().getExtras().getLong("customer id");
        bundle =new Bundle();
        bundle.putLong("customer id", cust_id);
    }
    public  void navigationDrawerMenuSetup()
    {
        mDrawer.setAdapter(new DrawerListAdapter(this));
        mDrawer.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        EMT();
                        break;
                    case 1:
                        accountDetail();
                        break;
                    case 2:
                        fundTransfer();
                        break;
                    case 3:
                        changePassword();
                        break;
                    case 4:
                        deleteAccount();
                        break;
                    case 5:
                        payBill();
                        break;

                    case 6:
                        logout();
                        break;


                }
            }

        });
    }
    public void navigationDrawerToggleSetup()
    {
        mDrawerToggle=new ActionBarDrawerToggle(this,mDrawerLayout, R.string.drawer_open, R.string.drawer_close){

            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
                getSupportActionBar().setTitle(title);

            }

            /** Called when a drawer has settled in a completely open state. */
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);
                mDrawer.bringToFront();
                mDrawerLayout.requestLayout();
                getSupportActionBar().setTitle("SELECT");

            }

        };
        mDrawerLayout.setDrawerListener(mDrawerToggle);
    }
    public void drawerActionBarSetup()
    {
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
       // mDrawerToggle.syncState();
    }
    public void EMT()
    {
        title="EMI";
        mDrawerLayout.closeDrawers();
        Bk_emi emi=new Bk_emi();
        changeFragment(Bk_emi.class, null, true, R.id.container);
       // getFragmentManager().beginTransaction().replace(R.id.container, emi).addToBackStack(null).commit();
    }
    public void accountDetail()
    {
        title="Account Details";
         mDrawerLayout.closeDrawers();
        changeFragment(Bk_account_summary.class, bundle, true, R.id.container);
    }
    public void fundTransfer()
    {
        title="Funds Transfer";
        mDrawerLayout.closeDrawers();
        changeFragment(Bk_fund_transfer.class, bundle, true, R.id.container);
    }
    public void changePassword()
    {
        title="Change Password";
        mDrawerLayout.closeDrawers();
        changeFragment(Bk_ChangePassword.class, bundle, true, R.id.container);
    }
    public void deleteAccount()
    {
        mDrawerLayout.closeDrawers();
        AlertDialog.Builder alertdialog = new AlertDialog.Builder(Bk_Containt.this);
        alertdialog.setTitle("Delete Account").setIcon(R.drawable.deleteaccounticonn);
        alertdialog.setMessage("Are you sure to Delete your account?");
        alertdialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(Bk_Containt.this, "Account deleted successfully", Toast.LENGTH_SHORT).show();
                //Bk_PayBillFragment.editor.clear();
               // Bk_PayBillFragment.editor.putLong("id", 200);
                mdbhandler.deleteAccount(cust_id);

               Intent intent=new Intent(Bk_Containt.this,Bk_FragmentContainer.class);
                finish();
                startActivity(intent);
            }
        });
        alertdialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        alertdialog.show();
    }
    public void payBill()
    {
        title="PayBill";
        mDrawerLayout.closeDrawers();
        changeFragment(Bk_PayBillFragment.class, bundle, true, R.id.container);
    }
    public void logout()
    {
        mDrawerLayout.closeDrawers();
        AlertDialog.Builder alert = new AlertDialog.Builder(Bk_Containt.this);
        alert.setTitle("Logout").setIcon(R.drawable.logout);
        alert.setMessage("Are you sure to Logout?");
        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(Bk_Containt.this, "Logged out successfully", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(Bk_Containt.this, Bk_FragmentContainer.class);
                finish();
                Bk_FragmentContainer.flag = 1;
                startActivity(intent1);
            }
        });
        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        alert.show();
    }
    public String setAccountHolder(long cust_id)
    {
        Account account=new Account();
        try {
            account = JSonReader.getAccountDetails(cust_id);
        }  catch (IOException e) {
        e.printStackTrace();
    } catch (JSONException e) {
        e.printStackTrace();
    }
        return "Hi "+account.getHolderName();
    }

    public <T>void changeFragment(Class<T> fragmentClass,Bundle bundle,boolean isBackStack,int framelayout)
    {
        try{
            Fragment fragment=(Fragment)fragmentClass.newInstance();
            if(bundle!=null)
            {
                fragment.setArguments(bundle);
            }
            if(isBackStack)
            {
                getFragmentManager().beginTransaction().replace(framelayout,fragment).addToBackStack(null).commit();
            }
            else
            {
                getFragmentManager().beginTransaction().replace(framelayout,fragment).commit();
            }

        }catch (InstantiationException e){
            e.printStackTrace();
        }
        catch (IllegalAccessException e){
            e.printStackTrace();
        }
    }
    public SharedPreferences.Editor getsharedprefence()
    {
       SharedPreferences sharedPreferences = this.getSharedPreferences("values", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        return editor;
    }

}
