package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import tcs.com.bankingsystem.Adapter.CurrencyStarAdapter;
import tcs.com.bankingsystem.R;

/**
 * Created by Anand Sharma on 9/26/2015.
 */
/*
    setting the adapter for favourite currency list.
 */
public class Bk_ForexStarList extends Fragment {
    private ListView listView;
    private Bundle b;
    private long custId;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.bk_currency_starlist,container,false);
        listView = (ListView)view.findViewById(R.id.starlist);
        custId=getBundle();
        listView.setAdapter(new CurrencyStarAdapter(getActivity(),custId));
        return view;
    }
    public long getBundle()
    {
        b=new Bundle();
        b=getArguments();
        custId=b.getLong("customer id");
        return custId;
    }
}
