package tcs.com.bankingsystem.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import tcs.com.bankingsystem.R;
import tcs.com.bankingsystem.Beans.beneficiary_class;

/**
 * Created by 963691 on 9/17/2015.
 */
public class beneficiary_adapter extends BaseAdapter {
    private Context context;
    private TextView tv1,tv2;
    private ArrayList<beneficiary_class> bene_list=new ArrayList<beneficiary_class>();
    public beneficiary_adapter(Context context,ArrayList<beneficiary_class> bene_list){
        this.context=context;
        this.bene_list=bene_list;
    }

    public int getCount() {
        return bene_list.size();
    }


    public Object getItem(int position) {
        return bene_list.get(position);
    }


    public long getItemId(int position) {
        return position;
    }


    public View getView(int position, View convertView, ViewGroup parent) {
        View v ;
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.bk_row_layout_bene_list, null);
            tv1 = (TextView) v.findViewById(R.id.tv_beneficiaryName_list);
            tv2= (TextView) v.findViewById(R.id.tv_BeneficiaryAcctno_list);
        }else{
            v=convertView;
        }
        Log.d("adapter","checking");
        tv1.setText(bene_list.get(position).getName());
        tv2.setText(bene_list.get(position).getAcc_no()+" ");
        return v;
    }
    public void updateAdapter(ArrayList<beneficiary_class> bene_list){
        this.bene_list=bene_list;
        this.notifyDataSetChanged();
    }
}
