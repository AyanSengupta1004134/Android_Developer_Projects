package tcs.com.bankingsystem.Fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.R;
import tcs.com.bankingsystem.Utilities.InputFilterMinMax;


public class Bk_emi extends Fragment {
    private EditText et_amount, et_time,et_rate;
    private Button calculate, clear;
    private SeekBar rateProgress;
    private Spinner dropdown;
    private TextView result;
    private double time;
    private String selectedFormat;
    public static boolean flag=false;
    private Context context;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bk_fragment_bk_emi, container, false);
        initializeView(view);
        setInputFilterInEdittext();
        dropDownListSetUp(container);
        seekBarSetUp();
        calculateEMI();
        clearEditText();
        setupTextWatcher();

        return view;
    }





    @Override
    public void onResume() {
        super.onResume();
        Log.d("onResume", "checking");
        flag=true;

    }


    public void initializeView(View view)
    {
        et_amount = (EditText) view.findViewById(R.id.pamount);
        et_rate = (EditText) view.findViewById(R.id.rate1);
        et_time = (EditText) view.findViewById(R.id.year);
        result=(TextView) view.findViewById(R.id.result);
        calculate = (Button) view.findViewById(R.id.calculate);
        clear = (Button) view.findViewById(R.id.clear);
        rateProgress = (SeekBar) view.findViewById(R.id.seekBar);
        dropdown = (Spinner) view.findViewById(R.id.spinner);
    }
    public void dropDownListSetUp(ViewGroup container)
    {
        String[] items = new String[]{"Year", "Month"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(container.getContext(), android.R.layout.simple_spinner_item, items);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dropdown.setAdapter(adapter);
        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
                selectedFormat=dropdown.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

                selectedFormat=dropdown.getSelectedItem().toString();;

            }
        });

    }
    public void seekBarSetUp()
    {
        rateProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            public void onStopTrackingTouch(SeekBar bar) {
                int value = bar.getProgress(); // the value of the seekBar progress
            }

            public void onStartTrackingTouch(SeekBar bar) {

            }

            public void onProgressChanged(SeekBar bar,
                                          int paramInt, boolean paramBoolean) {
                et_rate.setText("" + paramInt + ""); // here in textView the percent will be shown
            }
        });
    }
    public void calculateEMI()
    {
        calculate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!et_amount.getText().toString().isEmpty() && !et_rate.getText().toString().isEmpty() && !et_time.getText().toString().isEmpty())

                {
                    double p = 0;
                    double r = 0;
                    double r2 = 0;
                    double r1 = 0;
                    double ans = 0;
                    p = Double.parseDouble(et_amount.getText().toString());
                    r = Double.parseDouble(et_rate.getText().toString());
                    Log.d("selected", selectedFormat);
                    if (selectedFormat.equals("Year") && !et_time.getText().toString().isEmpty()) {
                        Log.d("PIYA", "YEAR ");
                        time = Double.parseDouble(et_time.getText().toString()) * 12;
                    } else if (selectedFormat.equals("Month")) {
                        if (!et_time.getText().toString().isEmpty())
                            time = Double.parseDouble(et_time.getText().toString());
                    }
                    r1 = r / (12 * 100);
                    r2 = Math.pow(1 + r1, time);
                    ans = ((p * r1 * r2) / (r2 - 1));
                    AlertDialog.Builder alertbox = new AlertDialog.Builder(v.getContext());
                    alertbox.setMessage("Your Monthly EMI is = " + ans);

                    alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface arg0, int arg1) {


                        }
                    });

                    alertbox.show();
                    ;
                } else {
                    AlertDialog.Builder alertbox = new AlertDialog.Builder(v.getContext());
                    alertbox.setMessage("Please input all values");
                    alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface arg0, int arg1) {


                        }
                    });

                    alertbox.show();
                }
            }

        });
    }
    public  void setInputFilterInEdittext()
    {
        InputFilterMinMax filter = new InputFilterMinMax("0", "100") {};
        et_rate.setFilters(new InputFilter[]{filter});
    }
    public  void clearEditText()
    {
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_amount.setText("");
                et_time.setText("");
                et_rate.setText("");
            }
        });
    }
    public void setupTextWatcher()
    {
        et_rate.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    //Update Seekbar value after entering a number
                    int progress = Integer.parseInt(s.toString());
                    if (progress >= 0 && progress <= 100) {
                        rateProgress.setProgress(progress);
                        et_rate.setSelection(et_rate.getText().length());
                    }

                } catch (Exception ex) {
                }

            }
        });
    }

}




