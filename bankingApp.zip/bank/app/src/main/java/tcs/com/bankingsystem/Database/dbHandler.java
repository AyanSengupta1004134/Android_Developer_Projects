package tcs.com.bankingsystem.Database;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.Beans.Bk_Currency;
import tcs.com.bankingsystem.Beans.Transaction;
import tcs.com.bankingsystem.Beans.beneficiary_class;
import tcs.com.bankingsystem.Fragment.Bk_PayBillFragment;

/**
 * Created by 963691 on 9/16/2015.
 */
/*
    this will contain all the methods to handle the database
 */
public class dbHandler {
    private static final String DATABASE_NAME = "MY_DATABASE";
    private static final int DATABASE_VERSION = 30;
    private Context context;
    private SQLiteDatabase sqlDatabase;
    private MyDatabase mDataBase;
    private ArrayList<Transaction> list,starlist;
    private ArrayList<beneficiary_class> beneficiary_list;
    private ArrayList<Bk_Currency> currencylist,favoriteCurrencyList;
    public dbHandler(Context context) {

        mDataBase = new MyDatabase(context, DATABASE_NAME, null,
                DATABASE_VERSION);
        sqlDatabase = mDataBase.getWritableDatabase();
        this.context=context;
        list=new ArrayList<Transaction>();
        starlist=new ArrayList<Transaction>();
        beneficiary_list=new ArrayList<beneficiary_class>();
        currencylist=new ArrayList<Bk_Currency>();
        favoriteCurrencyList=new ArrayList<Bk_Currency>();
    }
    /*
            this method will insert the registration detail in to customer table
     */
    public void registerCustomer(long custId,String password,String question,String answer){
        String query = "INSERT INTO CUSTOMER(CUSTOMERID,PASSWORD,SECURITY_QUESTION,SECURITY_ANSWER) values ('"
                + custId + "','" + password+"','" +question+ "','" +answer+ "')";
        try {

            if (sqlDatabase.isOpen()) {
                sqlDatabase.close();
            }

            sqlDatabase = mDataBase.getWritableDatabase();
            sqlDatabase.execSQL(query);

        } catch (Exception e) {

            e.printStackTrace();
        }
        sqlDatabase.close();
    }
    /*
        this method will check whether the customer is already registered or not.
     */
    public boolean isCustIdAlreadyRegistered(long custId){
        boolean res=false;
        Cursor c1 = null;
        try {

            if (sqlDatabase.isOpen()) {
                sqlDatabase.close();

            }
            sqlDatabase = mDataBase.getWritableDatabase();
            c1 = sqlDatabase.query(false, new String("CUSTOMER"), new String[]{"CUSTOMERID"}, "customerid=?", new String[]{"" + custId}, null, null, null, null);
            if(c1!=null&&c1.getCount()>0)
                res=true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        c1.close();
        sqlDatabase.close();
        return res;
    }
    /*
        this method will check whether the particular cusomerid and password matches with the database .
     */
    public boolean checkCustomer(long id,String password){
        boolean res=false;
        Cursor c1 = null;
        try {

            if (sqlDatabase.isOpen()) {
                sqlDatabase.close();

            }
            sqlDatabase = mDataBase.getWritableDatabase();
            c1 = sqlDatabase.query(false,new String("CUSTOMER"), new String[]{"CUSTOMERID","PASSWORD"}, "customerid=?",new String[]{""+id},null,null,null,null);
            if(c1.moveToFirst()){
                    Long registered_id=c1.getLong(c1.getColumnIndex("CUSTOMERID"));
                    String registered_password=c1.getString(c1.getColumnIndex("PASSWORD"));
                    if(id==registered_id){
                        if(password.equals(registered_password))
                            res=true;
                    }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        c1.close();
        sqlDatabase.close();
        return res;
    }
    /*
        this method will return the security question of registered user.
     */
    public String returnRegistertedSecurityQuestion(String custumerid){
        long custumer_id=Long.parseLong(custumerid);
        Cursor c1 = null;
        String securityquestion=null;
        try {

            if (sqlDatabase.isOpen())
                sqlDatabase.close();
            sqlDatabase = mDataBase.getWritableDatabase();
            c1 = sqlDatabase.query(false, new String("CUSTOMER"), new String[]{"SECURITY_QUESTION"}, "customerid=?", new String[]{"" + custumer_id}, null, null, null, null);
            if(c1.moveToFirst()){
                securityquestion=c1.getString(c1.getColumnIndex("SECURITY_QUESTION"));

                }
            }catch (SQLiteException e) {
                e.printStackTrace();
            }
            c1.close();
            sqlDatabase.close();
            return securityquestion;
        }

    /*
        this method will return answer of security question of a particular custid.
     */
    public String returnRegistertedSecurityAnswer(String custumerid){
        long custumer_id=Long.parseLong(custumerid);
        Cursor c1 = null;
        String securityAnsFrmDB=null;
        try {

            if (sqlDatabase.isOpen())
                sqlDatabase.close();
            sqlDatabase = mDataBase.getWritableDatabase();
            c1 = sqlDatabase.query(false, new String("CUSTOMER"), new String[]{"SECURITY_ANSWER"}, "customerid=?", new String[]{"" + custumer_id}, null, null, null, null);
            if(c1.moveToFirst()) {
                securityAnsFrmDB = c1.getString(c1.getColumnIndex("SECURITY_ANSWER"));
            }


        }catch (SQLiteException e) {
            e.printStackTrace();
        }
        c1.close();
        sqlDatabase.close();
        return securityAnsFrmDB;
    }

    /*
            this method will update the password of particular user in customer table.
     */

    public void updatePassword(long  userName,String newPassword) {
        String query = "UPDATE CUSTOMER SET PASSWORD ='"+newPassword+"'  WHERE  CUSTOMERID='"+userName+"'";
        try {

            if (sqlDatabase.isOpen()) {
                sqlDatabase.close();
            }
            sqlDatabase = mDataBase.getWritableDatabase();
            sqlDatabase.execSQL(query);

        } catch (Exception e) {

          e.printStackTrace();
        }
        sqlDatabase.close();
    }
    /*
            this method will return all beneficiary of particular customer id.
     */
    public ArrayList<beneficiary_class> readAllbeneficiaries(long id)
    {
        ArrayList<beneficiary_class> array_list = new ArrayList<beneficiary_class>();
        beneficiary_class bene;
        Cursor res=null;
        try {
            sqlDatabase= mDataBase.getWritableDatabase();
            res = sqlDatabase.query("BENEFICIARY", new String[]{"NAME", "ACCNO","BRANCH" ,"EMAIL"}, "ID=?",new String[]{""+id}, null, null, null);
            if(res!=null&&res.getCount()!=0)
                while (res.moveToNext()) {
                        bene = new beneficiary_class(res.getString(res.getColumnIndex("NAME")), res.getLong(res.getColumnIndex("ACCNO")), res.getString(res.getColumnIndex("BRANCH")), res.getString(res.getColumnIndex("EMAIL")));
                        array_list.add(bene);
                }
        }catch (SQLiteException e){
           e.printStackTrace();
        }
        res.close();
        sqlDatabase.close();
        return array_list;
    }
    /*
        this method will insert beneficiary into beneficiary table
    */
    public void insertBeneficiary(Long id, String sName, String sAcc, String sEmail, String sBranch) {
        sqlDatabase = mDataBase.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ID",id);
        contentValues.put( "NAME",sName);
        contentValues.put("ACCNO", sAcc);
        contentValues.put("BRANCH",sBranch );
        contentValues.put("EMAIL", sEmail);
        long chk=sqlDatabase.insert("BENEFICIARY", null, contentValues);
        sqlDatabase.close();
        }

    /*
            this method will update beneficiary name into beneficiary table
     */
    public void updateBeneficiaryName(String sName,Long sAccno,Long custId) {
        String Query="UPDATE BENEFICIARY SET NAME= '"+sName+"' WHERE ACCNO= '"+sAccno+"' AND  ID= '"+custId+"'" ;
        try {
            if (sqlDatabase.isOpen()) {
                sqlDatabase.close();
            }
            sqlDatabase = mDataBase.getWritableDatabase();
            sqlDatabase.execSQL(Query);

        } catch (Exception e) {

           e.printStackTrace();
        }
        sqlDatabase.close();
    }
    /*
        this method will delete beneficiary from beneficiary table
    */
    public void deleteBeneficiary(Long sAccno,Long custId) {
        String DelQuery="DELETE FROM BENEFICIARY WHERE ACCNO= '"+sAccno+"' AND  ID= '"+custId+"'";
        try {
            if (sqlDatabase.isOpen()) {
                sqlDatabase.close();
            }
            sqlDatabase = mDataBase.getWritableDatabase();
            sqlDatabase.execSQL(DelQuery);

        } catch (Exception e) {

            e.printStackTrace();
        }
        sqlDatabase.close();
    }
    /*
        this method will delete the account of particular customer from the application
     */
    public  void deleteAccount(long id){
        String DEL_CUSTOMER_QUERY = "DELETE FROM " + "CUSTOMER" + " WHERE " + "CUSTOMERID" + "=" + id;
        String DEL_BENEFICIARY_QUERY="DELETE FROM " + "BENEFICIARY" + " WHERE " + "ID" + "=" + id;
        String DEL_FOREX_QUERY="DELETE FROM " + "FOREX" + " WHERE " + "ID" + "=" + id;
        String DEL_FAVFOREX_QUERY="DELETE FROM " + "FOREXVIEW" + " WHERE " + "ID" + "=" + id;
        String DEL_FOREXVIEW_QUERY="DELETE FROM " + "FOREXFAV" + " WHERE " + "ID" + "=" + id;
        String DEL_TRANSACTION_QUERY="DELETE FROM " + "TRANS" + " WHERE " + "ID" + "=" + id;
        sqlDatabase = mDataBase.getWritableDatabase();
        try {
            if (sqlDatabase.isOpen()) {
                sqlDatabase.close();
            }
            sqlDatabase = mDataBase.getWritableDatabase();
            sqlDatabase.execSQL(DEL_BENEFICIARY_QUERY);
            sqlDatabase.execSQL(DEL_CUSTOMER_QUERY);
            sqlDatabase.execSQL(DEL_FOREX_QUERY);
            sqlDatabase.execSQL(DEL_FAVFOREX_QUERY);
            sqlDatabase.execSQL(DEL_FOREXVIEW_QUERY);
            sqlDatabase.execSQL(DEL_TRANSACTION_QUERY);
        } catch (Exception e) {
           e.printStackTrace();
        }
        sqlDatabase.close();
//        Bk_PayBillFragment.editor.putLong("id", 200);
        //Bk_PayBillFragment.editor.remove(String.valueOf(Bk_PayBillFragment.sharedPreferences)).commit();
        SharedPreferences sharedPreferences=context.getSharedPreferences("values", Context.MODE_PRIVATE);
        sharedPreferences.edit().clear().commit();

    }
  /*
    this method will insert a particular transaction in the transaction table
     */

    public  long insert_Transaction_detail(int id,String trans_date,double trans_amount,String is_starmark,String TRANS_ACCT_NO,String DESCRIPTION,int cust_id)
    {
        int count=0;
        sqlDatabase = mDataBase.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("TRANS_ID",id);
        contentValues.put("TRANS_DATE",trans_date);
        contentValues.put("AMOUNT",trans_amount);
        contentValues.put("STAR",is_starmark);
        contentValues.put("ACCOUNT_NO",TRANS_ACCT_NO);
        contentValues.put("DESCRIPTION", DESCRIPTION);
        contentValues.put("CUSTOMER_ID", cust_id);
        String[] col={"TRANS_ID"};
        Cursor c=sqlDatabase.query("TRANS", col,"TRANS_ID=" + id, null, null, null, null);
        while (c.moveToNext())
        {
            count=1;
        }
        if(count==0)
        sqlDatabase.insert("TRANS", null, contentValues);
        sqlDatabase.close();
        c.close();
        return id;
    }
    /*
  this method will retrieve all transaction list of a particular customer
   */
    public  ArrayList<Transaction> get_Transaction_list(int custid)
    {
        sqlDatabase=mDataBase.getWritableDatabase();
        String[] col={"TRANS_ID","TRANS_DATE","AMOUNT","STAR","ACCOUNT_NO","DESCRIPTION","CUSTOMER_ID"};
        Cursor c=sqlDatabase.query("TRANS", col, "CUSTOMER_ID=" + custid, null, null, null, null);
        list.clear();
        while (c.moveToNext())
        {
            String id=c.getString(0);
            String TRANS_DATE=c.getString(1);
            String TRANS_AMOUNT=c.getString(2);
            String IS_STARMARK=c.getString(3);
            String TRANS_ACCT_NO=c.getString(4);
            String TRANS_DES=c.getString(5);
            int Cust_id=c.getInt(6);
            list.add(new Transaction(id, TRANS_DATE, TRANS_AMOUNT,IS_STARMARK, TRANS_ACCT_NO,TRANS_DES,Cust_id));

        }
        c.close();
        sqlDatabase.close();
        return list;
    }
    /*
   this method will retrieve all favourite transactions of a particular customer
    */
    public  ArrayList<Transaction> getstar_Transaction_list(int custid)
    {
        sqlDatabase=mDataBase.getWritableDatabase();
        String[] col={"TRANS_ID","TRANS_DATE","AMOUNT","STAR","ACCOUNT_NO","DESCRIPTION","CUSTOMER_ID"};
        Cursor c=sqlDatabase.query("TRANS", col, "STAR" + "='" + "true" + "'" + "and CUSTOMER_ID=" + custid, null, null, null, null);
        starlist.clear();
        while (c.moveToNext())
        {
            String id=c.getString(0);
            String TRANS_DATE=c.getString(1);
            String TRANS_AMOUNT=c.getString(2);
            String IS_STARMARK=c.getString(3);
            String TRANS_ACCT_NO=c.getString(4);
            String TRANS_DES=c.getString(5);
            int Cust_id=c.getInt(6);
            starlist.add(new Transaction(id, TRANS_DATE, TRANS_AMOUNT,IS_STARMARK,TRANS_ACCT_NO,TRANS_DES,Cust_id));

        }
        c.close();
        sqlDatabase.close();
        return starlist;
    }
    /*
    this method will update IS_Star(favourite) column of transaction table of particular customer table
     */
    public  int updatestardata(String id)
    {
        sqlDatabase=mDataBase.getWritableDatabase();
        String transtarmark="false";
        String[] col={"STAR"};
        Cursor c=sqlDatabase.query("TRANS", col, "TRANS_ID" + "='" +id+ "'", null, null, null, null);
        starlist.clear();
        ContentValues contentValues=new ContentValues();
        try {
            while (c.moveToNext())
            {
                transtarmark = c.getString(c.getColumnIndex("STAR"));
            }

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        if(transtarmark.equals("true"))
            contentValues.put("STAR","false");
        else
            contentValues.put("STAR","true");
        String[] wherearg={id};
        int row= sqlDatabase.update("TRANS",contentValues,"TRANS_ID"+" =?",wherearg);
        c.close();
        sqlDatabase.close();
        return row;
    }
    /*
  this method will return all beneficiaries of a particular customer
   */
    public ArrayList<beneficiary_class> readAllbeneficiariesfund(Long custid){
        sqlDatabase=mDataBase.getReadableDatabase();
        String[] col={"ID","NAME","ACCNO","BRANCH","EMAIL"};
        try {
            Cursor c = sqlDatabase.query("BENEFICIARY", col, "ID=?", new String[]{"" + custid}, null, null, null);
            while (c.moveToNext()) {
                String id = c.getString(0);
                String BEN_NAME = c.getString(1);
                Long BEN_ACCNO=c.getLong(2);
                String BEN_BRANCH = c.getString(3);
                String BEN_EMAIL = c.getString(4);
                beneficiary_list.add(new beneficiary_class(BEN_NAME, BEN_ACCNO, BEN_BRANCH, BEN_EMAIL));

            }
            c.close();
        }catch (SQLiteException e){
            e.printStackTrace();
        }
        return beneficiary_list;
    }
    /*
        this method will insert forex data for a particular customer in forex table whenever data is downloading from internet
         */
    public void insertforexrate(String pair,String rate,long Cust_id)
    {
        int count=0;
        String previous = null;
        sqlDatabase = mDataBase.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("PAIR",pair);
        contentValues.put("RATES", rate);
        contentValues.put("CUSTOMER_ID", Cust_id);

        String[] col={"RATES"};
        String[] wherearg={pair};
        Cursor c=sqlDatabase.query("FOREX", col, "PAIR" + "='" + pair + "'", null, null, null, null);
        Cursor c1=sqlDatabase.query("FOREX", col, "PAIR" + "='" + pair + "'", null, null, null, null);

        while(c.moveToNext())
        {
            count++;
            previous=c.getString(0);

        }
        if(count==0)
        {
            long id=sqlDatabase.insert("FOREX", null, contentValues);

        }

        else  if(previous!=rate)
        {
            int row= sqlDatabase.update("FOREX", contentValues, "PAIR" + "=?", wherearg);

        }
        c.close();
        c1.close();
        sqlDatabase.close();

    }
    /*
   this method will retrieve currency rate for particular pair  from forex table when internet connection is not available
    */
    public String getratefromdatabase(String pair)
    {
        String rate=null;
        sqlDatabase = mDataBase.getWritableDatabase();
        String[] col={"RATES"};
        String[] wherearg={pair};
        Cursor c=sqlDatabase.query("FOREX", col, "PAIR" + "='" + pair + "'", null, null, null, null);
        while (c.moveToNext())
        {
            rate=c.getString(0);
        }
        c.close();
        sqlDatabase.close();
        return rate;
    }
    /*
   this method will return all currency pair list and rate of particular customer
    */
    public ArrayList<Bk_Currency> getAllListOfCurrency(long cust_id)
    {
        String pair,rate=null;
        sqlDatabase = mDataBase.getWritableDatabase();
        String[] col={"CUSTID","PAIR","DATETIME"};
        String[] col1={"RATES"};
        Cursor c=sqlDatabase.query("FOREXVIEW", col,"CUSTID="+cust_id, null, null, null, "DATETIME"+" DESC");

        while (c.moveToNext())
        {
            pair=c.getString(1);
            Cursor c1=sqlDatabase.query("FOREX", col1, "PAIR" + "='" + pair + "'", null, null, null, null);
            while (c1.moveToNext()) {
                rate = c1.getString(0);
            }

            currencylist.add(new Bk_Currency(pair, rate));
        }
        c.close();
        sqlDatabase.close();
        return currencylist;
    }
    /*
   this method will return favourite list of currency pair from favourite forex table of a particular customer
    */
    public ArrayList<Bk_Currency> getFavoriteListOfCurrency(long cust_id)
    {
        String pair,rate=null;
        sqlDatabase = mDataBase.getWritableDatabase();
        String[] col={"CUSTID","PAIR","DATETIME"};
        String[] col1={"RATES"};
        Cursor c=sqlDatabase.query("FOREXFAV", col,"CUSTID="+cust_id, null, null, null, "DATETIME"+" DESC");

        while (c.moveToNext())
        {
            pair=c.getString(1);
            Cursor c1=sqlDatabase.query("FOREX", col1, "PAIR" + "='" + pair + "'", null, null, null, null);
            while (c1.moveToNext()) {
                rate = c1.getString(0);
            }

            favoriteCurrencyList.add(new Bk_Currency(pair, rate));
        }
        c.close();
        sqlDatabase.close();
        return favoriteCurrencyList;
    }
    /*
       this method will update the favourite forex data in  FOREXFAV table for particular customer
        */
    public  void updateFavData(String pair,long cust_id)
    {
        int count=0;
        sqlDatabase = mDataBase.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("PAIR",pair);
        contentValues.put("CUSTID",String.valueOf(cust_id));
        contentValues.put("DATETIME", new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()));
        String[] col={"PAIR",String.valueOf(cust_id)};
        String[] wherearg={pair,String.valueOf(cust_id)};
        Cursor c=sqlDatabase.query("FOREXFAV", col, "PAIR" + "='" + pair + "' and "+"CUSTID="+cust_id, null, null, null, null);
        while(c.moveToNext())
        {
            count++;
        }
        if(count==0)
        {
            long id=sqlDatabase.insert("FOREXFAV", null, contentValues);

        }
        else
        {
            int row= sqlDatabase.delete("FOREXFAV","PAIR" + "=? AND " + "CUSTID" + "=?", wherearg);

        }
        c.close();
        sqlDatabase.close();

    }
    /*
       this method will insert the forex data into the FOREXVIEW table whenever user will view rate
        */
    public void insertInToViewForex(String pair,long Cust_id)
    {
        int count=0;
        sqlDatabase = mDataBase.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("PAIR",pair);
        contentValues.put("CUSTID",String.valueOf(Cust_id));
        contentValues.put("DATETIME", new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()));
        String[] col={"PAIR","DATETIME"};
        String[] wherearg={pair,String.valueOf(Cust_id)};
        Cursor c=sqlDatabase.query("FOREXVIEW", col, "PAIR" + "='" + pair + "' and "+"CUSTID="+Cust_id, null, null, null, null);
        while(c.moveToNext())
        {
            count++;

        }
        if(count==0)
        {
            long id=sqlDatabase.insert("FOREXVIEW", null, contentValues);

        } else {
            ContentValues contentValues1 = new ContentValues();
            contentValues1.put("DATETIME", new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime()));
            int row= sqlDatabase.update("FOREXVIEW", contentValues1, "PAIR" + "=? AND " + "CUSTID" + "=?", wherearg);

        }
        c.close();
        sqlDatabase.close();

    }
    /*
    this method will return true if particular currency pair is added in the favourite forex table, otherwise, it will return false
     */
    public boolean isFavorite(String pair,long cust_id)
    {
        int count=0;
        boolean flag=false;
        sqlDatabase = mDataBase.getWritableDatabase();
        String[] col={"PAIR"};
        Cursor c=sqlDatabase.query("FOREXFAV", col, "PAIR" + "='" + pair + "' and "+"CUSTID="+cust_id, null, null, null, null);
        while(c.moveToNext())
        {
            count++;

        }
        if(count==0) {
            flag=false;

        }
        else
            flag=true;
        c.close();
        sqlDatabase.close();
        return flag;

    }

}
