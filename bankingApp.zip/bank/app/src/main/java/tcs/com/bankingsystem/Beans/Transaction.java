package tcs.com.bankingsystem.Beans;

import java.io.Serializable;

public class Transaction implements Serializable {
	private String id;
	private String date;
	private String Amount;
	private String star;
	private String acctno;
	private String description;
	private int cust_id;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Transaction(String id, String date, String amount, String star,
					   String acctno, String description, int cust_id) {
		super();
		this.id = id;
		this.date = date;
		Amount = amount;
		this.star = star;
		this.acctno = acctno;
		this.description=description;
		this.cust_id=cust_id;

	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getAmount() {
		return Amount;
	}

	public void setAmount(String amount) {
		Amount = amount;
	}

	public String getAcctno() {
		return acctno;
	}

	public void setAcctno(String acctno) {
		this.acctno = acctno;
	}

	public String getStar() {
		return star;
	}

	public void setStar(String star) {
		this.star = star;
	}
	

}
