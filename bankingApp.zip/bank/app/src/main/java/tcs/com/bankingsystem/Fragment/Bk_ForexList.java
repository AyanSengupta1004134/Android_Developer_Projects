package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import tcs.com.bankingsystem.Adapter.CurrencyAdapter;
import tcs.com.bankingsystem.R;

/**
 * Created by Anand Sharma on 9/23/2015.
 */
/*
    setting the adapter for listview of currency_pair
 */
public class Bk_ForexList extends Fragment {
    private ListView forexListView;
    private Bundle bundle;
    private long custId;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.bk_currency_list,container,false);
        forexListView = (ListView)view.findViewById(R.id.simplelist);
        custId=getBundle();
        forexListView.setAdapter(new CurrencyAdapter(getActivity(),custId));
        return view;
    }
    public long getBundle()
    {
        bundle=new Bundle();
        bundle=getArguments();
        custId=bundle.getLong("customer id");
        return custId;
    }
}
