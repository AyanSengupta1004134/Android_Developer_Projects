package tcs.com.bankingsystem.Fragment;


import android.app.Fragment;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;

/**
 * Created by Anand Sharma on 9/23/2015.
 */
public class Bk_Forex extends Fragment{
   private Spinner sp;
   private String select;
   private String selectedrate;
   private ArrayList<String> list;
   private ProgressBar progressBar;
   private TextView result;
   private Bundle bundle;
    private Button recentlyview;
    private long custId;
    public static boolean flag=false;
    public static dbHandler mdbHandler;
    String url="http://globalcurrencies.xignite.com/xGlobalCurrencies.json/GetRealTimeRate?_token=C1D92593F9E04664B499F710C5EA4C6A&Symbol=";
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bk_activity_forex, container, false);
        initializeView(view);
        custId=getBundle();
        addcurrency();
        mdbHandler=new dbHandler(container.getContext());
        spinnerSetUp();
        listenerSetUp();
        return view;
    }
    /*
        this method will add all currency_pair in arraylist to load it in spinner.
     */
    public void addcurrency()
    {
        list=new ArrayList<String>();
        list.add("EURUSD");
        list.add("USDINR");
        list.add("USDAUD");
        list.add("USDCAD");
        list.add("CADINR");
        list.add("EURINR");
        list.add("RUBCAD");
        list.add("RUBINR");
        list.add("MXNINR");
        list.add("RUBMXN");
    }
    /*
        this method will download forex data from the given url in string format.
     */
    public String getWebsite(String address)
    {
        StringBuffer buffer=new StringBuffer();
        BufferedReader bufferedReader=null;
        try {
            URL url = new URL(address);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            InputStream in=new BufferedInputStream(connection.getInputStream());
            bufferedReader=new BufferedReader(new InputStreamReader(in));
            String line="";
            while((line=bufferedReader.readLine())!=null)
            {
                buffer.append(line);
            }

        } catch (MalformedURLException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        finally{
            if(bufferedReader!=null)
            {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return buffer.toString();
    }
    /*
        This is AsyncTask which will download the forex jason data  in background.
     */
    public class getwebpage extends AsyncTask<String,Void,String>
    {
          protected String doInBackground(String... url) {

            return getWebsite(url[0]);
          }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String result1) {
            Log.i("website", result1);
            try {
                JSONObject jsonObject=new JSONObject(result1);
                String value="Network Error";
                 value = jsonObject.getString("Mid");
                String valuetext = jsonObject.getString("Text");
                result.setText(valuetext);
                selectedrate=value;

            } catch (JSONException e) {
                e.printStackTrace();
            }
            progressBar.setVisibility(View.INVISIBLE);
            if(selectedrate!=null){
                mdbHandler.insertforexrate(select, selectedrate,custId);
                mdbHandler.insertInToViewForex(select,custId);
            }
            super.onPostExecute(result1);
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }
/*
    this method will check the internet connection whether it is available or not.
 */
    public boolean isConnectingToInternet(){
        ConnectivityManager connectivity = (ConnectivityManager)getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity != null)
        {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null)
                for (int i = 0; i < info.length; i++)
                    if (info[i].getState() == NetworkInfo.State.CONNECTED)
                    {
                        return true;
                    }

        }
        return false;
    }

    /*
        this method will set the currency rate by fetching data from database when internet connection is not available.
     */
    public void setratefromdatabase(String pair)
    {
        String rate= mdbHandler.getratefromdatabase(pair);
        mdbHandler.insertInToViewForex(pair,custId);
        progressBar.setVisibility(View.INVISIBLE);
        if(rate!=null)
            result.setText("1 "+select.substring(0,3)+"="+rate+" "+select.substring(3,6));
        else
            result.setText("Rate not found");
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        flag=true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy", "checking");
        flag=false;
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("onPause", "checking");
        flag=false;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("onResume", "checking");
        flag=true;

    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Forex");
        Bk_Containt.title="Forex";

    }
    public void initializeView(View view)
    {
        sp=(Spinner)view.findViewById(R.id.spinner1);
        result=(TextView)view.findViewById(R.id.result);
        progressBar=(ProgressBar)view.findViewById(R.id.progressBar);
         recentlyview=(Button)view.findViewById(R.id.forexlist);
    }
    public long getBundle()
    {
        bundle=new Bundle();
        bundle=getArguments();
        custId=bundle.getLong("customer id");
        return custId;
    }
public  void spinnerSetUp()
{
    ArrayAdapter adapter=new ArrayAdapter(getActivity(), android.R.layout.simple_spinner_dropdown_item, list);
    sp.setAdapter(adapter);
    sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
        public void onItemSelected(AdapterView<?> arg0, View selectedvalue, int arg2, long arg3) {
            select = sp.getSelectedItem().toString();
            String address = url + sp.getSelectedItem();
            if (isConnectingToInternet()) {
                Toast.makeText(getActivity(), "connection ok", Toast.LENGTH_SHORT).show();
                new getwebpage().execute(address);
                progressBar.setVisibility(View.VISIBLE);
            } else {
                setratefromdatabase(select);
                Toast.makeText(getActivity(), "connection not available", Toast.LENGTH_SHORT).show();
            }

        }
        public void onNothingSelected(AdapterView<?> arg0) {


        }
    });
}
    public void listenerSetUp()
    {
        recentlyview.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Bk_CurrencyFrameLayout currencyFrameLayout=new Bk_CurrencyFrameLayout();
                currencyFrameLayout.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.container,currencyFrameLayout ).addToBackStack(null).commit();
            }
        });
    }
}
