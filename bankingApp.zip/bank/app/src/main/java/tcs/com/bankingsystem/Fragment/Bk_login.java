package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;

/**
 * Created by 963691 on 9/16/2015.
 */
public class Bk_login extends Fragment implements View.OnClickListener {
   private TextView tv_registerOption,tv_forgot_PasswordOption;
   private EditText et_custId,et_password;
   private Button bLogin;
   private dbHandler mdbHandler;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.bk_user_login, container,false);
        initializeView(view);
        setListener();
        mdbHandler=new dbHandler(container.getContext());
        onFocusValidation();
        return  view;
    }

    public void onClick(View v) {
        switch(v.getId()){
            case R.id.tv_register:
                         Bk_RegisterFragment register=new Bk_RegisterFragment();
                         getFragmentManager().beginTransaction().replace(R.id.framelayout,register).addToBackStack(null).commit();
                break;
            case R.id.bLogin:
                         loginSetUp();
                         break;
            case R.id.tv_forgotPassword:
                          Bk_ForgotPassword forgotPassword=new Bk_ForgotPassword();
                          getFragmentManager().beginTransaction().replace(R.id.framelayout,forgotPassword).addToBackStack(null).commit();
        }
    }
    public static boolean isNumeric(String str) {
        int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (Character.isDigit(str.charAt(i)) == false) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void onResume() {
        et_custId.setText("");
        et_password.setText("");
        super.onResume();
    }
    public void initializeView(View view)
    {
        tv_registerOption= (TextView) view.findViewById(R.id.tv_register);
        tv_forgot_PasswordOption=(TextView) view.findViewById(R.id.tv_forgotPassword);
        et_custId= (EditText) view.findViewById(R.id.et_custId_login);
        et_password= (EditText) view.findViewById(R.id.et_password_login);
        bLogin= (Button) view.findViewById(R.id.bLogin);
    }
    public  void setListener()
    {
        bLogin.setOnClickListener(this);
        tv_registerOption.setOnClickListener(this);
        tv_forgot_PasswordOption.setOnClickListener(this);
    }
    public void onFocusValidation()
    {
        et_password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    Long id = 0L;
                    if (!et_custId.getText().toString().isEmpty() && isNumeric(et_custId.getText().toString()))
                        id = Long.parseLong((et_custId.getText().toString()));
                    if (et_custId.getText().toString().isEmpty())
                        et_custId.setError("Enter Customer id");
                    else if (!isNumeric(et_custId.getText().toString()))
                        et_custId.setError("enter valid Customer Id");
                    else if (!mdbHandler.isCustIdAlreadyRegistered(id))
                        et_custId.setError("Customer ID is not Registered..First Register yourself");
                }
            }
        });
    }
    public void loginSetUp()
    {
        Long id=0L;
        if(!et_custId.getText().toString().isEmpty()&&isNumeric(et_custId.getText().toString()))
            id=Long.parseLong((et_custId.getText().toString()));
        if(et_custId.getText().toString().isEmpty())
            et_custId.setError("Enter Customer id");
        else if(!isNumeric(et_custId.getText().toString()))
            et_custId.setError("enter valid Customer Id");
        else if(et_password.getText().toString().isEmpty()) {
            et_password.setError("Enter Password");
        }
        else if(!mdbHandler.isCustIdAlreadyRegistered(id))
            et_custId.setError("Customer ID is not Registered..First Register yourself");
        else{
            if(mdbHandler.checkCustomer(id,et_password.getText().toString())){
                Intent i=new Intent(getActivity(), Bk_Containt.class);
                i.putExtra("customer id",id);
                startActivity(i);
            }
            else
                et_password.setError("Enter Correct Password");
        }
    }
}
