package tcs.com.bankingsystem.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

import tcs.com.bankingsystem.Beans.Transaction;
import tcs.com.bankingsystem.Fragment.Bk_Transaction_star_list;
import tcs.com.bankingsystem.R;

/**
 set the single row for star transaction list
 */
public class Transaction_star_row extends BaseAdapter {
    private Context mcontext;
    private ArrayList<Transaction> translist;
    public Transaction_star_row(Context context) {
        translist=new ArrayList<Transaction>();
        mcontext=context;
        translist= Bk_Transaction_star_list.transtarslist;
    }

    public int getCount() {

        return translist.size();
    }


    public Object getItem(int i) {

        return translist.get(i);
    }


    public long getItemId(int arg0) {

        return 0;
    }


    public View getView(int i, View arg1, ViewGroup viewGroup) {
        LayoutInflater inflater=(LayoutInflater)mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row=inflater.inflate(R.layout.bk_transaction_row,viewGroup,false) ;
        TextView trans_id=(TextView)row.findViewById(R.id.trans_id);
        TextView trans_date=(TextView)row.findViewById(R.id.trans_date);
        ImageButton img=(ImageButton)row.findViewById(R.id.imageView1);
        Transaction temp=translist.get(i);
        if(temp.getStar().equals("false")) {
            img.setImageResource(android.R.drawable.btn_star_big_off);
        }
        else {
            img.setImageResource(android.R.drawable.btn_star_big_on);
        }
        trans_id.setText(temp.getId());
        trans_date.setText(temp.getDate());
        return row;
    }

}
