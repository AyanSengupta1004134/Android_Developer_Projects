package tcs.com.bankingsystem.Fragment;

/**
 * Created by 963691 on 9/16/2015.
 */

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.Activity.Bk_FragmentContainer;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;


public class Bk_Home extends Fragment implements View.OnClickListener {
    private RelativeLayout trans_layout, forexLayout, benefeciaryLayout;
    private Context context;
    private Long custId;
    private dbHandler mdbhandler;
    private Bundle bundle;
    public static boolean flag=false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bk_fragment_home, null);
        initializeView(view);
        setListener();
        setBundle();
        initializeDB(container);
        Bk_Containt main=(Bk_Containt)getActivity();
       // main.getSupportActionBar().setHomeButtonEnabled(true);
       // main.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        return view;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_home, menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        switch(id) {
            case R.id.logout_menu:
                Bk_FragmentContainer.flag=1;
                AlertDialog.Builder alert = new AlertDialog.Builder(context);
                alert.setTitle("Logout").setIcon(R.drawable.logout);
                alert.setMessage("Are you sure to Logout?");
                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context, "Logged out successfully", Toast.LENGTH_SHORT).show();
                       Intent intent=new Intent(getActivity(), Bk_FragmentContainer.class);
                        Bk_FragmentContainer.flag=1;
                        getActivity().finish();
                        startActivity(intent);
                    }
                });
                alert.setNegativeButton("No", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alert.show();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        flag=true;
        setHasOptionsMenu(true);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.trans_Layout:
                Bk_TransactionFragment transactionFragment=new Bk_TransactionFragment();
                transactionFragment.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.container,transactionFragment).addToBackStack(null).commit();
                break;
            case R.id.forex_Layout:
                Bk_Forex forex=new Bk_Forex();
                forex.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.container,forex).addToBackStack(null).commit();
                break;
            case R.id.beneficiary_layout:
                Bk_bene_frag bene_frag=new Bk_bene_frag();
                Log.d("beneficiary layout",""+bundle.getLong("customer id"));
                bene_frag.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.container,bene_frag).addToBackStack(null).commit();
                break;

        }
    }

    public void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy","checking");
        flag=false;
    }

    public void onPause() {
        super.onPause();
        Log.d("onPause","checking");
        flag=false;
    }

    public void onResume() {
        super.onResume();
        Log.d("onResume", "checking");
        getActivity().setTitle("Bk_Home");
        Bk_Containt main=(Bk_Containt)getActivity();
        main.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        main.getmDrawerToggle().setDrawerIndicatorEnabled(true);
       // main.getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        main.getmDrawerToggle().syncState();
        flag=true;

    }
    @Override
    public void onStop() {
        super.onStop();
        Bk_Containt main=(Bk_Containt)getActivity();
        main.getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        main.getmDrawerToggle().setDrawerIndicatorEnabled(false);
        main.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        main.getmDrawerToggle().syncState();
    }


    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Home");
        Bk_Containt.title="Home";
    }
    public void initializeView(View view)
    {
        trans_layout = (RelativeLayout) view.findViewById(R.id.trans_Layout);
        forexLayout = (RelativeLayout) view.findViewById(R.id.forex_Layout);
        benefeciaryLayout = (RelativeLayout) view.findViewById(R.id.beneficiary_layout);
    }
    public void setListener()
    {
        trans_layout.setOnClickListener(this);
        forexLayout.setOnClickListener(this);
        benefeciaryLayout.setOnClickListener(this);
    }
    public void setBundle()
    {
        bundle=new Bundle();
        bundle=getArguments();
    }
    public void initializeDB(ViewGroup container)
    {
        context = container.getContext();
        mdbhandler=new dbHandler(context);
    }
}
