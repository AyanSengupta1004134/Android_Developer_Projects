package tcs.com.bankingsystem.Fragment;


import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.app.Fragment;
import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.R;

/**
 * Created by Anand Sharma on 9/26/2015.
 */
/*
* this fragment contains the framelayout in which normal transaction and favorite transaction is going to be fit.
 */
public class Bk_TransactionFragment extends Fragment {
   private Button normallist,starlist;
   private Bundle bundle;
    public static  boolean flag=false;

       public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
           View view=inflater.inflate(R.layout.bk_transaction_list,container,false);
           initializeView(view);
           setBundle();
           Bk_Transaction_list list= new Bk_Transaction_list();
           list.setArguments(bundle);
           getFragmentManager().beginTransaction().replace(R.id.listframelayout, list).commit();
           setListener();
           return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Transaction");
        Bk_Containt.title="Transaction";
    }
    public void initializeView(View view)
    {
        normallist=(Button)view.findViewById(R.id.listbutton);
        starlist=(Button)view.findViewById(R.id.starbutton);
    }
    public void setListener()
    {
        normallist.setBackgroundColor(Color.BLUE);
        starlist.setBackgroundColor(Color.GRAY);
        normallist.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                normallist.setBackgroundColor(Color.BLUE);
                starlist.setBackgroundColor(Color.GRAY);
                Bk_Transaction_list list = new Bk_Transaction_list();
                list.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.listframelayout, list).commit();
            }
        });
        starlist.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                normallist.setBackgroundColor(Color.GRAY);
                starlist.setBackgroundColor(Color.BLUE);
                Bk_Transaction_star_list star_list = new Bk_Transaction_star_list();
                star_list.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.listframelayout, star_list).commit();
            }
        });

    }
    public void setBundle()
    {
        bundle=new Bundle();
        bundle=getArguments();
    }
    @Override
    public void onResume() {
        super.onResume();
        Log.d("onResume", "checking");
        flag=true;

    }
}
