package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

import tcs.com.bankingsystem.Adapter.Transaction_star_row;
import tcs.com.bankingsystem.Beans.Transaction;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;

/**
 set the adapter for star or favourite transaction list
 */
public class Bk_Transaction_star_list extends Fragment {
   public static ArrayList<Transaction> transtarslist;
   private ListView list;
   private dbHandler db;
   private Bundle b;
   private int custId;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.star, container, false);
        list=(ListView)view.findViewById(R.id.starlistview);
        db=new dbHandler(container.getContext());
        setFavourite_Trans_ListAdapter();
        return view;
    }
    public long getBundle()
    {
        b=new Bundle();
        b=getArguments();
        custId=(int)b.getLong("customer id");
        return custId;
    }
    public void setFavourite_Trans_ListAdapter()
    {
        custId=(int)getBundle();
        transtarslist=new ArrayList<Transaction>();
        transtarslist=db.getstar_Transaction_list(custId);
        list.setAdapter(new Transaction_star_row(getActivity()));
    }
}
