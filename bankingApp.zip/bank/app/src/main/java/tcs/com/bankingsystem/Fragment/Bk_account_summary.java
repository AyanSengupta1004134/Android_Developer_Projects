package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.json.JSONException;

import java.io.IOException;

import tcs.com.bankingsystem.R;
import tcs.com.bankingsystem.Beans.Account;
import tcs.com.bankingsystem.Utilities.JSonReader;

/**
 * Created by 963492 on 9/23/2015.
 */
public class Bk_account_summary extends Fragment {
    private TextView custId, accountNo, holderName, accType, avalBalnce, contactNo, email;
    private Context context;
    private Account account;
    private Bundle bundle;
    private Long Id;
    public static boolean flag=false;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bk_account_summary, null);
        initializeView(view);
        getAccountDetail();
        return view;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        flag=true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy", "checking");
        flag=false;
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("onPause", "checking");
        flag=false;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("onResume", "checking");
        flag=true;

    }
    public void initializeView(View view)
    {
        custId=(TextView)view.findViewById(R.id.custId);
        accountNo=(TextView)view.findViewById(R.id.account_no);
        holderName= (TextView)view.findViewById(R.id.account_name);
        accType=(TextView)view.findViewById(R.id.account_type);
        avalBalnce=(TextView)view.findViewById(R.id.aval_balance);
        contactNo=(TextView)view.findViewById(R.id.contact_no);
        email=(TextView)view.findViewById(R.id.email);
    }
    /*
        get account detail from account jason file
     */
   public void getAccountDetail()
    {
        account=new Account();
        bundle=new Bundle();
        bundle=getArguments();
        Id=bundle.getLong("customer id");
        try {
            account= JSonReader.getAccountDetails(Id);
            custId.setText(Id+"");
            accountNo.setText(account.getAccount_no().toString());
            holderName.setText(account.getHolderName());
            accType.setText(account.getAccType());
            avalBalnce.setText((String.valueOf( account.getAvalBalnce())));
            contactNo.setText(account.getPhoneNo());
            email.setText(account.getEmail());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}