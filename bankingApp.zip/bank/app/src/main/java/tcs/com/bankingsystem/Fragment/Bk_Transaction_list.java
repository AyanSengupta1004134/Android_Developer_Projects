package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

import tcs.com.bankingsystem.Adapter.Transaction_row;
import tcs.com.bankingsystem.Beans.Transaction;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;

/*
	setting the adapter for the transaction list
 */
public class Bk_Transaction_list extends Fragment {
	private ListView list;
	private dbHandler handler;
	private Bundle b;
	private int custId;
	private Context context;
	public static ArrayList<Transaction> translist;
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View view=inflater.inflate(R.layout.transaction_list, container,false);
		initializeView(view);
		setTransactionList(container);
		transactionListViewSetup();
		return view;
	}
	public long getBundle()
	{
		b=new Bundle();
		b=getArguments();
		custId=(int)b.getLong("customer id");
		return custId;
	}
	public void setTransactionList(ViewGroup container)
	{
		custId=(int)getBundle();
		context=container.getContext();
		handler=new dbHandler(context);
		translist=new ArrayList<Transaction>();
		translist= handler.get_Transaction_list(custId);
	}
	public void initializeView(View view)
	{
		list=(ListView)view.findViewById(R.id.listView1);
	}
	public void transactionListViewSetup()
	{
		custId=(int)getBundle();
		list.setAdapter(new Transaction_row(context,custId));
		list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
				Bundle bundle=new Bundle();
				bundle.putSerializable("id",translist.get(i));
				Bk_Transaction_details f=new Bk_Transaction_details();
				f.setArguments(bundle);
				getFragmentManager().beginTransaction().replace(R.id.container, f).addToBackStack(null).commit();

			}
		});

	}


}
