package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.R;

/**
 * Created by Anand Sharma on 9/26/2015.
 */
/*
* this fragment has a framelayout in which normal recently_viewed_currency list and favourite_currency list is going to be fit.
 */
public class Bk_CurrencyFrameLayout extends Fragment {
    private Button normallist,starlist;
    private Bundle bundle;
    private Long custId;
    public static boolean flag=false;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.bk_currency_framelayout,container,false);
        initializeView(view);
        bundle=new Bundle();
        bundle=getArguments();
        Bk_ForexList list= new Bk_ForexList();
        list.setArguments(bundle);
        getFragmentManager().beginTransaction().replace(R.id.currencyframelayout, list).commit();
        buttonOnClickSetUp();
        return view;

    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        flag=true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy", "checking");
        flag=false;
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("onPause", "checking");
        flag=false;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("onResume", "checking");
        flag=true;

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Bk_Currency List");
        Bk_Containt.title="Bk_Currency List";
    }
    public void initializeView(View view)
    {
        normallist=(Button)view.findViewById(R.id.listbutton);
        starlist=(Button)view.findViewById(R.id.starbutton);
    }
    public void buttonOnClickSetUp()
    {
        normallist.setBackgroundColor(Color.BLUE);
        starlist.setBackgroundColor(Color.GRAY);
        normallist.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                normallist.setBackgroundColor(Color.BLUE);
                starlist.setBackgroundColor(Color.GRAY);
                Bk_ForexList list= new Bk_ForexList();
                list.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.currencyframelayout, list).commit();
            }
        });
        starlist.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                normallist.setBackgroundColor(Color.GRAY);
                starlist.setBackgroundColor(Color.BLUE);
                Bk_ForexStarList star_list= new Bk_ForexStarList();
                star_list.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.currencyframelayout,star_list).commit();
            }
        });
    }
}
