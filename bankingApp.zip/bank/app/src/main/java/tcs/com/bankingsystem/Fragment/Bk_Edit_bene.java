package tcs.com.bankingsystem.Fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;
import tcs.com.bankingsystem.Beans.beneficiary_class;

/**
 * Created by 963691 on 9/17/2015.
 */
public class Bk_Edit_bene extends Fragment {

     private Context context;
     private TextView tName, tBranch, tEmail, tAccno,tTitle;
     private EditText eName;
     private Button bEdit, bSave;
     private String sName;
     private Long sAccno;
     private beneficiary_class bclass;
     private Bundle bundle;
     private dbHandler mdbHandler;
     private Long custId;
     public static boolean flag=false;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bk_bene_details, container, false);
        initializeView(view);
        initializeDB(container);
        custId=getBundle();
        Log.d("bk_edit", custId + " ");
        textviewSetUp();
        buttonOnClickListner();
        return  view;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_bene_details, menu);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();
        if(id==R.id.del_bene) {
            AlertDialog.Builder alert = new AlertDialog.Builder(context);
            alert.setTitle("Delete");
            alert.setMessage("Are you sure to delete the beneficiary?");
            alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    mdbHandler.deleteBeneficiary(bclass.getAcc_no(),custId);
                    Bk_bene_frag frag=new Bk_bene_frag();
                    Bundle bunl=new Bundle();
                    bunl.putLong("customer id",custId);
                    frag.setArguments(bunl);
                    getFragmentManager().beginTransaction().replace(R.id.container,frag).addToBackStack(null).commit();

                }
            });
            alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            alert.show();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Edit Beneficiary");
        Bk_Containt.title="Edit Beneficiary";

    }
    public void initializeView(View view)
    {
        tName = (TextView) view.findViewById(R.id.tName);
        tBranch = (TextView) view.findViewById(R.id.tBranch);
        tEmail = (TextView) view.findViewById(R.id.tEmail);
        tAccno = (TextView) view.findViewById(R.id.tAcc);
        tTitle= (TextView) view.findViewById(R.id.tTitle);
        eName = (EditText) view.findViewById(R.id.eName);
        bEdit = (Button) view.findViewById(R.id.bEdit);
        bSave = (Button) view.findViewById(R.id.bSave);
    }
    public void textviewSetUp()
    {
        bclass = (beneficiary_class) bundle.getSerializable("beneficiary");
        tName.setText(bclass.getName());
        tBranch.setText(bclass.getBranch());
        tEmail.setText(bclass.getEmail());
        String acc = Long.toString(bclass.getAcc_no());
        tAccno.setText(acc);
    }
    public void buttonOnClickListner()
    {
        bEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tName.setVisibility(View.INVISIBLE);
                eName.setVisibility(View.VISIBLE);
                bSave.setVisibility(View.VISIBLE);
                eName.setText(bclass.getName());
                tTitle.setText("EDIT");
            }
        });
        bSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sName = eName.getText().toString();
                sAccno = bclass.getAcc_no();
                Bundle bunl = new Bundle();
                bunl.putLong("customer id", custId);
                mdbHandler.updateBeneficiaryName(sName, sAccno, custId);
                Toast.makeText(context, "Updated Successfully", Toast.LENGTH_SHORT).show();
                Bk_bene_frag frag = new Bk_bene_frag();
                frag.setArguments(bunl);
                getFragmentManager().beginTransaction().replace(R.id.container, frag).addToBackStack(null).commit();
            }
        });
    }
    public long getBundle()
    {
        bundle=new Bundle();
        bundle=getArguments();
        custId= bundle.getLong("customer id");
        return custId;
    }
    public void initializeDB(ViewGroup container)
    {
        context = container.getContext();

        mdbHandler=new dbHandler(context);
    }
}
