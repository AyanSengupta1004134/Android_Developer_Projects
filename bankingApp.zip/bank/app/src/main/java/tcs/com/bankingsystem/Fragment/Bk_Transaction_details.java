package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.Beans.Transaction;
import tcs.com.bankingsystem.R;

/**
 show the transaction detail
 */
public class Bk_Transaction_details extends Fragment {
    private TextView id,date,amount,description;
     public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.bk_transaction_detail, container, false);
        initializeView(view);
        setTransactionDetail();
        Bk_TransactionFragment.flag=false;
        return view;
}

   @Override
   public void onActivityCreated(Bundle savedInstanceState) {
      super.onActivityCreated(savedInstanceState);
      ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Transaction Detail");
      Bk_Containt.title="Transaction Detail";
   }
   public void initializeView(View view)
   {
      id= (TextView) view.findViewById(R.id.id);
      date= (TextView) view.findViewById(R.id.date);
      amount= (TextView) view.findViewById(R.id.amount);
      description= (TextView) view.findViewById(R.id.description);
   }
   public void setTransactionDetail()
   {
      Bundle bundle=getArguments();
      Transaction transaction= (Transaction) bundle.getSerializable("id");
      String trans_id=transaction.getId().toString();
      String trans_date=transaction.getDate().toString();
      String trans_amt=transaction.getAmount().toString();
      String trans_des=transaction.getDescription().toString();
      id.setText(trans_id);
      date.setText(trans_date);
      amount.setText(trans_amt);
      description.setText(trans_des);
   }

   @Override
   public void onDestroy() {
      super.onDestroy();
   }
}
