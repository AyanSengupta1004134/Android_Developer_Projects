package tcs.com.bankingsystem.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

import java.util.Timer;
import java.util.TimerTask;

import tcs.com.bankingsystem.R;

/**
 * Created by 986716 on 9/16/2015.
 */
public class Bk_Splash extends Activity {
    Timer timer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.bk_splash);
        timer=new Timer();
        timer.schedule(new TimerTask() {

            @Override
            public void run() {
                Intent intent = new Intent(Bk_Splash.this, Bk_FragmentContainer.class);
                startActivity(intent);
                finish();

            }
        }, 1000);
        setContentView(R.layout.bk_splash);
    }
}
