package tcs.com.bankingsystem.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

import tcs.com.bankingsystem.Beans.Bk_Currency;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;

/**
 * Created by Anand Sharma on 9/26/2015.
 */
public class CurrencyStarAdapter extends BaseAdapter {
    private Context mcontext;
    private dbHandler handler;
    private long custId;
    private ArrayList<Bk_Currency> currencystarlist;
    public CurrencyStarAdapter(Context context,long custId)
    {
        mcontext=context;
        this.custId=custId;
        handler=new dbHandler(context);
        currencystarlist=new ArrayList<Bk_Currency>();
        currencystarlist=handler.getFavoriteListOfCurrency(custId);
        Log.d("fav",""+currencystarlist.size());
    }

    @Override
    public int getCount() {
        return currencystarlist.size();
    }

    @Override
    public Object getItem(int position) {
        return currencystarlist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflater=(LayoutInflater)mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row=inflater.inflate(R.layout.bk_currenct_star_row,viewGroup,false) ;
        TextView currencyPair=(TextView)row.findViewById(R.id.currencylist);
        TextView rate=(TextView)row.findViewById(R.id.rate);
        ImageButton img=(ImageButton)row.findViewById(R.id.imageView1);

        Bk_Currency temp=currencystarlist.get(position);
        img.setImageResource(android.R.drawable.btn_star_big_on);

        currencyPair.setText(temp.getCurrencyPair());

        rate.setText(temp.getForexRate());
        return row;
    }
}
