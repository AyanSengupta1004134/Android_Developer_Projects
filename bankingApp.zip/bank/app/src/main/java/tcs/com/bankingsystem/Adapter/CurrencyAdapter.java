package tcs.com.bankingsystem.Adapter;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

import tcs.com.bankingsystem.Beans.Bk_Currency;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.Fragment.Bk_CurrencyFrameLayout;
import tcs.com.bankingsystem.R;

/**
 * Created by Anand Sharma on 9/26/2015.
 */
public class CurrencyAdapter extends BaseAdapter {
   private ArrayList<Bk_Currency> currencylist;
   private Context context;
   private long custId;
   private dbHandler dbhandler;
    public CurrencyAdapter(Context context,long custId)
    {
        this.custId=custId;
        dbhandler=new dbHandler(context);
        currencylist=new ArrayList<Bk_Currency>();
        currencylist=dbhandler.getAllListOfCurrency(custId);
        this.context=context;
    }

    @Override
    public int getCount() {
        return currencylist.size();
    }

    @Override
    public Object getItem(int position) {
        return currencylist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v=convertView;
        View row=inflater.inflate(R.layout.bk_currency_row,viewGroup,false) ;
        TextView currencyPair=(TextView)row.findViewById(R.id.currencylist);
        TextView currencyRate=(TextView)row.findViewById(R.id.rate);
        ImageButton img=(ImageButton)row.findViewById(R.id.imageView1);

       final Bk_Currency temp=currencylist.get(position);
       if(!dbhandler.isFavorite(temp.getCurrencyPair(),custId)) {
            img.setImageResource(android.R.drawable.btn_star_big_off);
        }
        else {
            img.setImageResource(android.R.drawable.btn_star_big_on);

        }
        currencyPair.setText(temp.getCurrencyPair());

        currencyRate.setText(temp.getForexRate());

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbhandler.updateFavData(temp.getCurrencyPair(),custId);
                Log.d("paaair",temp.getCurrencyPair());
                Bk_CurrencyFrameLayout list= new Bk_CurrencyFrameLayout();
                Bundle b=new Bundle();
                b.putLong("customer id", custId);
                list.setArguments(b);
                ((Activity) context).getFragmentManager().beginTransaction().replace(R.id.currencyframelayout, list).commit();
            }
        });
        return row;
    }
}
