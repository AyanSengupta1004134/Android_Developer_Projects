package tcs.com.bankingsystem.Fragment;


import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;
import tcs.com.bankingsystem.Beans.beneficiary_class;

/**
 * Created by 1004134 on 9/23/2015.
 */
public class Bk_fund_transfer extends Fragment {

    private Spinner ben_name;
    private EditText amount;
    private Button transfer;
    private TextView branch,email;
    private Context context;
    private Bundle bundle;
    private Long custId;
    private String[] name;
    private ArrayList<beneficiary_class> arrfund;
    private dbHandler dbHandler;
    private Double balance;
    public static boolean flag=false;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.bk_fund_transfer,null,false);
        initializeView(view);
        initializeDB(container);
        custId= getBundle();
        arrfund=new ArrayList<beneficiary_class>();
        arrfund=dbHandler.readAllbeneficiariesfund(custId);
        balance=getBalanceFromJson();
        buttonOnClickSetUp();
        spinnerOnItemSelected();
        return view;
    }

    public String[] returnname(ArrayList<beneficiary_class> arrfund)
    {
        String arr[] = new String[arrfund.size()];
        for(int i=0;i<arrfund.size();i++)
        {
            arr[i]=arrfund.get(i).getName();
        }

        return arr ;
    }

    public Double getBalanceFromJson()
    {
        String strJson=readjsonfile();
        String data = "";
        Double avalBaln=0.0;
        try {
            JSONObject jsonRootObject = new JSONObject(strJson);

            //Get the instance of JSONArray that contains JSONObjects
            JSONArray jsonArray = jsonRootObject.optJSONArray("Accounts");

            //Iterate the jsonArray and print the info of JSONObjects
            for(int i=0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                int id = (jsonObject.optInt("id"));
                if (id == custId) {

                    avalBaln = Double.parseDouble(jsonObject.optString("AvailableBalance"));
                    Log.d("balance is",""+avalBaln);

                }
            }

        } catch (JSONException e) {e.printStackTrace();}
        return avalBaln;
    }

    public String readjsonfile()
    {
        StringBuilder builder=new StringBuilder();
        File file = new File(Environment.getExternalStorageDirectory(), "accounts.txt");
        if(file.exists())
        {

            try {
                BufferedReader br =new BufferedReader(new FileReader(file));
                String line;
                while((line=br.readLine())!=null)
                {
                    builder.append(line);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return builder.toString();

    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        flag=true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy", "checking");
        flag=false;
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("onPause", "checking");
        flag=false;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("onResume", "checking");
        flag=true;

    }

public void initializeView(View view)
{
    ben_name= (Spinner) view.findViewById(R.id.spinner2);
    amount= (EditText) view.findViewById(R.id.amount);
    transfer= (Button) view.findViewById(R.id.fund);
    branch= (TextView) view.findViewById(R.id.accno);
    email= (TextView) view.findViewById(R.id.email);
}
    public void buttonOnClickSetUp()
    {
        transfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (ben_name.getCount() == 0) {
                    Toast.makeText(context,"Benificiary is not added",Toast.LENGTH_SHORT).show();
                } else {
                    if (amount.getText().toString().equals("")) {
                        AlertDialog.Builder alert = new AlertDialog.Builder(context);
                        alert.setTitle("Delete");
                        alert.setMessage("Please give the amount");
                        Toast.makeText(context, "Enter amount", Toast.LENGTH_SHORT).show();
                    } else {
                        Double a;
                        a = Double.valueOf(amount.getText().toString());
                        if (a < balance) {
                            Bk_Home home = new Bk_Home();
                            home.setArguments(bundle);
                            getFragmentManager().beginTransaction().replace(R.id.container, home).commit();
                            Toast.makeText(context, "Fund is tranfered", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(context, "Check your amount", Toast.LENGTH_LONG).show();
                        }

                        a = 0.0;
                        Log.d("a is", "" + a);
                    }
                }
            }
        });
    }
    public void spinnerOnItemSelected()
    {
        name=returnname(arrfund);
        ben_name.setAdapter(new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, name));
        ben_name.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //acc.setText( String.valueOf(arrfund.get(i).getAcc_no()));
                branch.setText(arrfund.get(i).getBranch().toString());
                email.setText(arrfund.get(i).getEmail().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    public void initializeDB(ViewGroup container)
    {
        context=container.getContext();
        dbHandler=new dbHandler(context);
    }
    public long getBundle()
    {
        bundle=new Bundle();
        bundle=getArguments();
        custId= bundle.getLong("customer id");
        return custId;
    }
}
