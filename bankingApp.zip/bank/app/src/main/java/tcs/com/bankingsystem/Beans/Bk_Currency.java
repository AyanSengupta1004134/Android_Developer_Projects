package tcs.com.bankingsystem.Beans;

/**
 * Created by Anand Sharma on 9/26/2015.
 */
public class Bk_Currency {

    private String currencyPair;
    private String forexRate;

    public Bk_Currency(String currencyPair, String forexRate) {
        this.forexRate = forexRate;
        this.currencyPair = currencyPair;

    }

    public String getCurrencyPair() {
        return currencyPair;
    }

    public void setCurrencyPair(String currencyPair) {
        this.currencyPair = currencyPair;
    }

    public String getForexRate() {
        return forexRate;
    }

    public void setForexRate(String forexRate) {
        this.forexRate = forexRate;
    }


}
