package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import tcs.com.bankingsystem.Activity.Bk_FragmentContainer;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;


/**
 * Created by 986623 on 9/21/2015.
 */
public class Bk_ForgotPassword extends Fragment {
    TextView security_question,tv_title,tv1,tv2,tv3,tv4;
    EditText custumer_id,security_answer,enter_password,re_enter_password;
    Context context;
    dbHandler mdbHandler;
    Button sumbitbtn,changepwd_btn,sumbit_password;
    String result;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.bk_forgotpassword,container,false);
        initializeView(view);
        initializeDB(container);
        buttonOnclickListenerSetUp();
        Bk_FragmentContainer.flag=2;
        return view;
    }
    public static boolean isNumeric(String str) {
        int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (Character.isDigit(str.charAt(i)) == false) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void onDestroy() {
        Bk_FragmentContainer.flag=1;
        super.onDestroy();
    }
    public void initializeView(View view)
    {
        tv_title= (TextView) view.findViewById(R.id.tv_display);
        sumbitbtn=(Button)view.findViewById(R.id.forgot_sumbit_btn);
        custumer_id=(EditText)view.findViewById(R.id.et_custId_ForgotPassword);
        security_question=(TextView)view.findViewById(R.id.securityQuestion);
        security_answer= (EditText) view.findViewById(R.id.forgot_password_answer);
        changepwd_btn=(Button)view.findViewById(R.id.forgot_changepwd_btn);
        tv1= (TextView) view.findViewById(R.id.textView4);
        tv2= (TextView) view.findViewById(R.id.textView2);
        sumbit_password=(Button)view.findViewById(R.id.forgot_changepwd_sumbit_btn);
        tv3= (TextView) view.findViewById(R.id.text_new_password);
        tv4= (TextView) view.findViewById(R.id.textconfirm_pwd);
        enter_password= (EditText) view.findViewById(R.id.new_password);
        re_enter_password= (EditText) view.findViewById(R.id.et_newPasswordConfirm_forgot);

    }
    public void buttonOnclickListenerSetUp()
    {
        sumbitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Long id=0L;
                if(!custumer_id.getText().toString().isEmpty()&&isNumeric(custumer_id.getText().toString()))
                    id=Long.parseLong((custumer_id.getText().toString()));
                if(custumer_id.getText().toString().isEmpty())
                    custumer_id.setError("Enter Customer id");
                else if(!isNumeric(custumer_id.getText().toString()))
                    custumer_id.setError("enter valid Customer Id");
                else if(!mdbHandler.isCustIdAlreadyRegistered(id))
                    custumer_id.setError("Customer ID is not Registered..First Register yourself");
                else{
                    custumer_id.setFocusable(false);
                    custumer_id.setClickable(false);
                    custumer_id.setEnabled(false);
                    security_question.setText(mdbHandler.returnRegistertedSecurityQuestion(custumer_id.getText().toString()));
                    tv_title.setVisibility(View.INVISIBLE);
                    sumbitbtn.setVisibility(View.INVISIBLE);
                    changepwd_btn.setVisibility(View.VISIBLE);
                    tv1.setVisibility(View.VISIBLE);
                    tv2.setVisibility(View.VISIBLE);
                    security_answer.setVisibility(View.VISIBLE);
                    security_question.setVisibility(View.VISIBLE);
                }


            }
        });
        changepwd_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                custumer_id.setFocusable(false);
                custumer_id.setClickable(false);
                custumer_id.setEnabled(false);
                Log.d("gautam","change pwd btn");
                String securityAnswer=security_answer.getText().toString();
                result=mdbHandler.returnRegistertedSecurityAnswer(custumer_id.getText().toString());
                Log.d("returned answer",result);
                Log.d("security ans emulator",securityAnswer);
                if(result.equals(securityAnswer))
                {
                    Toast.makeText(context,"Please enter new password",Toast.LENGTH_LONG).show();
                    changepwd_btn.setVisibility(View.INVISIBLE);
                    tv1.setVisibility(View.INVISIBLE);
                    tv2.setVisibility(View.INVISIBLE);
                    security_question.setVisibility(View.INVISIBLE);
                    security_answer.setVisibility(View.INVISIBLE);
                    tv3.setVisibility(View.VISIBLE);
                    tv4.setVisibility(View.VISIBLE);

                    sumbit_password.setVisibility(View.VISIBLE);
                    enter_password.setVisibility(View.VISIBLE);
                    re_enter_password.setVisibility(View.VISIBLE);
                    re_enter_password.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (hasFocus) {
                                if (enter_password.getText().toString().length() < 8)
                                    enter_password.setError("Password Too Short");
                                else if (enter_password.getText().toString().isEmpty())
                                    enter_password.setError("Enter New Password");
                            }

                        }
                    });
                    sumbit_password.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            custumer_id.setFocusable(false);
                            custumer_id.setClickable(false);
                            custumer_id.setEnabled(false);
                            if (re_enter_password.getText().toString().isEmpty())
                                re_enter_password.setError("Enter confirm Password");
                            if(!enter_password.getText().toString().equals(re_enter_password.getText().toString()))
                                re_enter_password.setError("Passwords do not match");
                            else{
                                mdbHandler.updatePassword(Long.parseLong(custumer_id.getText().toString()),enter_password.getText().toString());
                                Bk_login bk_login=new Bk_login();
                                getFragmentManager().beginTransaction().replace(R.id.framelayout,bk_login).addToBackStack(null).commit();
                            }

                        }
                    });
                }
                else
                {
                    Toast.makeText(context,"Enter correct answer",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
    public void initializeDB(ViewGroup container)
    {
        context=container.getContext();

        mdbHandler=new dbHandler(context);
    }
}
