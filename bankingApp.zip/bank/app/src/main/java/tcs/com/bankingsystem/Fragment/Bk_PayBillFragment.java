package tcs.com.bankingsystem.Fragment;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.R;
import tcs.com.bankingsystem.Utilities.JSonReader;

/**
 * Created by 963691 on 9/24/2015.
 */
public class Bk_PayBillFragment extends Fragment {
    private TextView tHead, tCardNo, tCardName,tATMpin;
    private EditText eCardNo, eCardName,eATMpin, eCVV;
    private Spinner spinMonth, spinYear;
    private Button bSubmit, bViewDetails;
    private CheckBox checkBox;
    private   SharedPreferences.Editor editor;
    private SharedPreferences sharedPreferences;
    private Context context;
    private Bundle bundle;
    private boolean flag=false;
    public static boolean mflag=false;
    private long custId;
    private long cardnojson=0l;
    private String cardname=null;
    private int CVV;
    private long month;
    private String date,datejson;
    private long year;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.paybill,container,false);
        initializeView(view);
        context=container.getContext();
        bundle =new Bundle();
        bundle=getArguments();
        custId=bundle.getLong("customer id");

        jsonparser();
        ArrayAdapter adapteryear = ArrayAdapter.createFromResource(getActivity(), R.array.year, android.R.layout.simple_spinner_item);
        adapteryear.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinYear.setAdapter(adapteryear);
        spinYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
               year=i+14;
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinMonth = (Spinner) view.findViewById(R.id.spinner);

        ArrayAdapter adaptermonth = ArrayAdapter.createFromResource(getActivity(), R.array.months, android.R.layout.simple_spinner_item);

        adaptermonth.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinMonth.setAdapter(adaptermonth);
        spinMonth.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                month = i;

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        eCVV = (EditText) view.findViewById(R.id.eCVV);
        bSubmit = (Button) view.findViewById(R.id.button);




        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    flag = true;
                }
            }
        });

        eCardName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (eCardNo.getText().toString().equals(""))
                    eCardNo.setError("enter the card No. first");
                else if (!eCardNo.getText().toString().equals(String.valueOf(cardnojson))) {
                    eCardNo.setError("You have enter an invalid card No.");
                }
            }
        });
        eATMpin.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if(eCardName.getText().toString().equals(""))
                    eCardName.setError("enter the card name");
                else if(!eCardName.getText().toString().equals(cardname))
                {
                    eCardName.setError("You have enter an invalid card name");
                }
            }
        });

        bSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                date=month+"/"+year;
                if(eCardNo.getText().toString().equals("")||eCardName.getText().toString().equals("")||eATMpin.getText().toString().equals("")||spinMonth.getSelectedItem().toString().equals("")||spinYear.getSelectedItem().toString().equals("")||eCVV.getText().toString().equals(""))
                    Toast.makeText(getActivity(),"Please enter all the credentials",Toast.LENGTH_SHORT).show();

                else if(!eCVV.getText().toString().equals(String.valueOf(CVV)))
                {
                    eCVV.setError("Enter correct CVV");
                }
                else if(!date.equals(datejson))
                {
                    Toast.makeText(getActivity(),"Please check your expiry date",Toast.LENGTH_SHORT).show();

                }
                else if(eATMpin.getText().length()!=4)
                {
                    eATMpin.setError("Enter correct ATM pin");
                }
                else
                {
                    if(flag)
                    {
                        sharedPreferences = getActivity().getSharedPreferences("values", Context.MODE_PRIVATE);
                        editor = sharedPreferences.edit();
                         editor.putString("cardNo", eCardNo.getText().toString());
                        editor.putString("cardname", eCardName.getText().toString());
                        editor.putLong("id",custId);
                        Bk_PayBillFragment payBillFragment=new Bk_PayBillFragment();
                        payBillFragment.setArguments(bundle);
                        getFragmentManager().beginTransaction().replace(R.id.container, payBillFragment).addToBackStack(null).commit();
                        editor.commit();

                    }
                    else
                    {
                        Bk_PayBillFragment payBillFragment=new Bk_PayBillFragment();
                        payBillFragment.setArguments(bundle);
                        getFragmentManager().beginTransaction().replace(R.id.container, payBillFragment).commit();
                    }

                }
            }
        });

        bViewDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sharedPreferences = getActivity().getSharedPreferences("values", Context.MODE_PRIVATE);
                if(sharedPreferences.getLong("id",100)==200)
                {
                    Toast.makeText(getActivity(),"Your data is not saved recently",Toast.LENGTH_LONG).show();
                }
                if(custId==sharedPreferences.getLong("id",100)) {
                    String cardNo = sharedPreferences.getString("cardNo", "");
                    String cardName = sharedPreferences.getString("cardname", "");
                    eCardNo.setText(cardNo);
                    eCardName.setText(cardName);

                }
                else
                {
                    Toast.makeText(getActivity(),"Your data is not saved recently",Toast.LENGTH_LONG).show();
                }
            }
        });

        return view;
    }


    public void jsonparser()
    {
        String strJson=readjsonfile();
        String data = "";

        try {
            JSONObject jsonRootObject = new JSONObject(strJson);


            JSONArray jsonArray = jsonRootObject.optJSONArray("Accounts");


            for(int i=0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                int id = (jsonObject.optInt("id"));
                if (id == custId) {
                    cardnojson=Long.parseLong(jsonObject.optString("CardNo"));
                    cardname=jsonObject.optString("NameOnCard");
                    CVV=Integer.parseInt(jsonObject.optString("CVV"));

                    datejson=jsonObject.optString("ExpiryDate");



                }
            }

        }
        catch (JSONException e)
        {e.printStackTrace();}

    }

    public String readjsonfile()
    {
        StringBuilder builder=new StringBuilder();
        File file = new File(Environment.getExternalStorageDirectory(), "accounts.txt");
        if(file.exists())
        {

            try {
                BufferedReader br =new BufferedReader(new FileReader(file));
                String line;
                while((line=br.readLine())!=null)
                {
                    builder.append(line);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return builder.toString();

    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mflag=true;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mflag=false;
    }

    @Override
    public void onPause() {
        super.onPause();
        mflag=false;
    }

    @Override
    public void onResume() {
        super.onResume();
        mflag=true;

    }
    public void initializeView(View view)
    {
        checkBox = (CheckBox) view.findViewById(R.id.checkBox);
        bViewDetails = (Button) view.findViewById(R.id.button2);
        tHead = (TextView) view.findViewById(R.id.CDcard);
        tCardNo = (TextView) view.findViewById(R.id.tCardNo);
        tCardName = (TextView) view.findViewById(R.id.tNameOnCard);
        eCardName = (EditText) view.findViewById(R.id.eNameOnCard);
        tATMpin = (TextView) view.findViewById(R.id.tATMpin);
        eATMpin = (EditText) view.findViewById(R.id.eATMpin);
        eCardNo = (EditText) view.findViewById(R.id.eCardNo);
        spinYear = (Spinner) view.findViewById(R.id.spinner2);
    }
}