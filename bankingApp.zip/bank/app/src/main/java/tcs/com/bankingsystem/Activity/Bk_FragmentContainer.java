package tcs.com.bankingsystem.Activity;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.Fragment.Bk_login;
import tcs.com.bankingsystem.R;

/**
 * Created by 986716 on 9/16/2015.
 */
public class Bk_FragmentContainer extends AppCompatActivity {
   private dbHandler mdbHAndler;
    private Toolbar toolbar;
    public static int flag=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mdbHAndler=new dbHandler(this);
        setContentView(R.layout.bk_fragment_container);
        toolbar=(Toolbar)findViewById(R.id.app);
        setSupportActionBar(toolbar);
        FragmentManager fragmentManager=getFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.framelayout, new Bk_login(),"f2");
        fragmentTransaction.commit();


    }
    public void onBackPressed() {
       if(flag==1){
            finish();
       }
        else {
            getFragmentManager().popBackStackImmediate();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
