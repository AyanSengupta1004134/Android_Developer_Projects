package tcs.com.bankingsystem.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import tcs.com.bankingsystem.R;

/**
 * Created by 986716 on 9/24/2015.
 */
public class DrawerListAdapter extends BaseAdapter{

    private Context mcontext;
    public DrawerListAdapter(Context context)
    {
        mcontext=context;
    }

    @Override
    public int getCount() {
        return 7;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater=(LayoutInflater)mcontext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row=inflater.inflate(R.layout.bk_navigation_drawer_singlerow,viewGroup,false) ;
        TextView itemname=(TextView)row.findViewById(R.id.itemname);
        ImageView image=(ImageView)row.findViewById(R.id.imagedrawer);
        if(i==0) {
            image.setImageResource(R.drawable.emiico);
            itemname.setText(R.string.EMI);
        }
        if(i==1){
            image.setImageResource(R.drawable.accountsummary);
            itemname.setText(R.string.Account_Summary);
        }
        if(i==2){
            image.setImageResource(R.drawable.fundtransfer);
            itemname.setText(R.string.Funds_transfer);
        }
        if(i==3){
            image.setImageResource(R.drawable.changepassword);
            itemname.setText(R.string.Change_Password);
        }
        if(i==4){
            image.setImageResource(R.drawable.remove_user);
            itemname.setText(R.string.Delete_Account);
        }
        if(i==5){
            image.setImageResource(R.drawable.paybill);
            itemname.setText(R.string.PayBill);
        }
        if(i==6){
            image.setImageResource(R.drawable.logout);
            itemname.setText(R.string.Log_out);
        }
        return row;
    }
}
