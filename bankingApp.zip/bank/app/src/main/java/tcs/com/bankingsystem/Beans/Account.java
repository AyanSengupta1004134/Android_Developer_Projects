package tcs.com.bankingsystem.Beans;

import java.io.Serializable;

/**
 * Created by 963492 on 9/23/2015.
 */
public class Account implements Serializable {
    private String holderName;
    private String accType;
    private String email;
    private  String phoneNo;
    private int custId;
    private Long account_no;
    private double  avalBalnce;


    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public String getAccType() {
        return accType;
    }

    public void setAccType(String accType) {
        this.accType = accType;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public Long getAccount_no() {
        return account_no;
    }

    public void setAccount_no(Long account_no) {
        this.account_no = account_no;
    }

    public double getAvalBalnce() {
        return avalBalnce;
    }

    public void setAvalBalnce(double avalBalnce) {
        this.avalBalnce = avalBalnce;
    }



}
