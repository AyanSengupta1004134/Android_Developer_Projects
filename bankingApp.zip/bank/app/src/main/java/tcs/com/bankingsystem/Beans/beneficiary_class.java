package tcs.com.bankingsystem.Beans;

import java.io.Serializable;

/**
 * Created by 963691 on 9/17/2015.
 */
public class beneficiary_class implements Serializable {
    private String name;
    private String branch;
    private String email;
    private int id ;
    private Long acc_no;
    private boolean selected = false;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public beneficiary_class(String name, Long acc_no, String branch, String email) {

        this.name = name;

        this.branch = branch;

        this.acc_no = acc_no;

        this.email = email;
    }

    public String getBranch() {
        return branch;
    }

    public String getName() {
        return this.name;
    }

    public int getId() {
        return id;
    }

    public Long getAcc_no() {
        return this.acc_no;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setAcc_no(Long acc_no) {
        this.acc_no = acc_no;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    public String toString(){
        return this.name + "   " +this.acc_no;
    }
}
