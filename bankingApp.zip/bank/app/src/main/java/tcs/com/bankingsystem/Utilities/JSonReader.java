package tcs.com.bankingsystem.Utilities;

import android.os.Environment;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import tcs.com.bankingsystem.Beans.Account;

/**
 * Created by 963691 on 9/22/2015.
 */
public class JSonReader {

    private Account account;
    private static long cardNo;
    private static int cVv,atmPin;
    private static String cardName;
    /*
    this method will check whether the customer id is present in the JSON file
     */
    public static boolean checkAccount(Long Id) throws IOException, JSONException {
        boolean res = false;
        String data = StringReadFromFile();
        Log.d("char",data.substring(1132,1140)+"");
        JSONObject mYRootObject = new JSONObject(data);

        JSONArray myArray = mYRootObject.optJSONArray("Accounts");
        for (int i = 0; i < myArray.length(); i++) {
            JSONObject jsonObject = myArray.getJSONObject(i);
            Long id = Long.parseLong(jsonObject.optString("id"));
            if (Id.equals(id)) {
                res = true;
            }
        }
        return res;
    }
    /*
    this method will read JSON file and return a string
    */
    public static String StringReadFromFile() throws IOException {
        File readFile = new File(Environment.getExternalStorageDirectory(), "accounts.txt");
        FileInputStream fin = new FileInputStream(readFile);
        int c;
        String temp = "";
        while ((c = fin.read()) != -1) {
            temp = temp + Character.toString((char) c);
        }
        fin.close();
        return temp;
    }
    /*
    this method return the Account details for the particular customer id
     */
    public static Account getAccountDetails(Long Id) throws IOException, JSONException {
        String data = StringReadFromFile();
        Account account = new Account();
        JSONObject mYRootObject = new JSONObject(data);
        JSONArray myArray = mYRootObject.optJSONArray("Accounts");
        for (int i = 0; i < myArray.length(); i++) {
            JSONObject jsonObject = myArray.getJSONObject(i);
            Long id = Long.parseLong(jsonObject.optString("id"));
            if (Id.equals(id)) {
                String name = jsonObject.optString("AccountName");
                Long accountNo = Long.parseLong(jsonObject.optString("AccountNo"));
                String accType = jsonObject.optString("Type");
                Double avalBaln = Double.parseDouble(jsonObject.optString("AvailableBalance"));
                String email = jsonObject.optString("Email");
                String phoneNo = jsonObject.getString("ContactNo");
                account.setAccount_no(accountNo);
                account.setHolderName(name);
                account.setAccType(accType);
                account.setAvalBalnce(avalBaln);
                account.setEmail(email);
                account.setPhoneNo(phoneNo);

            }
        }
        return account;

    }
    /*
    this method will validate the card details with that stored in the server here JSON
     */
    public static boolean validateCardDetails(long CardNo, String CardName, int CVV, int AtmPin) throws IOException, JSONException {
        boolean res=false;
        String data=StringReadFromFile();
        JSONObject mYRootObject = new JSONObject(data);
        JSONArray myArray = mYRootObject.optJSONArray("Accounts");
        for(int i=0; i < myArray.length(); i++){
            JSONObject jsonObject = myArray.getJSONObject(i);
            cardNo=jsonObject.optLong("CardNo");
            cardName=jsonObject.optString("NameOnCard");
            cVv=jsonObject.optInt("CVV");
            atmPin=jsonObject.optInt("AtmPin");
            Log.d("CardName", CardName);
            Log.d("cardName",cardName);
            Log.d("customer1",cardName+cardNo+cVv);
            if(CardName.equals(cardName)) {
                if(CVV==cVv){
                    if(CardNo==cardNo){
                        if(atmPin==AtmPin) {
                            res = true;
                            break;
                        }
                    }
                }
            }
        }
        return res;
    }
}