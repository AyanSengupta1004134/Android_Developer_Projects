package tcs.com.bankingsystem.Fragment;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import tcs.com.bankingsystem.Activity.Bk_Containt;
import tcs.com.bankingsystem.Database.dbHandler;
import tcs.com.bankingsystem.R;

/**
 * Created by 963691 on 9/17/2015.
 */
public class Bk_add_beneficiary extends Fragment {
   private Context context;
   private EditText eName,eBranch,eAcc,eEmail;
   private Button bAdd;
   private String sName,sBranch,sAcc,sEmail;
   private Bundle bundle;
   private dbHandler mdbHandler;
   private Long id;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bk_add_beneficiary,null);
        context=container.getContext();
        initializeView(view);
        validation();
        return view;
    }

    public void initializeView(View view)
    {
        eName = (EditText) view.findViewById(R.id.Name);
        eBranch = (EditText) view.findViewById(R.id.Branch);
        eAcc = (EditText) view.findViewById(R.id.AccountNo);
        eEmail = (EditText) view.findViewById(R.id.Email);
        bAdd = (Button) view.findViewById(R.id.AddBeneficiary);
    }
    public void validation()
    {
    eAcc.setOnFocusChangeListener(new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if(hasFocus){

                if(eName.getText().toString().isEmpty()) {
                    eName.setError("Enter Beneficiary name ");
                }

                else if(eName.getText().toString().length()<=1)
                {
                    eName.setError(" Enter valid name");
                }

            }
        }
    });

    eBranch.setOnFocusChangeListener(new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if(hasFocus){
                if(eAcc.getText().toString().isEmpty()){
                    eAcc.setError("Enter the Account No");
                }
                else if(eAcc.getText().toString().length()!=12||(eAcc.getText().toString().equals("000000000000"))) {
                    eAcc.setError("Enter valid Account No");
                }
            }
        }
    });
    eEmail.setOnFocusChangeListener(new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if(hasFocus) {
                if (eBranch.getText().toString().isEmpty()) {
                    eBranch.setError("Enter the Branch");
                }else if(eAcc.getText().toString().length() != 12 ||(eAcc.getText().toString().equals("000000000000"))) {
                    eAcc.setError("Enter valid Account No");
                }
                else if(eBranch.getText().toString().length()<=1)
                {
                    eBranch.setError("Enter the valid Branch Name");
                }
            }
        }
    });
    bAdd.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            String regExpn = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
            sName = eName.getText().toString();
            sBranch = eBranch.getText().toString();
            sAcc = eAcc.getText().toString();
            sEmail = eEmail.getText().toString();
            Pattern pattern = Pattern.compile(regExpn, Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(sEmail);

            if (sName.isEmpty()) {
                eName.setError("Enter Beneficiary name ");
            } else if (sName.length() <= 1) {
                eName.setError(" Enter valid name");
            } else if(sAcc.isEmpty()){
                eAcc.setError("Enter the Account No");
            }
            else if(sAcc.length()!=12||sAcc.equals("000000000000")){
                eAcc.setError("Enter valid Account No");
            }else if (sBranch.isEmpty()) {
                eBranch.setError("Enter the Branch");
            }
            else if(sBranch.length()<=1)
            {
                eBranch.setError("Enter the valid Branch Name");
            } else if(sEmail.isEmpty())
            {
                eEmail.setError("Enter the Email");
            }
            else if (!sEmail.matches(regExpn)){
                eEmail.setError("Enter the valid Email");
            }
            else {
                mdbHandler=new dbHandler(context);
                bundle=getArguments();
                id=bundle.getLong("customer id");
                Log.d("add beneficiary",id+" ");
                mdbHandler.insertBeneficiary(id, sName, sAcc, sEmail, sBranch);
                Bk_bene_frag frag = new Bk_bene_frag();
                frag.setArguments(bundle);
                getFragmentManager().beginTransaction().replace(R.id.container, frag).addToBackStack(null).commit();
            }
        }


    });
    }
    public static boolean isNumeric(String str) {
        int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (Character.isDigit(str.charAt(i)) == false) {
                return true;
            }
        }
        return false;
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Add Beneficiary");
        Bk_Containt.title="Add Beneficiary";

    }

}
