package com.example.ion.khanapalace.Activity;


import android.app.Activity;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ion.khanapalace.R;

public class SplashActivity extends Activity {


    TextView text1,text2;

    Thread splashTread;
    private Handler mHandler = new Handler();
    private Handler mHandler1 = new Handler();

    private Runnable mUpdateTimeTask = new Runnable()
    {
        public void run()
        {
            // Code to hide textview
            text1.setVisibility(View.VISIBLE);

        }
    };

    private Runnable mUpdateTimeTask1 = new Runnable()
    {
        public void run()
        {
            // Code to hide textview

            text2.setVisibility(View.VISIBLE);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        StartAnimations();
        text1 = (TextView) findViewById(R.id.text1);
        text2 = (TextView) findViewById(R.id.text2);
        mHandler.postDelayed(mUpdateTimeTask, 2000);
        mHandler1.postDelayed(mUpdateTimeTask1, 2500);

    }

    private void StartAnimations() {
        splashTread = new Thread() {
            @Override
            public void run() {
                try {
                    int waited = 0;
                    // Splash screen pause time
                    while (waited < 4500) {
                        sleep(100);
                        waited += 100;
                    }
                    Intent intent = new Intent(SplashActivity.this,
                            Details.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivity(intent);
                    SplashActivity.this.finish();
                } catch (InterruptedException e) {
                    // do nothing
                } finally {
                    SplashActivity.this.finish();
                }

            }
        };
        splashTread.start();


    }

}
