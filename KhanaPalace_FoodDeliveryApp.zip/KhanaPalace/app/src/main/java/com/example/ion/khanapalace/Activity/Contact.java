package com.example.ion.khanapalace.Activity;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.example.ion.khanapalace.R;

public class Contact extends AppCompatActivity {

    TextView call, email,call1,email1;
    Button closecall,closeemail;
    private PopupWindow pwindo,pwindo1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        call = (TextView) findViewById(R.id.call);
        call1 = (TextView) findViewById(R.id.call1);

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initiatePopupWindow();
            }
        });

        call1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initiatePopupWindow();
            }
        });
        email = (TextView) findViewById(R.id.email);
        email1 = (TextView) findViewById(R.id.email1);
        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initiatePopupWindow1();
            }
        });
        email1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                initiatePopupWindow1();
            }
        });


    }

    private void initiatePopupWindow() {
        try {
// We need to get the instance of the LayoutInflater
            LayoutInflater inflater = (LayoutInflater) Contact.this
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View layout = inflater.inflate(R.layout.popup_call,
                    (ViewGroup) findViewById(R.id.callLin));
            pwindo = new PopupWindow(layout, 300, 370, true);
            pwindo.showAtLocation(layout, Gravity.CENTER, 0, 0);


            closecall = (Button) layout.findViewById(R.id.closecall);
            closecall.setOnClickListener(cancel_button_click_listener);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private View.OnClickListener cancel_button_click_listener = new View.OnClickListener() {
        public void onClick(View v) {
            pwindo.dismiss();

        }
    };

    private void initiatePopupWindow1() {
        try {
// We need to get the instance of the LayoutInflater
            LayoutInflater inflater = (LayoutInflater) Contact.this
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View layout = inflater.inflate(R.layout.popup_email,
                    (ViewGroup) findViewById(R.id.emailLin));
            pwindo1 = new PopupWindow(layout, 300, 370, true);
            pwindo1.showAtLocation(layout, Gravity.CENTER, 0, 0);

            closecall = (Button) layout.findViewById(R.id.closeemail);
            closecall.setOnClickListener(cancel_button_click_listener1);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private View.OnClickListener cancel_button_click_listener1 = new View.OnClickListener() {
        public void onClick(View v) {
            pwindo1.dismiss();

        }
    };



}
