package com.example.ion.khanapalace.spare;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ion.khanapalace.Activity.Payment;
import com.example.ion.khanapalace.Database.DataBaseHelper;
import com.example.ion.khanapalace.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login extends AppCompatActivity {


    EditText customername,phn;
    Button login;
    String name,phn1;

    DataBaseHelper db = new DataBaseHelper(Login.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        customername = (EditText) findViewById(R.id.name);
        phn = (EditText) findViewById(R.id.phn);



        login = (Button) findViewById(R.id.Login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name= customername.getText().toString();
                phn1= phn.getText().toString();

                if(isValidPhone(phn1) && phn1.length()==10){
                    Toast.makeText(Login.this, "Welcome "+ name, Toast.LENGTH_LONG).show();
                    Toast.makeText(Login.this, "we will call you at "+ phn1, Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Login.this, Payment.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(Login.this, "Phone number is invalid", Toast.LENGTH_LONG).show();
                }

            }
        });




    }
    public static boolean isValidPhone(String phone)
    {
        String expression = "^([0-9\\+]|\\(\\d{1,3}\\))[0-9\\-\\. ]{3,15}$";
        CharSequence inputString = phone;
        Pattern pattern = Pattern.compile(expression);
        Matcher matcher = pattern.matcher(inputString);
        if (matcher.matches())
        {
            return true;
        }
        else{
            return false;
        }
    }


}
