package com.example.ion.khanapalace.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.ion.khanapalace.Adapter.CustomList;
import com.example.ion.khanapalace.R;

public class RestaurantList extends Activity {

    ListView list;

    String[] web = {
            "Faasos Khajana",
            "Behrouz Biriyani",
            "Ovenstory Pizza",
            "Hotel Manu residency",
            "Imperio restaurant",
            "Delhi Mahal",
            "Chef Bekers",
            "Five Star Chicken"
    } ;

    String[] web1 = {
            "Kebab,North Indian",
            "Biriyani,Chinese",
            "South Indian,Pizza,Wraps",
            "Italian,Continental",
            "Biriyani,Mughlai,North Indian",
            "Burgers,Snacks,Wraps",
            "Biriyani,Sandwichs,Wraps",
            "South Indian,North Indian"
    } ;

    Integer[] imageId = {
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image8,
            R.drawable.image4,
            R.drawable.image5,
            R.drawable.image6,
            R.drawable.image7,
            R.drawable.image8

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_list);

        //Toolbar toolbar=(Toolbar)findViewById(R.id.app);
        //setSupportActionBar(toolbar);

        CustomList adapter = new
                CustomList(RestaurantList.this, web, web1, imageId);
        list=(ListView)findViewById(R.id.list);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {

                Toast.makeText(RestaurantList.this, "Showing Food of" + web[position], Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(RestaurantList.this, FoodActivity.class);
                startActivity(intent);

            }
        });



    }
}
