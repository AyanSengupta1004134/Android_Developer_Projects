package com.example.ion.khanapalace.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.ion.khanapalace.Adapter.MyCustomPagerAdapter;


import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import me.relex.circleindicator.CircleIndicator;
import com.example.ion.khanapalace.R;

public class LocationTrack extends Activity {

    Button searchRest,current,edit;
    private static ViewPager mPager;
    private static int currentPage = 0;
    private static final Integer[] XMEN= {R.drawable.biriyani,R.drawable.chkn,R.drawable.food,R.drawable.pizza,R.drawable.multifood};
    private ArrayList<Integer> XMENArray = new ArrayList<Integer>();
    public static int cur=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_track);

        init();
        searchRest = (Button) findViewById(R.id.rest);
        searchRest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LocationTrack.this,RestaurantList.class);
                startActivity(intent);
            }
        });
        current = (Button) findViewById(R.id.current);
        edit = (Button) findViewById(R.id.edit);
        current.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cur==0){
                    cur=1;
                    Toast.makeText(LocationTrack.this,"Food will be delivered to your Current location",Toast.LENGTH_SHORT).show();
                }
                else{
                    cur=0;
                }
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(LocationTrack.this,Edit_location.class);
                startActivity(intent);
            }
        });

    }
    private void init() {
        for(int i=0;i<XMEN.length;i++)
            XMENArray.add(XMEN[i]);

        mPager = (ViewPager) findViewById(R.id.pager);
        mPager.setAdapter(new MyCustomPagerAdapter(LocationTrack.this,XMENArray));
        CircleIndicator indicator = (CircleIndicator) findViewById(R.id.indicator);
        indicator.setViewPager(mPager);

        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == XMEN.length) {
                    currentPage = 0;
                }
                mPager.setCurrentItem(currentPage++, true);
            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 2500, 2500);
    }

}
