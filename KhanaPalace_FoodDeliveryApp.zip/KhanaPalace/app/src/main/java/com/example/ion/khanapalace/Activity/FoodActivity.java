package com.example.ion.khanapalace.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;


import com.example.ion.khanapalace.Adapter.CustomList;
import com.example.ion.khanapalace.Adapter.FoodList;
import com.example.ion.khanapalace.R;
import com.example.ion.khanapalace.spare.Login;

public class FoodActivity extends AppCompatActivity {

    ListView list;
    Button payment;

    String[] web = {
            "Masala Paneer Wrap       ",
            "Double Cheese Meatball   ",
            "Chicken Biryani          ",
            "Kheema Kulcha Combo      ",
            "Dal Rice with Omelette   ",
            "Meatball Salad Wrap      ",
            "Potato Chilli Pops Salad ",
            "Paneer Biriyani          ",
            "Royal Veg. Rice feast    ",
            "Paneer Tikka rice Feast  ",
            "Jumbo Chicken Rice Feast ",
            "Chicken Salami Rice Feast",
            "Dal Makhani Bowl         "
    } ;
    String[] web1 = {
            "Rs. 119",
            "Rs. 159",
            "Rs. 212",
            "Rs. 115",
            "Rs. 85",
            "Rs. 139",
            "Rs. 129",
            "Rs. 174",
            "Rs. 192",
            "Rs. 200",
            "Rs. 215",
            "Rs. 229",
            "Rs. 76"
    } ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        FoodList adapter = new
                FoodList(FoodActivity.this, web, web1);
        list=(ListView)findViewById(R.id.listfood);
        list.setAdapter(adapter);
        //list.setItemsCanFocus(true);
        Button payment = (Button)findViewById(R.id.payment);
        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FoodActivity.this, Login.class);
                startActivity(intent);
            }
        });

    }


}
