package com.example.ion.khanapalace.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.ion.khanapalace.R;

public class Payment extends AppCompatActivity {

    Button cash,card,internet,option;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        cash = (Button) findViewById(R.id.cash);
        card = (Button) findViewById(R.id.card);
        internet = (Button) findViewById(R.id.inter);
        option = (Button) findViewById(R.id.option);

        cash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(LocationTrack.cur==1)
                    Toast.makeText(Payment.this,"Your food will be delivered to your current location",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(Payment.this,"Your food will be delivered to new location",Toast.LENGTH_SHORT).show();
            }
        });

        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Payment.this,"Still not Applicable",Toast.LENGTH_SHORT).show();
            }
        });
        internet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Payment.this,"Still not Applicable",Toast.LENGTH_SHORT).show();
            }
        });
        option.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Payment.this,Details.class);
                startActivity(intent);
            }
        });
    }

}
