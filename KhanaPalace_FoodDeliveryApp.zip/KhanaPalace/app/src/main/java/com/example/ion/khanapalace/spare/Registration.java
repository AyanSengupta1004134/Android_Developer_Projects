package com.example.ion.khanapalace.spare;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import com.example.ion.khanapalace.Database.DataBaseHelper;
import com.example.ion.khanapalace.R;
import com.example.ion.khanapalace.Util.Customer;

import java.util.regex.Pattern;

/**
 * Created by ION on 29-04-2017.
 */
public class Registration extends Activity implements View.OnClickListener {

    Customer customer = new Customer();
    DataBaseHelper db = new DataBaseHelper(Registration.this);
    EditText name,pass,conpass,phone;
    Button register;
    String bname,bpass,bconpass,bphone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_register);

        name = (EditText) findViewById(R.id.Name);
        pass = (EditText) findViewById(R.id.Password);
        conpass = (EditText) findViewById(R.id.ConfirmPassword);
        phone = (EditText) findViewById(R.id.Phone);


        bname = name.getText().toString();
        bpass = pass.getText().toString();
        bconpass = conpass.getText().toString();
        bphone = phone.getText().toString();


        register = (Button) findViewById(R.id.Register);
        register.setOnClickListener(Registration.this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.Register:
                customer.setName(bname);
                customer.setPassword(bpass);
                customer.setPhone(bphone);


                if(name.getText().toString().isEmpty()){
                    name.setError("Name can't be empty");

                }

                if(pass.getText().toString().isEmpty()){
                    pass.setError("Password can't be empty");

                }
                if(conpass.getText().toString().isEmpty())
                    conpass.setError("Please enter password again");

                if(phone.getText().toString().isEmpty() && !isNumeric(phone.getText().toString()))
                    phone.setError("Please enter valid Phone number");

                if (!bpass.equals(bconpass))
                    conpass.setError("Password doesn't match");
                else if(!name.getText().toString().isEmpty() && !pass.getText().toString().isEmpty()
                        && !conpass.getText().toString().isEmpty() && !phone.getText().toString().isEmpty() && isNumeric(phone.getText().toString())){

                        db.insertCustomer(customer);
                        Intent intent = new Intent(Registration.this,Login.class);
                        startActivity(intent);

                }


                break;
        }
    }

    public static boolean isNumeric(String str) {
        if (str == null) {
            return false;
        }
        int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (Character.isDigit(str.charAt(i)) == false) {
                return false;
            }
        }
        return true;
    }
    private boolean isValidMobile(String phone) {
        boolean check=false;
        if(phone.length()==10){
            check = true;
        }
        return check;
    }
}
