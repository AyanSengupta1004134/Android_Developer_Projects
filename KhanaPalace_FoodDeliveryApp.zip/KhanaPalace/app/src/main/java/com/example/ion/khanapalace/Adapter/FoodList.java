package com.example.ion.khanapalace.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ion.khanapalace.R;

/**
 * Created by ION on 04-05-2017.
 */
public class FoodList extends ArrayAdapter<String> {

    private final Activity context;
    private final String[] web;
    private final String[] web1;

    public FoodList(Activity context,
                      String[] web, String[] web1) {
        super(context, R.layout.food_list, web);
        this.context = context;
        this.web = web;
        this.web1 = web1;


    }
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView= inflater.inflate(R.layout.food_list, null, true);
        TextView txtTitle = (TextView) rowView.findViewById(R.id.textfood);
        TextView txtTitle1 = (TextView) rowView.findViewById(R.id.textcost);
        EditText edit = (EditText) rowView.findViewById(R.id.edit);


        txtTitle.setText(web[position]);
        txtTitle1.setText(web1[position]);
        String a = edit.getText().toString();
        CheckBox check = (CheckBox)rowView.findViewById(R.id.checkBox);
        check.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //is chkIos checked?
                if (((CheckBox) v).isChecked()) {
                    Toast.makeText(context,"Item Added",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(context,"Item Removed",Toast.LENGTH_SHORT).show();
                }

            }
        });

        return rowView;
    }
}
