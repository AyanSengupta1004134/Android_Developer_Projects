package com.example.ion.khanapalace.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.ion.khanapalace.Util.Customer;

/**
 * Created by ION on 24-04-2017.
 */
public class DataBaseHelper extends SQLiteOpenHelper {

    Context context;
    SQLiteDatabase db;
    private static final int DATABASE_VERSION = 13;
    private static final String DATABASE_NAME = "KHANA_PALACE";

    private static final String USER_TABLE = "USER_DETAILS";
    private static final String USER_NAME = "USER_NAME";
    private static final String USER_PASSWORD = "USER_PASSWORD";
    private static final String USER_PHONE = "USER_PHONE";

    private static final String CREATE_USER_TABLE= "Create table " + USER_TABLE +"( "+
            USER_NAME + " varchar(255) ,"+ USER_PASSWORD + " varchar(255) ,"+
            USER_PHONE + " varchar(255) primary key )";

    private static final String DROP_USER_TABLE="DROP TABLE IF EXISTS "+USER_TABLE;;

    private static final String VEG_FOOD_TABLE = "VEG_FOOD";
    private static final String VEGFOOD_NAME = "VEGFOOD_NAME";
    private static final String VEGFOOD_COST = "VEGFOOD_COST";
    private static final String VEGFOOD_DESCRIBTION = "VEGFOOD_DESCRIBTION";
    private static final String CREATE_VEG_FOOD_TABLE= "";
    private static final String DROP_VEG_FOOD_TABLE = "";

    private static final String NONVEG_FOOD_TABLE = "NONVEG_FOOD";
    private static final String NONVEGFOOD_NAME = "NONVEGFOOD_NAME";
    private static final String NONVEGFOOD_COST = "NONVEGFOOD_COST";
    private static final String NONVEGFOOD_DESCRIBTION = "NONVEGFOOD_DESCRIBTION";
    private static final String CREATE_NONVEG_FOOD_TABLE= "";
    private static final String DROP_NONVEG_FOOD_TABLE = "";

    private static final String PLACE_ORDER_TABLE = "PLACE_ORDER";
    private static final String RES_NAME = "RES_NAME";
    //private static final String USER_ID = "USER_ID";
    private static final String FOOD_ARRAY = "FOOD_ARRAY";
    private static final String TOTAL_AMOUNT = "TOTAL_AMOUNT";
    private static final String USER_PRESENT_ADDRESS = "USER_PRESENT_ADDRESS";
    private static final String CREATE_PLACE_ORDER_TABLE = "";
    private static final String DROP_PLACE_ORDER_TABLE = "";



    public DataBaseHelper(Context context)
    {
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_USER_TABLE);
        this.db= db;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        if(newVersion>oldVersion){
            db.execSQL(DROP_USER_TABLE);
            onCreate(db);
        }
    }


    public  void  insertCustomer(Customer c)
    {

            db = this.getWritableDatabase();
            ContentValues values= new ContentValues();

            values.put(USER_NAME, c.getName());
            values.put(USER_PASSWORD, c.getPassword());
            values.put(USER_PHONE, c.getPhone());

            db.insert(USER_TABLE, null, values);
            Toast.makeText(context,"Value inserted",Toast.LENGTH_SHORT).show();

            db.close();

    }

    public String searchPass(String uid){
        db = this.getReadableDatabase();
        String query = " select USER_PHONE, USER_PASSWORD from "+ USER_TABLE;
        Cursor cursor = db.rawQuery(query, null);
        String userid,pass="not found";
        if(cursor.moveToFirst()){
            do{

                userid = cursor.getString(0);
                if(uid.equals(userid)){
                    pass = cursor.getString(1);
                    break;
                }
            }
            while (cursor.moveToNext());
        }
        return pass;
    }
}
