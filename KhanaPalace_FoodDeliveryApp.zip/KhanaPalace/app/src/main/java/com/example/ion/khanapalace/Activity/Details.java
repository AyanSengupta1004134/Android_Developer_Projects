package com.example.ion.khanapalace.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.ion.khanapalace.R;

public class Details extends AppCompatActivity {

    Button location,rest,offer,order,cont;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        location = (Button) findViewById(R.id.Location);
        rest = (Button) findViewById(R.id.rest);
        offer = (Button) findViewById(R.id.offer);
        order = (Button) findViewById(R.id.order);
        cont = (Button) findViewById(R.id.cont);

        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Details.this, LocationTrack.class);
                startActivity(intent1);
            }
        });
        rest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1 = new Intent(Details.this, RestaurantList.class);
                startActivity(intent1);
            }
        });
        offer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1 = new Intent(Details.this, Offers.class);
                startActivity(intent1);
            }
        });
        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1 = new Intent(Details.this, RestaurantList.class);
                startActivity(intent1);
            }
        });
        cont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1 = new Intent(Details.this, Contact.class);
                startActivity(intent1);
            }
        });
    }


}
